"""
App utilities module.

This module provides common application utilities including HTTPX client management.
"""

from .httpx_client_manager_sync import (
    CommonHTTPXClientManagerSync,
    create_client_with_proxy,
    create_client_without_proxy,
    create_client_auto_proxy,
)

__all__ = [
    "CommonHTTPXClientManagerSync",
    "create_client_with_proxy",
    "create_client_without_proxy",
    "create_client_auto_proxy",
]