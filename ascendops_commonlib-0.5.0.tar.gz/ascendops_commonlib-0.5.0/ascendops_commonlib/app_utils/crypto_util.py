import asyncio
import jpype
import jpype.imports
from jpype.types import *
import os
import logging
import base64
import json

import contextlib
import time
import queue
from ascendops_commonlib.enums.service.service_name_enum import ServiceNameEnum 
from concurrent.futures import ThreadPoolExecutor

log = logging.getLogger("ascendopsrealtime")
class Singleton (type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

class ContentHelper(metaclass=Singleton):
    def __init__(self, logger, ljar: str, environment: str, prefix: str, aws_profile: str, instances: int):
        """
            Initializes the ContentHelper class.

            Args:
                logger (object): The logger object used to log errors.
                ljar (str): The path to the JAR file.
                environment (str): The environment name.
                prefix (str): The prefix for the configuration.
                awsProfile (str): The AWS profile name.
                instances (int): The number of instances for the ThreadPoolExecutor.
        """
        self.logger = logger
        if not jpype.isJVMStarted():
            jpype.startJVM("-Xms64m", "-Xmx64m", classpath=[ljar])
            self.krypt = jpype.JClass("com.experian.ops.crypto.Crypto")
            self.krypt.extractNaeConfigFiles(environment, prefix, False)
            k = self.krypt.initAndGet(environment, prefix, aws_profile)

            self.executor = ThreadPoolExecutor(max_workers=instances)

            self.cifaceq = queue.Queue()
            for _ in range(instances):
                self.cifaceq.put([self.krypt.getCipher(k, True), self.krypt.getCipher(k, False)])
        

    def close(self):
        """
            Shuts down the JVM if it is started.
        """
        try:
            if jpype.isJVMStarted():
                jpype.shutdownJVM()
        except Exception as xcp:
            message = {
                  "event_type": "SERVICE_SHUTDOWN",
                  "service": ServiceNameEnum.CRYPTO.value,
                  "message": "Error shutting down JVM",
                  "exception": str(xcp)
               }
            self.logger.error(json.dumps(message))

    @contextlib.contextmanager
    def ciface(self, idx: int):
        """
            Context manager for cipher interface.

            Args:
                idx (int): The index of the cipher object to be used.

            Yields:
                object: The cipher object.
        """
        obj = self.cifaceq.get()
        try:
            yield obj[idx]
        except Exception as xcp:
            message = {
                    "event_type": "CIPHER_INTERFACE",
                    "service": ServiceNameEnum.CRYPTO.value,
                    "message": "Error in cipher interface",
                    "exception": str(xcp)
                }
            self.logger.error(json.dumps(message))
            
        finally:
            self.cifaceq.put(obj)

    def decrypt(self, encrypted: str) -> str:
        """
            Decrypts the encrypted data.

            Args:
                encrypted (str): The encrypted data to be decrypted.

            Returns:
                str: The decrypted data.
        """
        with self.ciface(1) as obj:
            try:
                encrypted_decoded = base64.b64decode(encrypted)
                decrypted_encoded = self.krypt.decrypt(obj, encrypted_decoded)
                decrypted = bytes(decrypted_encoded).decode("utf-8")
            except Exception as e:
                message = {
                    "event_type": "DECRYPTION",
                    "service": ServiceNameEnum.CRYPTO.value,
                    "message": "Decryption failed",
                    "exception": str(e)
                }
                self.logger.error(json.dumps(message))
                raise
            return decrypted

    def encrypt(self, input: str) -> str:
        """
            Encrypts the input data.

            Args:
                input (str): The input data to be encrypted.

            Returns:
                str: The encrypted data.
        """
        with self.ciface(0) as obj:
            try:
                input_encoded = input.encode("utf-8")
                encrypted_encoded = self.krypt.encrypt(obj, input_encoded)
                encrypted_str = base64.b64encode(bytes(encrypted_encoded)).decode("utf-8")
            except Exception as e:
                message = {
                    "event_type": "ENCRYPTION",
                    "service": ServiceNameEnum.CRYPTO.value,
                    "message": "Encryption failed",
                    "exception": str(e)
                }
                self.logger.error(json.dumps(message))
                raise
            return encrypted_str

    def encrypt_file_with_chunks(self, input_path: str, output_path: str):
        """
            Encrypts a file in chunks.

            Args:
                input_path (str): The path to the input file.
                output_path (str): The path to the output file.

            Returns:
                None
        """
        with self.ciface(0) as obj:
            try:
                self.krypt.encryptFileBlockByBlock(obj, input_path, output_path)
                # there is delay so waiting till file is updated
                for _ in range(3):
                    time.sleep(10)
                    if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
                        break
            except Exception as e:
                message = {
                    "event_type": "FILE_ENCRYPTION",
                    "service": ServiceNameEnum.CRYPTO.value,
                    "message": "File encryption failed",
                    "exception": str(e)
                }
                self.logger.error(json.dumps(message))
                raise

    def decrypt_file(self, input_path: str, output_path: str):
        """
            Decrypts a file in chunks.

            Args:
                input_path (str): The path to the input file.
                output_path (str): The path to the output file.

            Returns:
                None
        """
        with self.ciface(1) as obj:
            try:
                self.krypt.decryptFile(obj, input_path, output_path)
                # there is delay so waiting till file is updated
                for _ in range(3):
                    time.sleep(10)
                    if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
                        break
            except Exception as e:
                message = {
                    "event_type": "FILE_DECRYPTION",
                    "service": ServiceNameEnum.CRYPTO.value,
                    "message": "File decryption failed",
                    "exception": str(e)
                }
                self.logger.error(json.dumps(message))
                raise
               
    def etask(self, input: str):
        """
            Submits an encryption task to the executor.

            Args:
                input (str): The input data to be encrypted.

            Returns:
                Any: The future object representing the encryption task.
        """
        return self.executor.submit(self.encrypt, input)

    def dtask(self, encrypted: str):
        """
            Submits a decryption task to the executor.

            Args:
                encrypted (str): The encrypted data to be decrypted.

            Returns:
                Any: The future object representing the decryption task.
        """
        return self.executor.submit(self.decrypt, encrypted)

    async def aetask(self, input: str):
        """
            Submits an asynchronous encryption task to the executor.

            Args:
                input (str): The input data to be encrypted.

            Returns:
                Any: The future object representing the encryption task.
        """
        return await asyncio.wrap_future(self.executor.submit(self.encrypt, input))

    async def adtask(self, encrypted: str):
        """
            Submits an asynchronous decryption task to the executor.

            Args:
                encrypted (str): The encrypted data to be decrypted.

            Returns:
                Any: The future object representing the decryption task.
        """
        return await asyncio.wrap_future(self.executor.submit(self.decrypt, encrypted))


class CryptoUtil:
    instance = None

    @staticmethod
    def initialize(crypto_jar: str, crypto_env: str, crypto_env_prefix: str, crypto_aws_profile: str, crypto_instances: int):
        """
            Initializes the CryptoUtil instance.

            Args:
                crypto_jar (str): The path to the JAR file.
                crypto_env (str): The environment name.
                crypto_env_prefix (str): The prefix for the configuration.
                crypto_aws_profile (str): The AWS profile name.
                crypto_instances (int): The number of instances for the ThreadPoolExecutor.

            Returns:
                None
        """
        try:
            CryptoUtil.instance = ContentHelper(log, crypto_jar, crypto_env, crypto_env_prefix, crypto_aws_profile, crypto_instances)
            message = {
                    "event_type": "SERVICE_INITIALIZATION",
                    "service": ServiceNameEnum.CRYPTO.value,
                    "message": "CryptoUtil setup completed"
                }
            log.warning(json.dumps(message))
        except Exception as xcp:
            message = {
                    "event_type": "SERVICE_INITIALIZATION",
                    "service": ServiceNameEnum.CRYPTO.value,
                    "message": "CryptoUtil initialization Failed",
                    "exception": str(xcp)
                }
            log.error(json.dumps(message))