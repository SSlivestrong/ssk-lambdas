""" httpx client task """

import typing
import httpx
from ascendops_commonlib.ops_utils import ops_util
from ascendops_commonlib.models.httpx_response import HTTPXResponse


class CommonHTTPXClientManagerSync:
    """
    A synchronous HTTP client manager using the HTTPX library.

    Args:
        base_url (str): The base URL for the HTTP client.
        username (str, optional): The username for basic authentication. Defaults to None.
        password (str, optional): The password for basic authentication. Defaults to None.
        max_connections (int, optional): The maximum number of connections. Defaults to 1.
        max_keepalive_connections (int, optional): The maximum number of keep-alive connections. Defaults to 1.
        connect_timeout (float, optional): The timeout for establishing a connection. Defaults to 0.5.
        conn_pool_timeout (float, optional): The timeout for acquiring a connection from the connection pool. Defaults to 0.5.
        keepalive_expiry (int, optional): The expiry time for keep-alive connections. Defaults to 600.
        read_timeout (float, optional): The timeout for reading a response. Defaults to 1.
        write_timeout (float, optional): The timeout for writing a request. Defaults to None.
        proxy_url (str, optional): The proxy URL. Defaults to None.
        ssl_verify (bool, optional): Whether to verify SSL certificates. Defaults to False.
    """

    def __init__(
        self,
        base_url: str,
        username: typing.Optional[str] = None,
        password: typing.Optional[str] = None,
        max_connections: int = 1,
        max_keepalive_connections: int = 1,
        connect_timeout: float = 0.5,
        conn_pool_timeout: float = 0.5,
        keepalive_expiry: int = 600,
        read_timeout: float = 1,
        write_timeout=None,
        proxy_url: typing.Optional[str] = None,
        ssl_verify=False
    ):
        """
        Initializes an instance of the CommonHTTPXClientManagerSync class.

        Args:
            base_url (str): The base URL for the HTTP client.
            username (str, optional): The username for basic authentication. Defaults to None.
            password (str, optional): The password for basic authentication. Defaults to None.
            max_connections (int, optional): The maximum number of connections. Defaults to 1.
            max_keepalive_connections (int, optional): The maximum number of keep-alive connections. Defaults to 1.
            connect_timeout (float, optional): The timeout for establishing a connection. Defaults to 0.5.
            conn_pool_timeout (float, optional): The timeout for acquiring a connection from the connection pool. Defaults to 0.5.
            keepalive_expiry (int, optional): The expiry time for keep-alive connections. Defaults to 600.
            read_timeout (float, optional): The timeout for reading a response. Defaults to 1.
            write_timeout (float, optional): The timeout for writing a request. Defaults to None.
            proxy_url (str, optional): The proxy URL. Defaults to None.
            ssl_verify (bool, optional): Whether to verify SSL certificates. Defaults to False.
        """
        self.base_url = base_url
        auth = httpx.BasicAuth(username, password) if username and password else None
        if proxy_url:
            self.client = httpx.Client(
                base_url=self.base_url,
                auth=auth,
                limits=httpx.Limits(
                    max_connections=max_connections,
                    max_keepalive_connections=max_keepalive_connections,
                    keepalive_expiry=keepalive_expiry,
                ),
                timeout=httpx.Timeout(
                    connect=connect_timeout,
                    read=read_timeout,
                    write=write_timeout,
                    pool=conn_pool_timeout,
                ),
                proxy=proxy_url,
                verify=ssl_verify,
            )
        else:
            self.client = httpx.Client(
                base_url=self.base_url,
                auth=auth,
                limits=httpx.Limits(
                    max_connections=max_connections,
                    max_keepalive_connections=max_keepalive_connections,
                    keepalive_expiry=keepalive_expiry,
                ),
                timeout=httpx.Timeout(
                    connect=connect_timeout,
                    read=read_timeout,
                    write=write_timeout,
                    pool=conn_pool_timeout,
                ),
                verify=ssl_verify,
            )

    def make_request_sync(
        self,
        endpoint: str,
        method: str = "get",
        payload: typing.Optional[dict] = None,
        headers: typing.Optional[dict] = None,
        retries: int = 0,
        logger=None,
        verify: bool = False,
        auth=None,
        read_timeout: typing.Optional[float] = None,
        params: typing.Optional[dict] = None,
    ):
        """
        Makes a synchronous HTTP request to the specified endpoint.

        Args:
            endpoint (str): The URL endpoint to send the request to.
            method (str, optional): The HTTP method to use for the request. Defaults to "get".
            payload (dict, optional): The payload to include in the request. Defaults to None.
            headers (dict, optional): The headers to include in the request. Defaults to None.
            retries (int, optional): The number of times to retry the request in case of failure. Defaults to 0.
            logger (optional): The logger object to use for logging. Defaults to None.
            verify (bool, optional): Whether to verify the SSL certificate. Defaults to False.
            auth (optional): The authentication object to use for the request. Defaults to None.
            params (dict, optional): The query parameters to include in the request. Defaults to None.

        Returns:
            HTTPXResponse: The response object containing the result of the request.

        Raises:
            ValueError: If an unsupported HTTP method is provided.
        """
        if params is None:
            params = {}
        if headers:
            params["headers"] = headers
        if auth:
            params["auth"] = auth
        if verify:
            params["verify"] = verify

        last_exception = {}
        invocations = {}
        for _retry in range(0, retries + 1):
            st_time = ops_util.get_epoch_millis()
            try:
                if read_timeout:
                    self.client.timeout.read = read_timeout

                if method.upper() == "GET":
                    response = self.client.get(endpoint, **params)
                elif method.upper() == "POST":
                    if "Content-Type" in params["headers"] and "application/json" in params["headers"]["Content-Type"]:
                        response = self.client.post(endpoint, json=payload, **params)
                    else:
                        response = self.client.post(endpoint, data=payload, **params)
                else:
                    # TODO: unsupported method logging - add transaction id
                    raise ValueError(f"Unsupported HTTP method: {method} | endpoint: {endpoint}")

                # throw errors if response is not 2xx
                # response.raise_for_status()
                if 200 <= response.status_code < 300:
                    # handle different reponse content-types
                    content_type = response.headers.get("content-type", "").split(";")[0].strip()

                    if "application/json" in content_type:
                        data = response.json()
                    elif "text/" in content_type:
                        data = response.text
                    else:
                        data = response.content
                    invocations.update(
                        {
                            "attempt:"
                            + str(_retry): {
                                "success": True,
                                "code": response.status_code,
                                "latency": ops_util.get_epoch_millis() - st_time,
                                "exception": None,
                            }
                        }
                    )
                    httpx_response = {
                        "status": "success",
                        "code": response.status_code,
                        "data": data,
                        "headers": dict(response.headers),
                        "retries": _retry,
                        "invocations": invocations,
                    }
                    return HTTPXResponse.model_validate(httpx_response)

                elif response.status_code >= 300:
                    content_type = response.headers.get("content-type", "").split(";")[0].strip()

                    if "application/json" in content_type:
                        data = response.json()
                    elif "text/" in content_type:
                        data = response.text
                    else:
                        data = response.content

                    # except httpx.HTTPStatusError as xcp:
                    #     #TOD: single log
                    invocations.update(
                        {
                            "attempt:"
                            + str(_retry): {
                                "success": False,
                                "code": response.status_code,
                                "data": data,
                                "latency": ops_util.get_epoch_millis() - st_time,
                                "exception": str(data),
                            }
                        }
                    )
                    last_exception = {
                        "status": "failure",
                        "code": response.status_code,
                        "data": data,
                        "message": str(data),
                        "headers": dict(response.headers) if response.headers else {},
                        "retries": _retry,
                    }

            except Exception as xcp:
                invocations.update(
                    {
                        "attempt:"
                        + str(_retry): {
                            "success": False,
                            "code": 500,
                            "latency": ops_util.get_epoch_millis() - st_time,
                            "exception": str(xcp),
                        }
                    }
                )
                last_exception = {
                    "status": "failure",
                    "code": 500,
                    "message": str(xcp),
                    "headers": {},
                    "retries": _retry,
                }
        last_exception.update({"invocations": invocations})
        return HTTPXResponse.model_validate(last_exception)

    def close(self):
        """
        Closes the HTTPX client.

        This method closes the underlying HTTPX client, releasing any resources
        associated with it.

        Args:
            None

        Returns:
            None
        """
        self.client.close()


# Factory functions for creating clients with different proxy configurations

def create_client_with_proxy(
    base_url: str,
    proxy_url: str,
    username: typing.Optional[str] = None,
    password: typing.Optional[str] = None,
    **kwargs
) -> CommonHTTPXClientManagerSync:
    """
    Factory function to create an HTTPX client manager with proxy.

    Args:
        base_url (str): The base URL for the HTTP client.
        proxy_url (str): The proxy URL to use.
        username (str, optional): Username for basic authentication.
        password (str, optional): Password for basic authentication.
        **kwargs: Additional arguments for CommonHTTPXClientManagerSync.

    Returns:
        CommonHTTPXClientManagerSync: Configured client manager with proxy.
    """
    return CommonHTTPXClientManagerSync(
        base_url=base_url,
        proxy_url=proxy_url,
        username=username,
        password=password,
        **kwargs
    )


def create_client_without_proxy(
    base_url: str,
    username: typing.Optional[str] = None,
    password: typing.Optional[str] = None,
    **kwargs
) -> CommonHTTPXClientManagerSync:
    """
    Factory function to create an HTTPX client manager without proxy.

    Args:
        base_url (str): The base URL for the HTTP client.
        username (str, optional): Username for basic authentication.
        password (str, optional): Password for basic authentication.
        **kwargs: Additional arguments for CommonHTTPXClientManagerSync.

    Returns:
        CommonHTTPXClientManagerSync: Configured client manager without proxy.
    """
    return CommonHTTPXClientManagerSync(
        base_url=base_url,
        proxy_url=None,
        username=username,
        password=password,
        **kwargs
    )


def create_client_auto_proxy(
    base_url: str,
    username: typing.Optional[str] = None,
    password: typing.Optional[str] = None,
    **kwargs
) -> CommonHTTPXClientManagerSync:
    """
    Factory function to create an HTTPX client manager with automatic proxy detection.

    This function will use proxy if SQUID_PROXY environment variable is set,
    otherwise creates client without proxy.

    Args:
        base_url (str): The base URL for the HTTP client.
        username (str, optional): Username for basic authentication.
        password (str, optional): Password for basic authentication.
        **kwargs: Additional arguments for CommonHTTPXClientManagerSync.

    Returns:
        CommonHTTPXClientManagerSync: Configured client manager with auto proxy detection.
    """
    import os
    proxy_url = os.getenv('SQUID_PROXY')
    return CommonHTTPXClientManagerSync(
        base_url=base_url,
        proxy_url=proxy_url,
        username=username,
        password=password,
        **kwargs
    )
