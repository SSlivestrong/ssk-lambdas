"""Authentication base class with shared utilities for AWS secrets, Redis caching, and logging."""

import json
import logging
import asyncio
import base64
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
import httpx

from .distributed_cache import DistributedCache
from ascendops_commonlib.ops_utils import ops_util
from ascendops_commonlib.aws_utils.secrets_manager_util import SecretsManagerUtil


class AuthType:
    """Authentication type constants."""
    JWT_BEARER = "jwt_bearer"
    BASIC_TO_BEARER = "basic_to_bearer"
    API_KEY = "api_key"
    BASIC_AUTH = "basic_auth"
    CERTIFICATE = "certificate"
    NO_AUTH = "no_auth"


class AuthenticationBaseService(ABC):
    """Base class providing AWS secrets, Redis caching, and logging utilities.

    Services can opt-in or opt-out of AWS Secrets Manager usage based on their needs:
    - FDN: Requires AWS Secrets Manager (uses get_aws_secret)
    - EWS: Does NOT require AWS Secrets Manager (uses environment variables)
    """

    # Services that support domain extraction from basic tokens
    DOMAIN_EXTRACTION_SERVICES = {"FDN"}

    # Services that require AWS Secrets Manager access
    AWS_SECRETS_SERVICES = {"FDN"}

    # Services that use environment variables instead of AWS Secrets
    ENV_BASED_SERVICES = {"EWS"}
    
    def __init__(self, service_name: str, logger: Optional[logging.Logger] = None, **kwargs):
        """Initialize with service name and optional logger."""
        self.service_name = service_name.upper()
        self.config = kwargs
        
        self.logger = logger or logging.getLogger(f"auth.{service_name.lower()}")
        self.cache = DistributedCache(self.logger)
    
    # === CACHE UTILITIES ===
    def generate_cache_key(self, credentials: Dict[str, Any]) -> str:
        """Generate cache key: AUTH::TOKEN::SERVICE_NAME::hash::TOKEN"""
        return self.cache.generate_cache_key(self.service_name, credentials)
    
    def get_cached_data(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """Get cached data from Redis."""
        try:
            cached_data = self.cache.get_cached_data(cache_key)
            if cached_data:
                self.logger.debug("Cache hit")
            return cached_data
        except Exception as e:
            self.logger.warning(f"Cache error: {e}")
            return None
    
    def cache_data(self, cache_key: str, data: Dict[str, Any], ttl_seconds: int) -> None:
        """Cache data in Redis with TTL."""
        try:
            self.cache.cache_data(cache_key, data, ttl_seconds)
        except Exception as e:
            self.logger.warning(f"Cache storage error: {e}")
    
    # === AWS SECRETS UTILITIES ===
    def requires_aws_secrets(self) -> bool:
        """Check if this service requires AWS Secrets Manager access."""
        return self.service_name in self.AWS_SECRETS_SERVICES

    def uses_env_variables(self) -> bool:
        """Check if this service uses environment variables instead of AWS Secrets."""
        return self.service_name in self.ENV_BASED_SERVICES

    def get_aws_secret(self, secret_name: str, region: str = "us-east-1") -> Dict[str, Any]:
        """Load AWS secret and parse JSON if needed.

        Only call this method if requires_aws_secrets() returns True.
        Services that use environment variables should not call this method.
        """
        if not self.requires_aws_secrets():
            raise ValueError(f"Service {self.service_name} does not require AWS Secrets Manager. "
                           f"Use environment variables instead.")

        try:
            secrets_util = SecretsManagerUtil(region_name=region)
            secret_data = secrets_util.get_secret(secret_name)
            if not secret_data:
                raise ValueError(f"Secret {secret_name} not found")
            return secret_data
        except Exception as e:
            self.logger.error(f"Error loading secret {secret_name}: {e}")
            raise
    
    def get_nested_secret_value(self, secret_data: Dict[str, Any], key: str) -> Dict[str, Any]:
        """Extract and parse nested secret value (for Crosscore/FDN format)."""
        try:
            if key not in secret_data:
                raise ValueError(f"Key {key} not found in secret data")
            
            nested_data = secret_data[key]
            return json.loads(nested_data) if isinstance(nested_data, str) else nested_data
                
        except Exception as e:
            self.logger.error(f"Error parsing nested secret for key {key}: {e}")
            raise
    
    def extract_domain_from_basic_token(self, basic_token: str) -> str:
        """Extract domain from basic token (only for whitelisted services)."""
        if self.service_name not in self.DOMAIN_EXTRACTION_SERVICES:
            raise ValueError(f"Domain extraction not supported for {self.service_name}")
        
        try:
            decoded = base64.b64decode(basic_token).decode('utf-8')
            username, _ = decoded.split(':', 1)
            
            if '@' in username:
                return username.split('@')[1]
            else:
                raise ValueError("No domain found in username")
                
        except Exception as e:
            self.logger.error(f"Error extracting domain: {e}")
            raise
    
    # === LOGGING UTILITIES ===
    def log_auth_attempt(self, credentials_info: str):
        """Log authentication attempt."""
        self.logger.info(f"{self.service_name} auth attempt: {credentials_info}")
    
    def log_auth_success(self, token_length: int):
        """Log successful authentication."""
        self.logger.info(f"{self.service_name} auth success, token length: {token_length}")
    
    def log_auth_error(self, error: Exception):
        """Log authentication error."""
        self.logger.error(f"{self.service_name} auth failed: {str(error)}")
    
    # === ASYNC CONTEXT MANAGER ===
    async def __aenter__(self):
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Exit async context manager."""
        # Cleanup resources if needed
        pass

    # === ABSTRACT METHODS ===
    @abstractmethod
    async def authenticate(self, **credentials):
        """Authenticate and return token response."""
        pass

    @abstractmethod
    def get_auth_headers(self, token_response) -> Dict[str, str]:
        """Get authentication headers."""
        pass
