"""Distributed cache utilities for authentication tokens."""

import json
import hashlib
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from ascendops_commonlib.datastores.redis_util import RedisCache


class DistributedCache:
    """Distributed cache for authentication tokens using Redis."""
    
    def __init__(self, logger=None):
        """Initialize cache with optional logger."""
        self.logger = logger
        self.key_prefix = "AUTH::TOKEN"
    
    def generate_cache_key(self, service_type: str, credentials: Dict[str, Any]) -> str:
        """Generate cache key: AUTH::TOKEN::SERVICE_NAME::hash::TOKEN"""
        # Remove sensitive data for key generation
        safe_creds = {k: v for k, v in credentials.items() 
                     if k not in ['private_key', 'password', 'client_secret', 'basic_token']}
        
        cred_str = json.dumps(safe_creds, sort_keys=True)
        cred_hash = hashlib.md5(cred_str.encode()).hexdigest()[:12]
        
        return f"{self.key_prefix}::{service_type.upper()}::{cred_hash}::TOKEN"
    
    def get_cached_data(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """Get data from Redis cache."""
        try:
            return RedisCache.get_from_redis(cache_key, self.logger)
        except Exception:
            return None
    
    def cache_data(self, cache_key: str, data: Dict[str, Any], ttl_seconds: int):
        """Cache data in Redis with TTL."""
        try:
            cache_data = {
                **data,
                'cached_at': datetime.utcnow().isoformat()
            }
            RedisCache.set_in_redis(cache_key, cache_data, ttl_seconds, self.logger)
        except Exception:
            pass
