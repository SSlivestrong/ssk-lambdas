"""EWS authentication client interface."""

import os
from typing import Dict, Any
from .ews_token_service import EWSTokenService


class EWSClient:
    """EWS authentication client."""
    
    @staticmethod
    async def get_token_data_from_env(
        is_lambda: bool = False,
        timeout_seconds: float = None,
        max_retries: int = 3,
        refresh_threshold_seconds: int = 60,
        squid_proxy: str = os.getenv("SQUID_PROXY", ""),
        ews_private_key_path: str = os.getenv("EWS_PRIVATE_KEY_PATH", None),
        ews_base_url: str = os.getenv("EWS_BASE_URL", "https://platform.cat.earlywarning.io"),
        ews_kid: str = os.getenv("EWS_KID", "330da108617fdaa8"),
        ews_auth_client_id: str = os.getenv("EWS_AUTH_CLIENT_ID", "8df0bfd9-7691-401c-9778-2311bfdff83c"),
        ews_client_id: str = os.getenv("EWS_CLIENT_ID", "Experian"),
        ews_client_acct_id: str = os.getenv("EWS_CLIENT_ACCT_ID", "Experian"),
        ews_app: str = os.getenv("EWS_APP", "ExpandCreditInsights49A1012001"),
        ews_billing_client_id: str = os.getenv("EWS_BILLING_CLIENT_ID", "JPMC"),
        ews_billing_client_acct_id: str = os.getenv("EWS_BILLING_CLIENT_ACCT_ID", "JPMC")
    ) -> Dict[str, Any]:
        """Get EWS token data using environment variables (not AWS Secrets Manager).

        This method retrieves EWS configuration from environment variables first,
        falling back to default values if environment variables are not set.
        It generates a JWT token for authentication.

        Environment Variables (with fallback defaults):

        HTTP Client Configuration:
        - SQUID_PROXY: Proxy server URL (default: "")
        - EWS_TIMEOUT_SECONDS: Pool timeout in seconds for real-time service (default: 5.0)
        - EWS_LAMBDA_TIMEOUT_SECONDS: Pool timeout in seconds for Lambda service (default: 30.0)
        - EWS_CONN_TIMEOUT: Connection timeout in seconds (default: 5.0)
        - EWS_READ_TIMEOUT: Read timeout in seconds for real-time service (default: 10.0)
        - EWS_TOKEN_READ_TIMEOUT: Read timeout in seconds for Lambda service (default: 30.0)
        - EWS_MAX_CONNECTIONS: Maximum concurrent connections (default: 20 real-time, 5 lambda)
        - EWS_MAX_KEEP_ALIVE_CONNECTIONS: Maximum keep-alive connections (default: 10 real-time, 2 lambda)
        - EWS_KEEPALIVE_EXPIRY: Keep-alive expiry in seconds (default: 300 real-time, 30 lambda)
        - EWS_SSL_VERIFY: SSL certificate verification (default: True)
        - EWS_RETRIES: Maximum retry attempts (default: 3)

        EWS Authentication Configuration:
        - EWS_PRIVATE_KEY_PATH: Path to EWS private key file (default: Lambda=/Volumes/work/shaheer_projects/experian/ssk-lambdas/lambdas/certs/ews_uat_jwks_private_key.pem, Real-time=ascendops_realtime/certs/ews_uat_jwks_private_key.pem)
        - EWS_BASE_URL: EWS API base URL (default: https://platform.cat.earlywarning.io)
        - EWS_KID: JWT Key ID (default: 330da108617fdaa8)
        - EWS_AUTH_CLIENT_ID: EWS authentication client ID (default: 8df0bfd9-7691-401c-9778-2311bfdff83c)
        - EWS_CLIENT_ID: EWS client identifier (default: Experian)
        - EWS_CLIENT_ACCT_ID: EWS client account ID (default: Experian)
        - EWS_APP: EWS application name (default: ExpandCreditInsights49A1012001)
        - EWS_BILLING_CLIENT_ID: EWS billing client ID (default: JPMC)
        - EWS_BILLING_CLIENT_ACCT_ID: EWS billing client account ID (default: JPMC)

        Returns:
            Token data dict like existing set_ews_token() function:
            {
                "access_token": "...",
                "expires_in": 3600,
                "token_type": "Bearer",
                "issued_at": 1234567890,
                "runtime_generated": True
            }
        """
        # Handle environment variable for timeout_seconds if not provided
        if timeout_seconds is None:
            timeout_seconds = float(os.getenv("EWS_TIMEOUT_SECONDS", "5.0"))

        async with EWSTokenService(
            is_lambda=is_lambda,
            timeout_seconds=timeout_seconds,
            max_retries=max_retries,
            squid_proxy=squid_proxy,
            ews_private_key_path=ews_private_key_path,
            ews_base_url=ews_base_url,
            ews_kid=ews_kid,
            ews_auth_client_id=ews_auth_client_id,
            ews_client_id=ews_client_id,
            ews_client_acct_id=ews_client_acct_id,
            ews_app=ews_app,
            ews_billing_client_id=ews_billing_client_id,
            ews_billing_client_acct_id=ews_billing_client_acct_id
        ) as service:
            return await service.get_token_data_with_caching(
                secret_name="",  # Not used for environment-based auth
                region="",      # Not used for environment-based auth
                refresh_threshold_seconds=refresh_threshold_seconds
            )
    
    @staticmethod
    async def get_token_from_secret(
        secret_name: str,
        region: str = "us-east-1",
        is_lambda: bool = False,
        timeout_seconds: float = None,
        max_retries: int = 3,
        refresh_threshold_seconds: int = 60
    ) -> str:
        """Get EWS token from AWS Secrets Manager.
        
        Args:
            secret_name: Name of the AWS secret containing EWS credentials
            region: AWS region for secrets manager
            is_lambda: True if running in Lambda, False for real-time service (default)
            timeout_seconds: Request timeout (default: 5s for real-time, 30s for Lambda)
            max_retries: Maximum retry attempts (default: 3)
            refresh_threshold_seconds: Seconds before expiry to trigger refresh (default 60s)
            
        Returns:
            Access token string
        """
        async with EWSTokenService(
            is_lambda=is_lambda,
            timeout_seconds=timeout_seconds,
            max_retries=max_retries
        ) as service:
            return await service.get_token_from_secret_with_caching(
                secret_name=secret_name,
                region=region,
                refresh_threshold_seconds=refresh_threshold_seconds
            )
    
    @staticmethod
    async def get_token(
        client_id: str,
        private_key: str,
        token_url: str,
        audience: str = "https://api.experian.com",
        key_id: str = None,
        is_lambda: bool = False,
        timeout_seconds: float = None,
        max_retries: int = 3,
        refresh_threshold_seconds: int = 60
    ) -> str:
        """Get EWS token directly with credentials.
        
        Args:
            client_id: EWS client ID
            private_key: Private key for JWT signing
            token_url: EWS token endpoint URL
            audience: JWT audience
            key_id: Optional key ID for JWT header
            is_lambda: True if running in Lambda, False for real-time service (default)
            timeout_seconds: Request timeout (default: 5s for real-time, 30s for Lambda)
            max_retries: Maximum retry attempts (default: 3)
            refresh_threshold_seconds: Seconds before expiry to trigger refresh (default 60s)
            
        Returns:
            Access token string
        """
        async with EWSTokenService(
            is_lambda=is_lambda,
            timeout_seconds=timeout_seconds,
            max_retries=max_retries
        ) as service:
            return await service.get_token_with_caching(
                refresh_threshold_seconds=refresh_threshold_seconds,
                client_id=client_id,
                private_key=private_key,
                token_url=token_url,
                audience=audience,
                key_id=key_id
            )
