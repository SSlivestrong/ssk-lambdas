"""EWS JWT token service implementation."""

import jwt
import os
import httpx
from typing import Dict, Any
from ..base.authentication_base import AuthenticationBaseService, AuthType
from ascendops_commonlib.models.jwt_models import EWSCredential, EWSTokenResponse
from ascendops_commonlib.ops_utils import ops_util

# Module-level HTTP client - initialized at app startup like your existing pattern
ews_auth_client = httpx.AsyncClient(
    timeout=httpx.Timeout(
        connect=float(os.getenv('EWS_CONN_TIMEOUT', '5.0')),
        read=float(os.getenv('EWS_READ_TIMEOUT', '10.0')),
        write=None,
        pool=float(os.getenv('EWS_TIMEOUT_SECONDS', '5.0'))
    ),
    limits=httpx.Limits(
        max_connections=int(os.getenv('EWS_MAX_CONNECTIONS', '20')),
        max_keepalive_connections=int(os.getenv('EWS_MAX_KEEP_ALIVE_CONNECTIONS', '10')),
        keepalive_expiry=int(os.getenv('EWS_KEEPALIVE_EXPIRY', '300'))
    ),
    verify=os.getenv('EWS_SSL_VERIFY', 'True').lower() in ('true', '1', 'yes'),
    follow_redirects=True
)

# Lambda-optimized client
ews_lambda_client = httpx.AsyncClient(
    timeout=httpx.Timeout(
        connect=float(os.getenv('EWS_CONN_TIMEOUT', '15.0')),
        read=float(os.getenv('EWS_TOKEN_READ_TIMEOUT', '30.0')),
        write=None,
        pool=float(os.getenv('EWS_LAMBDA_TIMEOUT_SECONDS', '30.0'))
    ),
    limits=httpx.Limits(
        max_connections=int(os.getenv('EWS_MAX_CONNECTIONS', '5')),
        max_keepalive_connections=int(os.getenv('EWS_MAX_KEEP_ALIVE_CONNECTIONS', '2')),
        keepalive_expiry=int(os.getenv('EWS_KEEPALIVE_EXPIRY', '30'))
    ),
    verify=os.getenv('EWS_SSL_VERIFY', 'True').lower() in ('true', '1', 'yes'),
    follow_redirects=True
)


async def close_ews_auth_connections():
    """Close EWS auth connections - similar to your existing pattern."""
    if ews_auth_client:
        await ews_auth_client.aclose()
    if ews_lambda_client:
        await ews_lambda_client.aclose()


class EWSTokenService(AuthenticationBaseService):
    """EWS JWT token service."""
    
    def __init__(self, is_lambda: bool = False, **kwargs):
        """Initialize EWS token service."""
        # Use appropriate module-level HTTP client
        http_client = ews_lambda_client if is_lambda else ews_auth_client

        # Extract EWS configuration from kwargs or environment
        self.squid_proxy = kwargs.get('squid_proxy', os.getenv('SQUID_PROXY', ''))

        # Set default private key path based on environment (Lambda vs real-time)
        default_key_path = '/Volumes/work/shaheer_projects/experian/ssk-lambdas/lambdas/certs/ews_uat_jwks_private_key.pem' if is_lambda else 'ascendops_realtime/certs/ews_uat_jwks_private_key.pem'
        self.ews_private_key_path = kwargs.get('ews_private_key_path', os.getenv('EWS_PRIVATE_KEY_PATH', default_key_path))
        self.ews_base_url = kwargs.get('ews_base_url', os.getenv('EWS_BASE_URL', 'https://platform.cat.earlywarning.io'))
        self.ews_kid = kwargs.get('ews_kid', os.getenv('EWS_KID', '330da108617fdaa8'))
        self.ews_auth_client_id = kwargs.get('ews_auth_client_id', os.getenv('EWS_AUTH_CLIENT_ID', '8df0bfd9-7691-401c-9778-2311bfdff83c'))
        self.ews_client_id = kwargs.get('ews_client_id', os.getenv('EWS_CLIENT_ID', 'Experian'))
        self.ews_client_acct_id = kwargs.get('ews_client_acct_id', os.getenv('EWS_CLIENT_ACCT_ID', 'Experian'))
        self.ews_app = kwargs.get('ews_app', os.getenv('EWS_APP', 'ExpandCreditInsights49A1012001'))
        self.ews_billing_client_id = kwargs.get('ews_billing_client_id', os.getenv('EWS_BILLING_CLIENT_ID', 'JPMC'))
        self.ews_billing_client_acct_id = kwargs.get('ews_billing_client_acct_id', os.getenv('EWS_BILLING_CLIENT_ACCT_ID', 'JPMC'))

        # Handle timeout_seconds from environment if not provided
        timeout_seconds = kwargs.get('timeout_seconds')
        if timeout_seconds is None:
            timeout_seconds = float(os.getenv('EWS_TIMEOUT_SECONDS', '5.0'))
        self.timeout_seconds = timeout_seconds

        # Handle max_retries from environment if not provided
        max_retries = kwargs.get('max_retries')
        if max_retries is None:
            max_retries = int(os.getenv('EWS_RETRIES', '3'))
        self.max_retries = max_retries

        super().__init__(
            service_name="EWS",
            auth_type=AuthType.JWT_BEARER,
            http_client=http_client,
            **kwargs
        )

        # Log EWS configuration
        self.logger.info(f"EWS Configuration: Base URL={self.ews_base_url}, Client ID={self.ews_client_id}, Timeout={self.timeout_seconds}s")
    
    async def authenticate(self, **credentials) -> EWSTokenResponse:
        """Authenticate with EWS using JWT assertion."""
        credential = self.validate_credentials(**credentials)
        
        self.log_auth_attempt(f"client_id={credential.client_id}, audience={credential.audience}")
        
        try:
            # Create JWT assertion
            jwt_assertion = self._create_jwt_assertion(credential)
            
            # Make token request using shared HTTP client
            response = await self.http_client.post(
                credential.token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
                    "client_assertion": jwt_assertion,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"}
            )
            response.raise_for_status()
            
            token_response = EWSTokenResponse(**response.json())
            self.log_auth_success(len(token_response.access_token))
            
            return token_response
            
        except Exception as e:
            self.log_auth_error(e)
            raise
    
    def validate_credentials(self, **credentials):
        """Validate EWS credentials using centralized model."""
        return EWSCredential(**credentials)
    
    def _create_token_response(self, token_data: Dict[str, Any]):
        """Create EWS token response from cached data."""
        return EWSTokenResponse(**token_data)
    
    def get_auth_headers(self, token_response) -> Dict[str, str]:
        """Get EWS authentication headers."""
        return {
            "Authorization": f"Bearer {token_response.access_token}",
            "Content-Type": "application/json"
        }
    
    def format_token_data(self, token_response, runtime_generated: bool = True) -> Dict[str, Any]:
        """Format EWS token data in exact same format as existing set_ews_token()."""
        from ascendops_commonlib.ops_utils import ops_util

        return {
            "access_token": token_response.access_token,
            "expires_in": token_response.expires_in,
            "token_type": token_response.token_type,
            "issued_at": ops_util.get_epoch_millis(),
            "runtime_generated": runtime_generated
        }

    def is_token_expired_or_near_expiry(self, token_data: Dict[str, Any], threshold_seconds: int = 300) -> bool:
        """Check if token is expired or within threshold of expiry (EWS: 5 minutes = 300 seconds).

        Args:
            token_data: Token data dictionary containing created_at and expires_in
            threshold_seconds: Threshold in seconds before expiry to consider token near expiry
                             Default: 300 seconds (5 minutes) for EWS

        Returns:
            True if token needs refresh, False otherwise
        """
        if not token_data or 'created_at' not in token_data or 'expires_in' not in token_data:
            return True  # Missing token data - needs refresh

        current_time = ops_util.get_epoch_millis() / 1000  # Convert to seconds
        token_expiry_time = token_data['created_at'] + token_data['expires_in']

        return current_time >= (token_expiry_time - threshold_seconds)
    
    def _create_jwt_assertion(self, credential) -> str:
        """Create JWT assertion for EWS."""
        now = ops_util.get_epoch_seconds()
        payload = {
            "iss": credential.issuer,
            "sub": credential.client_id,
            "aud": credential.audience,
            "iat": now,
            "exp": now + 300,  # 5 minutes
            "jti": str(now)
        }
        
        headers = {"alg": credential.algorithm}
        if credential.key_id:
            headers["kid"] = credential.key_id
        
        return jwt.encode(
            payload,
            credential.private_key,
            algorithm=credential.algorithm,
            headers=headers
        )

    def _load_private_key(self) -> str:
        """Load private key from file path for JWT signing."""
        try:
            with open(self.ews_private_key_path, 'r') as f:
                return f.read().strip()
        except FileNotFoundError:
            raise ValueError(f"Private key file not found: {self.ews_private_key_path}")
        except Exception as e:
            raise ValueError(f"Error loading private key: {e}")

    # === MISSING METHODS FOR CLIENT COMPATIBILITY ===

    async def get_token_data_with_caching(
        self,
        secret_name: str,
        region: str = "us-east-1",
        refresh_threshold_seconds: int = 60,
        **additional_params
    ) -> Dict[str, Any]:
        """Get token data with caching - compatible with client."""
        return await self.get_token_with_validation_realtime(
            secret_name=secret_name,
            region=region,
            existing_token=None,
            **additional_params
        )

    async def get_token_data_from_secret_with_caching(
        self,
        secret_name: str,
        region: str = "us-east-1",
        refresh_threshold_seconds: int = 60,
        **additional_params
    ) -> Dict[str, Any]:
        """Get token data from secret with caching - compatible with client."""
        return await self.get_token_data_with_caching(
            secret_name=secret_name,
            region=region,
            refresh_threshold_seconds=refresh_threshold_seconds,
            **additional_params
        )

    async def get_token_with_validation_realtime(
        self,
        secret_name: str = "",
        region: str = "",
        existing_token: Dict[str, Any] = None,
        **additional_params
    ) -> Dict[str, Any]:
        """Get token with validation for real-time flow - compatible with client."""
        # For EWS, we'll implement a simplified version
        # In a full implementation, this would include JWT validation
        try:
            # For EWS, we use environment variables instead of AWS Secrets Manager
            # Verify this service is configured for environment-based auth
            if not self.uses_env_variables():
                raise ValueError(f"EWS service is not configured for environment-based authentication. "
                               f"Check ENV_BASED_SERVICES configuration.")

            # Create credentials from environment variables
            secret_data = {
                "issuer": self.ews_auth_client_id,
                "client_id": self.ews_client_id,
                "audience": f"{self.ews_base_url}/token",
                "private_key": self._load_private_key(),
                "token_url": f"{self.ews_base_url}/token",
                "key_id": self.ews_kid,
                "algorithm": "RS256"
            }

            # Generate cache key for potential caching
            cache_key = self.generate_cache_key(secret_data)

            # Check cache first
            cached_token = self.get_cached_data(cache_key)
            if cached_token and not self.is_token_expired_or_near_expiry(cached_token, threshold_seconds=300):
                self.logger.debug("Using cached EWS token")
                return cached_token

            # Token needs refresh (EWS: refresh if < 5 minutes remaining)
            self.logger.info("EWS token needs refresh or not cached")
            token_response = await self.authenticate(**secret_data, **additional_params)
            token_data = self.format_token_data(token_response)

            # Cache the new token
            self.cache_data(cache_key, token_data, ttl_seconds=token_data['expires_in'] - 60)

            return token_data

        except Exception as e:
            self.logger.error(f"Failed to get EWS token: {str(e)}")
            raise
