"""FDN authentication client interface."""

from typing import Dict, Any, Tuple
from .fdn_token_service import FDNTokenService


class FDNClient:
    """FDN authentication client."""
    
    @staticmethod
    async def get_token_data_from_secret(
        secret_name: str,
        domain_key: str,
        region: str = "us-east-1",
        is_lambda: bool = False,
        timeout_seconds: float = None,
        max_retries: int = 3,
        refresh_threshold_seconds: int = 60,
        **additional_params
    ) -> Dict[str, Any]:
        """Get FDN token data in same format as other services.
        
        Args:
            secret_name: AWS secret name containing FDN credentials
            domain_key: Domain key like "AOVERIZON", "AOTMOBILE", "AOATT", etc.
        
        Returns:
            Token data dict like other services:
            {
                "access_token": "...",
                "expires_in": 3600,
                "token_type": "Bearer",
                "issued_at": 1234567890,
                "runtime_generated": True
            }
        """
        async with FDNTokenService(is_lambda=is_lambda) as service:
            return await service.get_token_data_from_secret_with_caching(
                secret_name=secret_name,
                region=region,
                refresh_threshold_seconds=refresh_threshold_seconds,
                domain_key=domain_key,  # Pass domain_key for FDN-specific parsing
                **additional_params
            )
    
    @staticmethod
    async def get_token_tuple_from_secret(
        secret_name: str,
        domain_key: str,
        region: str = "us-east-1",
        is_lambda: bool = False,
        timeout_seconds: float = None,
        max_retries: int = 3,
        refresh_threshold_seconds: int = 60,
        **additional_params
    ) -> Tuple[str, str]:
        """Get FDN token in tuple format (access_token, error_message) like Crosscore.
        
        Returns:
            Tuple of (access_token, error_message)
        """
        try:
            async with FDNTokenService(
                is_lambda=is_lambda,
                timeout_seconds=timeout_seconds,
                max_retries=max_retries
            ) as service:
                access_token = await service.get_token_from_secret_with_caching(
                    secret_name=secret_name,
                    region=region,
                    refresh_threshold_seconds=refresh_threshold_seconds,
                    domain_key=domain_key,
                    **additional_params
                )
                return access_token, ""  # Return token and empty error message
                
        except Exception as e:
            return "", str(e)  # Return empty token and error message
    
    @staticmethod
    async def get_token_from_secret(
        secret_name: str,
        domain_key: str,
        region: str = "us-east-1",
        is_lambda: bool = False,
        timeout_seconds: float = None,
        max_retries: int = 3,
        refresh_threshold_seconds: int = 60,
        **additional_params
    ) -> str:
        """Get FDN token from AWS Secrets Manager.
        
        Args:
            secret_name: Name of the AWS secret containing FDN credentials
            domain: FDN domain
            region: AWS region for secrets manager
            is_lambda: True if running in Lambda, False for real-time service (default)
            timeout_seconds: Request timeout (default: 5s for real-time, 30s for Lambda)
            max_retries: Maximum retry attempts (default: 3)
            refresh_threshold_seconds: Seconds before expiry to trigger refresh (default 60s)
            **additional_params: Additional parameters like correlation_id, request_id
            
        Returns:
            Access token string
        """
        async with FDNTokenService(
            is_lambda=is_lambda,
            timeout_seconds=timeout_seconds,
            max_retries=max_retries
        ) as service:
            return await service.get_token_from_secret_with_caching(
                secret_name=secret_name,
                region=region,
                refresh_threshold_seconds=refresh_threshold_seconds,
                                    domain_key=domain_key,  # FDN-specific parameter
                **additional_params
            )
    
    @staticmethod
    async def get_token(
        username: str = None,
        password: str = None,
        basic_token: str = None,
        domain: str = None,
        base_url: str = "https://da-saas-npsvhreanrlz.mn-na-test.preprod-ascend-na.io",
        is_lambda: bool = False,
        timeout_seconds: float = None,
        max_retries: int = 3,
        refresh_threshold_seconds: int = 60,
        **additional_params
    ) -> str:
        """Get FDN token directly with credentials.
        
        Args:
            username: FDN username (if not using basic_token)
            password: FDN password (if not using basic_token)
            basic_token: Pre-encoded basic token
            domain: FDN domain
            base_url: FDN base URL
            is_lambda: True if running in Lambda, False for real-time service (default)
            timeout_seconds: Request timeout (default: 5s for real-time, 30s for Lambda)
            max_retries: Maximum retry attempts (default: 3)
            refresh_threshold_seconds: Seconds before expiry to trigger refresh (default 60s)
            **additional_params: Additional parameters like correlation_id, request_id
            
        Returns:
            Access token string
        """
        async with FDNTokenService(
            is_lambda=is_lambda,
            timeout_seconds=timeout_seconds,
            max_retries=max_retries
        ) as service:
            return await service.get_token_with_caching(
                refresh_threshold_seconds=refresh_threshold_seconds,
                username=username,
                password=password,
                basic_token=basic_token,
                domain=domain,
                base_url=base_url,
                **additional_params
            )

    @staticmethod
    async def get_token_with_validation_lambda(
        secret_name: str,
        domain_key: str,
        region: str = "us-east-1",
        threshold_seconds: int = 300,
        is_lambda: bool = True,
        **additional_params
    ) -> Dict[str, Any]:
        """Get valid token for Lambda flow - always refresh if near expiry or missing.

        Args:
            secret_name: AWS secret name containing FDN credentials
            domain_key: Domain key like "AOVERIZON", "AOTMOBILE", etc.
            region: AWS region for secrets manager
            threshold_seconds: Threshold in seconds before expiry to refresh token (default 5 mins)
            is_lambda: True for Lambda optimized client
            **additional_params: Additional parameters like correlation_id, request_id

        Returns:
            Token data dictionary with fresh/valid token
        """
        async with FDNTokenService(is_lambda=is_lambda) as service:
            return await service.get_token_with_validation_lambda(
                secret_name=secret_name,
                domain_key=domain_key,
                region=region,
                threshold_seconds=threshold_seconds,
                **additional_params
            )

    @staticmethod
    async def get_token_with_validation_realtime(
        secret_name: str,
        domain_key: str,
        region: str = "us-east-1",
        existing_token: Dict[str, Any] = None,
        is_lambda: bool = False,
        **additional_params
    ) -> Dict[str, Any]:
        """Get valid token for real-time flow - use existing if valid, get new if missing.

        Args:
            secret_name: AWS secret name containing FDN credentials
            domain_key: Domain key like "AOVERIZON", "AOTMOBILE", etc.
            region: AWS region for secrets manager
            existing_token: Existing token data (if any)
            is_lambda: False for real-time service client
            **additional_params: Additional parameters like correlation_id, request_id

        Returns:
            Token data dictionary (existing if valid, new if needed)
        """
        async with FDNTokenService(is_lambda=is_lambda) as service:
            return await service.get_token_with_validation_realtime(
                secret_name=secret_name,
                domain_key=domain_key,
                region=region,
                existing_token=existing_token,
                **additional_params
            )
