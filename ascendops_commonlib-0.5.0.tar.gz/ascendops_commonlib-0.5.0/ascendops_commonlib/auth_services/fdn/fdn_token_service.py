"""FDN basic authentication token service implementation."""

import httpx
from typing import Dict, Any
from ..base.authentication_base import AuthenticationBaseService, AuthType
from ascendops_commonlib.models.basic_auth_models import FDNCredential, FDNTokenResponse
from ascendops_commonlib.ops_utils import ops_util

# Module-level HTTP client - initialized at app startup like your existing pattern
fdn_auth_client = httpx.AsyncClient(
    timeout=5.0,  # Real-time service default
    limits=httpx.Limits(
        max_connections=20,
        max_keepalive_connections=10,
        keepalive_expiry=300.0
    ),
    follow_redirects=True
)

# Lambda-optimized client
fdn_lambda_client = httpx.AsyncClient(
    timeout=30.0,  # Lambda default
    limits=httpx.Limits(
        max_connections=5,
        max_keepalive_connections=2,
        keepalive_expiry=30.0
    ),
    follow_redirects=True
)


async def close_fdn_auth_connections():
    """Close FDN auth connections - similar to your existing pattern."""
    if fdn_auth_client:
        await fdn_auth_client.aclose()
    if fdn_lambda_client:
        await fdn_lambda_client.aclose()


class FDNTokenService(AuthenticationBaseService):
    """FDN basic authentication token service."""
    
    def __init__(self, is_lambda: bool = False, **kwargs):
        """Initialize FDN token service."""
        # Use appropriate module-level HTTP client
        http_client = fdn_lambda_client if is_lambda else fdn_auth_client
        
        super().__init__(
            service_name="FDN",
            auth_type=AuthType.BASIC_TO_BEARER,
            http_client=http_client,
            **kwargs
        )
    
    async def authenticate(self, **credentials) -> FDNTokenResponse:
        """Authenticate with FDN using basic auth."""
        credential = self.validate_credentials(**credentials)
        
        self.log_auth_attempt(f"domain={credential.domain}")
        
        try:
            headers = {
                "Authorization": f"Basic {credential.basic_token}",
                "X-Correlation-ID": str(credentials.get("correlation_id", "")),
                "X-Request-ID": str(credentials.get("request_id", "")),
                "X-Client-ID": credential.client_id or credential.domain,
                "Content-Type": "application/json",
            }
            
            # Use shared HTTP client
            response = await self.http_client.post(
                f"{credential.base_url}/v1/tokens/create",
                headers=headers,
                json={"grant_type": "client_credentials"}
            )
            response.raise_for_status()
            
            token_data = response.json()
            token_response = FDNTokenResponse(**token_data)
            
            self.log_auth_success(len(token_response.access_token))
            return token_response
            
        except Exception as e:
            self.log_auth_error(e)
            raise
    
    def validate_credentials(self, **credentials):
        """Validate FDN credentials using automatic domain extraction."""
        # If we have a basic_token, use the factory method for automatic extraction
        if 'basic_token' in credentials and 'domain' not in credentials:
            return FDNCredential.from_aws_secret_format(**credentials)
        else:
            return FDNCredential(**credentials)
    
    def _create_token_response(self, token_data: Dict[str, Any]):
        """Create FDN token response from cached data."""
        return FDNTokenResponse(**token_data)
    
    def get_auth_headers(self, token_response) -> Dict[str, str]:
        """Get FDN authentication headers."""
        return {
            "Authorization": f"Bearer {token_response.access_token}",
            "Content-Type": "application/json"
        }
    
    def format_token_data(self, token_response, runtime_generated: bool = True) -> Dict[str, Any]:
        """Format FDN token data in same format as other services."""
        return {
            "access_token": token_response.access_token,
            "expires_in": token_response.expires_in,
            "token_type": token_response.token_type,
            "scope": token_response.scope,
            "created_at": token_response.created_at,
            "issued_at": ops_util.get_epoch_millis(),
            "runtime_generated": runtime_generated
        }

    def is_token_expired_or_near_expiry(self, token_data: Dict[str, Any], threshold_seconds: int = 3600) -> bool:
        """Check if token is expired or within threshold of expiry (FDN: 1 hour = 3600 seconds).

        Args:
            token_data: Token data dictionary containing created_at and expires_in
            threshold_seconds: Threshold in seconds before expiry to consider token near expiry
                             Default: 3600 seconds (1 hour) for FDN

        Returns:
            True if token needs refresh, False otherwise
        """
        if not token_data or 'created_at' not in token_data or 'expires_in' not in token_data:
            return True  # Missing token data - needs refresh

        current_time = ops_util.get_epoch_millis() / 1000  # Convert to seconds
        token_expiry_time = token_data['created_at'] + token_data['expires_in']

        return current_time >= (token_expiry_time - threshold_seconds)

    async def ensure_token_valid(self, token_data: Dict[str, Any] = None, **credentials) -> Dict[str, Any]:
        """Ensure valid token exists (for real-time flow - get if missing, use if valid).

        Args:
            token_data: Existing token data (None if missing)
            **credentials: FDN credentials for authentication

        Returns:
            Valid token data dictionary
        """
        if not token_data:
            # No token - authenticate and get new one
            self.logger.info("No token available, authenticating...")
            token_response = await self.authenticate(**credentials)
            return self.format_token_data(token_response)

        # Check if token is still valid (FDN: refresh if < 1 hour remaining)
        if not self.is_token_expired_or_near_expiry(token_data, threshold_seconds=3600):
            # Token is valid, return existing
            self.logger.debug("Using existing valid token")
            return token_data

        # Token is expired or near expiry - refresh
        self.logger.info("Token expired or near expiry, refreshing...")
        token_response = await self.authenticate(**credentials)
        return self.format_token_data(token_response)

    async def get_token_with_validation_lambda(
        self,
        secret_name: str,
        domain_key: str,
        region: str = "us-east-1",
        threshold_seconds: int = 300,
        **additional_params
    ) -> Dict[str, Any]:
        """Get valid token for Lambda flow - always refresh if near expiry or missing.

        Args:
            secret_name: AWS secret name containing FDN credentials
            domain_key: Domain key like "AOVERIZON", "AOTMOBILE", etc.
            region: AWS region for secrets manager
            threshold_seconds: Threshold in seconds before expiry to refresh token
            **additional_params: Additional parameters like correlation_id, request_id

        Returns:
            Token data dictionary with fresh token
        """
        self.log_auth_attempt(f"lambda_flow domain_key={domain_key}")

        try:
            # Load credentials from AWS secret
            secret_data = self.get_aws_secret(secret_name, region)
            nested_credentials = self.get_nested_secret_value(secret_data, domain_key)

            # Generate cache key for potential caching
            cache_key = self.generate_cache_key(nested_credentials)

            # Check cache first
            cached_token = self.get_cached_data(cache_key)

            # Validate token - refresh if expired or near expiry
            if not cached_token or self.is_token_expired_or_near_expiry(cached_token, threshold_seconds):
                self.logger.info("Token needs refresh for Lambda flow")
                token_response = await self.authenticate(**nested_credentials, **additional_params)
                token_data = self.format_token_data(token_response)

                # Cache the new token
                self.cache_data(cache_key, token_data, ttl_seconds=token_data['expires_in'] - 60)
                self.log_auth_success(len(token_data['access_token']))
                return token_data
            else:
                self.logger.debug("Using cached token for Lambda flow")
                return cached_token

        except Exception as e:
            self.log_auth_error(e)
            raise

    async def get_token_with_validation_realtime(
        self,
        secret_name: str,
        domain_key: str,
        region: str = "us-east-1",
        existing_token: Dict[str, Any] = None,
        **additional_params
    ) -> Dict[str, Any]:
        """Get valid token for real-time flow - use existing if valid, get new if missing.

        Args:
            secret_name: AWS secret name containing FDN credentials
            domain_key: Domain key like "AOVERIZON", "AOTMOBILE", etc.
            region: AWS region for secrets manager
            existing_token: Existing token data (if any)
            **additional_params: Additional parameters like correlation_id, request_id

        Returns:
            Token data dictionary (existing if valid, new if needed)
        """
        self.log_auth_attempt(f"realtime_flow domain_key={domain_key}")

        try:
            # Verify this service requires AWS Secrets Manager
            if not self.requires_aws_secrets():
                raise ValueError(f"FDN service is not configured to use AWS Secrets Manager. "
                               f"Check AWS_SECRETS_SERVICES configuration.")

            # Load credentials from AWS secret
            secret_data = self.get_aws_secret(secret_name, region)
            nested_credentials = self.get_nested_secret_value(secret_data, domain_key)

            # Generate cache key for potential caching
            cache_key = self.generate_cache_key(nested_credentials)

            # Use existing token if valid, otherwise get/refresh
            if existing_token and not self.is_token_expired_or_near_expiry(existing_token, threshold_seconds=3600):
                self.logger.debug("Using provided existing token")
                return existing_token

            # Check cache
            cached_token = self.get_cached_data(cache_key)
            if cached_token and not self.is_token_expired_or_near_expiry(cached_token, threshold_seconds=3600):
                self.logger.debug("Using cached token")
                return cached_token

            # Need new token
            self.logger.info("Getting fresh token for real-time flow")
            token_response = await self.authenticate(**nested_credentials, **additional_params)
            token_data = self.format_token_data(token_response)

            # Cache the new token
            self.cache_data(cache_key, token_data, ttl_seconds=token_data['expires_in'] - 60)
            self.log_auth_success(len(token_data['access_token']))
            return token_data

        except Exception as e:
            self.log_auth_error(e)
            raise

    # === MISSING METHODS FOR CLIENT COMPATIBILITY ===

    async def get_token_data_from_secret_with_caching(
        self,
        secret_name: str,
        region: str = "us-east-1",
        refresh_threshold_seconds: int = 60,
        domain_key: str = None,
        **additional_params
    ) -> Dict[str, Any]:
        """Get token data from secret with caching - compatible with client."""
        return await self.get_token_with_validation_realtime(
            secret_name=secret_name,
            domain_key=domain_key,
            region=region,
            existing_token=None,
            **additional_params
        )

    async def get_token_from_secret_with_caching(
        self,
        secret_name: str,
        region: str = "us-east-1",
        refresh_threshold_seconds: int = 60,
        domain_key: str = None,
        **additional_params
    ) -> str:
        """Get token string from secret with caching - compatible with client."""
        token_data = await self.get_token_data_from_secret_with_caching(
            secret_name=secret_name,
            region=region,
            refresh_threshold_seconds=refresh_threshold_seconds,
            domain_key=domain_key,
            **additional_params
        )
        return token_data.get('access_token', '')

    async def get_token_with_caching(
        self,
        refresh_threshold_seconds: int = 60,
        username: str = None,
        password: str = None,
        basic_token: str = None,
        domain: str = None,
        base_url: str = None,
        **additional_params
    ) -> str:
        """Get token with caching - compatible with direct credential client method."""
        # Prepare credentials
        credentials = {}
        if username and password:
            credentials.update({'username': username, 'password': password})
        if basic_token:
            credentials.update({'basic_token': basic_token})
        if domain:
            credentials.update({'domain': domain})
        if base_url:
            credentials.update({'base_url': base_url})

        credentials.update(additional_params)

        # Get token data and return just the access token
        token_response = await self.authenticate(**credentials)
        token_data = self.format_token_data(token_response)

        # Cache the token
        cache_key = self.generate_cache_key(credentials)
        self.cache_data(cache_key, token_data, ttl_seconds=token_data['expires_in'] - 60)

        return token_data.get('access_token', '')
