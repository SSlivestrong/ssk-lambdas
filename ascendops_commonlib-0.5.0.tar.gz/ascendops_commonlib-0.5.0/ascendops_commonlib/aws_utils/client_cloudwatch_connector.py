""" Connects to cloudwatch with a client's role """
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.aws_utils.cloudwatch_connector import (
    CloudwatchConnector,
)


class ClientCloudwatchConnector(CloudwatchConnector):
    """create cloudwatch connector for a given client"""

    def __init__(self, client_alias: str):
        """initializes client cloudwatch connector
        Params:
            client_alias: str - alias of client
        """

        role_arn = f"arn:aws:iam::{ops_config.AWS_ACCOUNT}:role/{ops_config.RUNTIME_ENV}-{client_alias}-sagemaker"

        super().__init__(role_arn=role_arn)
