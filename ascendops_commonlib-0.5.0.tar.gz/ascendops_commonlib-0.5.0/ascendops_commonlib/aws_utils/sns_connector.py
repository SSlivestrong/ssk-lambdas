""" SNS connector for a specific topic - wrapper around boto3 sns client """
import logging
from typing import Optional
from ascendops_commonlib.aws_utils.aws_client_util import STSClientUtil

log = logging.getLogger("ascendopscommon")


class SNSConnectorException(Exception):
    """custom exception for sns connector"""


class SNSConnector:
    """Creates sns connector for a specific topic"""

    def __init__(self, topic_arn: str, role_arn: Optional[str] = None) -> None:
        """
        intitializes sns connector
        Params:
            topic_arn - arn of topic to connect to
            role_arn - role to assume to connect to sns topic
        Raises:
            SNSConnectorException if invalid topic arn is given

        """
        sts_client = STSClientUtil()
        self.sns_client = sts_client.get_client("sns", role_arn=role_arn)

        if not topic_arn:
            raise SNSConnectorException("SNS Connector - topic arn cannot be null")

        self.topic_arn = topic_arn

        try:
            self.topic_name = topic_arn.split(":")[5]
        except Exception as exception:
            # if unable to parse name from topic arn, the arn is invalid
            raise SNSConnectorException(
                "SNS Connector - Invalid topic arn: " + topic_arn
            ) from exception

    def publish_message(self, message: str, message_attributes: dict) -> None:
        """publish message to this connector's topic arn
        Params:
            message: str - message to send to topic
            message_attributes: dict
            {
                '<attribute_name>': {
                    'DataType': 'string', (required, datatype of attribute)
                    'StringValue': 'string', (optional, value as string)
                    'BinaryValue': b'bytes' (optional, value as binary data)
            }
        }

        """
        response = self.sns_client.publish(
            TopicArn=self.topic_arn,
            Message=message,
            MessageAttributes=message_attributes,
        )

        message_id = response.get("MessageId")

        log.info(
            "Message sent to '%s' sns topic with id: '%s'",
            self.topic_name,
            message_id,
        )
