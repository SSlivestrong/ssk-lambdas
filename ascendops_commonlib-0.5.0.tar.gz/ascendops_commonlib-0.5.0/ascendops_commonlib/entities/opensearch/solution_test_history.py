""" Entity that stores information about a sinle solution test case execution """
from datetime import datetime
from opensearch_dsl import Text, Keyword, Integer, Object, InnerDoc, Boolean

from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.entities.opensearch.fields.na_enum_opensearch_field import (
    NAEnumOpensearchField,
)
from ascendops_commonlib.entities.opensearch.fields.na_epoch_millis_date_field import (
    NAEpochMillisDateField,
)
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.enums.solution.solution_test_status_enum import (
    SolutionTestStatusEnum,
)
from ascendops_commonlib.enums.solution.solution_test_type_enum import (
    SolutionTestTypeEnum,
)


class InquiryInputParameters(InnerDoc):
    """stores the input parameters sent by the user for this test
    these values are added to the inquiry string
    """

    device_indicator: str = Text()
    preamble_cod: str = Text()
    operator_initials: str = Text()
    inquiry_type: str = Text()
    subcode_and_password: str = Text()
    verify_keywords: "list[str]" = Text(multi=True)
    products: "list[str]" = Text(multi=True)
    purpose_type: str = Text()


class SolutionTestResult(InnerDoc):
    """Stores result for this solution test"""

    # id for this GO Inquiry transaction. Can be used to view logs
    go_transaction_id: str = Keyword()
    # request sent to GO Inquiry
    request: dict = Object(dynamic=False)
    # response from GO Inquiry
    response: dict = Object(dynamic=False)
    # billing results from test
    billing: "list[str]" = Text(multi=True)


class SolutionTestResultDaas(InnerDoc):
    """Stores result for this solution test"""

    # request sent to Daas Inquiry
    request: dict = Object(dynamic=False)
    # response from DaaS Inquiry
    response: dict = Object(dynamic=False)


class SolutionTestHistory(NABaseDocument):
    """history document for a test for a solution"""

    # test case for this execution
    test_case_uid: str = Keyword()
    test_case_name: str = Keyword()
    # defines whether the expected test results need to be defined by user or not
    test_type: SolutionTestTypeEnum = NAEnumOpensearchField(SolutionTestTypeEnum)
    # identifies which test suite execution instance this test is part of
    # a test suite execution is a collection of tests run
    test_suite_execution_uid: str = Keyword()
    test_suite_execution_name: str = Keyword()
    test_suite_submitted_on: datetime = NAEpochMillisDateField(format="epoch_millis")
    # solution uid used in test
    solution_uid: str = Keyword()
    # time when execution call made to GO Inquiry
    exec_start_time: datetime = NAEpochMillisDateField(format="epoch_millis")
    # time when GO Inquiry sends response
    exec_end_time: datetime = NAEpochMillisDateField(format="epoch_millis")
    # status of test
    status: SolutionTestStatusEnum = NAEnumOpensearchField(SolutionTestStatusEnum)
    # runtime of test in milliseconds
    runtime_ms: int = Integer()
    # result from running the test
    test_result: SolutionTestResult = Object(SolutionTestResult)
    status_daas: SolutionTestStatusEnum = NAEnumOpensearchField(SolutionTestStatusEnum)
    test_result_daas: SolutionTestResultDaas = Object(SolutionTestResultDaas)
    compare_report_path: str = Text()
    diff_exists: bool = Boolean()

    # input parameters for this test
    inquiry_input_parameters: InquiryInputParameters = Object(InquiryInputParameters)

    class Index:
        """Opensearch Index where test history documents are stored"""

        name: str = ops_config.SOLUTION_TEST_HISTORY_INDEX_NAME
