"""Defines the names of the different batch components involved with batch execution. Primary purpose of this enum is for logging"""

from enum import Enum, unique


@unique
# Inherits from str as well so that enum is json serializable
class BatchAppNameEnum(str, Enum):
    """Defines the names of the different batch components involved with batch execution. Primary purpose of this enum is for logging"""

    PLATFORM_API: str = "platform-api"
    DISPATCH_CONSUMER: str = "dispatch-consumer"

    PRE_PROCESS_START: str = "pre-process-start"
    PRE_PROCESS_END: str = "pre-process-end"

    MODEL_EXEC_START: str = "model-exec-start"
    MODEL_EXEC_END: str = "model-exec-end"

    POST_PROCESS_START: str = "post-process-start"
    POST_PROCESS_END: str = "post-process-end"

    NOTIFY_CAMPAIGN_END_AMPS: str = "notify-campaign-end-amps"
    NOTIFY_CAMPAIGN_END_MKTG: str = "notify-campaign-end-mktg"

    BATCH_PROCESSOR_START: str = "batch-processor-start"
    BATCH_PROCESSOR_END: str = "batch-processor-end"

    BATCH_ORCHESTRATOR: str = "batch-orchestrator"
