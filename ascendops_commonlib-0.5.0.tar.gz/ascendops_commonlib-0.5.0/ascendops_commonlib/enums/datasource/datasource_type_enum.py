""" Enum that defines the type of input datasources available for realtime execution """

from enum import Enum, unique


# Inherits from str as well so that enum is json serializable
@unique
class DatasourceTypeEnum(str, Enum):
    """Defines the type of Datasource"""

    EXPERIAN: str = "experian"
    CLARITY: str = "clarity"
    EQUIFAX: str = "equifax"
    TRANSUNION: str = "transunion"
    FRAUD: str = "fraud"
    THIRD_PARTY: str = "third_party"
