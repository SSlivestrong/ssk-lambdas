""" Enum that defines the type of a feature used by a model """
from enum import Enum

# Inherits from str as well so that enum is json serializable
class FeatureTypeEnum(Enum):
    """ Defines the type of an input feature """
    # feature is defined by Experian datasets
    GENERIC = "generic"
    # feature is defined by external sources, such as Clarity
    EXTERNAL = "external"
    # feature is defined by marketing
    MARKETING = "marketing"
    # feature is defined by client
    CUSTOM = "custom"
    # feature is a Key (row identifier/experian_consumer_key, etc)
    KEY = "key"
    # feature is a Score
    SCORE = "score"
    # feature is an Adverse Action Code
    AAC = "aac"
    # feature is an Attribute
    ATTRIBUTE = "attribute"
    # feature is an Object response
    OBJECT = "object"
