""" Enum that defines the types of models that can be referenced in a solution """

from enum import Enum, unique


# Inherits from str as well so that enum is json serializable
@unique
class SolutionModelTypeEnum(str, Enum):
    """defines the types of models that can be referenced in a solution"""

    SCORE: str = "score"
    SCORE_ONLY: str = "score_only"
    SCORE_AND_ATTRIBUTE: str = "score_and_attribute"
