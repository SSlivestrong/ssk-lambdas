""" represents the status of a solution test """

from enum import Enum, unique


# Inherits from str as well so that enum is json serializable
@unique
class SolutionTestStatusEnum(str, Enum):
    """represents the status of a solution test"""

    CREATED: str = "created"
    PASSED: str = "passed"
    FAILED: str = "failed"
