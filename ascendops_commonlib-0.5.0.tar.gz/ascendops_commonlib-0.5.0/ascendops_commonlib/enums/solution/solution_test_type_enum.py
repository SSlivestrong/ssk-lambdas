""" Enum that denotes type of test run for verifying a solution document """

from enum import Enum, unique


# Inherits from str as well so that enum is json serializable
@unique
class SolutionTestTypeEnum(str, Enum):
    """denotes type of solution test"""

    # common tests are applicable for all solutions. The success criteria of the test is already defined
    COMMON: str = "common"
    # custom tests are special case tests. The success criteria need to be defined
    CUSTOM: str = "custom"
