"""Basic authentication models."""

from .common_models import BaseCredential, BaseTokenResponse
from pydantic import Field, validator
from typing import Optional
import base64
from ..ops_utils import ops_util


class FDNCredential(BaseCredential):
    """FDN basic authentication credential."""
    basic_token: str = Field(..., description="Base64 encoded basic token from AWS secrets")
    domain: str = Field(..., description="FDN domain (extracted from username in basic_token)")
    client_id: Optional[str] = Field(None, description="Client ID (if different from domain)")
    base_url: str = Field(
        default="https://da-saas-npsvhreanrlz.mn-na-test.preprod-ascend-na.io", 
        description="FDN base URL"
    )
    
    @validator('basic_token')
    def validate_basic_token(cls, v):
        """Validate basic token is provided."""
        if not v or not isinstance(v, str):
            raise ValueError("Basic token must be a non-empty string")
        return v.strip()
    
    @validator('domain')
    def validate_domain(cls, v):
        """Validate domain field."""
        if not v or not isinstance(v, str):
            raise ValueError("Domain must be a non-empty string")
        return v.strip().lower()
    
    @validator('base_url')
    def validate_base_url(cls, v):
        """Validate and clean base URL."""
        return v.rstrip('/')
    
    @classmethod
    def from_aws_secret_format(cls, basic_token: str, **kwargs):
        """Create FDN credential from AWS secret format with automatic domain extraction.
        
        Args:
            basic_token: Base64 encoded token from AWS secrets
            **kwargs: Additional parameters
            
        Returns:
            FDNCredential with extracted domain only
        """
        
        
        # Decode basic token to extract domain only
        try:
            decoded = base64.b64decode(basic_token).decode('utf-8')
            username, _ = decoded.split(':', 1)  # We don't need password
            
            # Extract domain from username (e.g., ascend-ops-real-time-support@verizon-fdn.com)
            domain = username.split('@')[1] if '@' in username else 'unknown'
            
            return cls(
                basic_token=basic_token,
                domain=domain,
                **kwargs
            )
            
        except Exception as e:
            raise ValueError(f"Invalid basic_token format: {e}")


class FDNTokenResponse(BaseTokenResponse):
    """FDN token response model."""
    created_at: int = Field(..., description="Token creation timestamp")
    
    @property
    def is_expired(self) -> bool:
        """Check if FDN token is expired with buffer."""
        current_time = ops_util.get_epoch_seconds()
        return current_time >= (self.created_at + self.expires_in - 60)  # 60s buffer
