"""Common models for authentication services."""

from pydantic import BaseModel, Field, validator
from typing import Optional, Dict, Any
from datetime import datetime, timedelta


class BaseTokenResponse(BaseModel):
    """Base token response model."""
    access_token: str = Field(..., description="Access token")
    token_type: str = Field(default="Bearer", description="Token type")
    expires_in: int = Field(..., description="Expires in seconds")
    scope: Optional[str] = Field(None, description="Token scope")
    
    @property
    def expires_at(self) -> datetime:
        """Calculate absolute expiration time."""
        return datetime.utcnow() + timedelta(seconds=self.expires_in)
    
    @property
    def is_expired(self) -> bool:
        """Check if token is expired with 60s buffer."""
        return datetime.utcnow() >= (self.expires_at - timedelta(seconds=60))
    
    def to_cache_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for caching."""
        return {
            "access_token": self.access_token,
            "token_type": self.token_type,
            "expires_in": self.expires_in,
            "scope": self.scope,
            "expires_at": self.expires_at.isoformat()
        }


class BaseCredential(BaseModel):
    """Base credential model."""
    
    @validator('*', pre=True)
    def strip_strings(cls, v):
        """Strip whitespace from string fields."""
        if isinstance(v, str):
            return v.strip()
        return v
