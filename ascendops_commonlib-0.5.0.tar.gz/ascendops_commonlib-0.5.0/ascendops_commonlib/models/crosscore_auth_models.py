"""Crosscore authentication models."""

from typing import Optional, Dict, Any
from pydantic import Field, validator
from .common_models import BaseCredential, BaseTokenResponse


class CrosscoreCredential(BaseCredential):
    """Crosscore basic authentication credential."""
    basic_token: str = Field(..., description="Base64 encoded basic auth token (crosscore_password)")
    user_domain: str = Field(..., description="X-User-Domain header value")
    base_url: str = Field(default="https://crosscore-api.experian.com", description="Crosscore base URL")
    token_endpoint: str = Field(default="/v1/tokens/create", description="Token endpoint path")
    
    @validator('basic_token')
    def validate_basic_token(cls, v):
        """Validate basic token is provided."""
        if not v or not isinstance(v, str):
            raise ValueError("Basic token (crosscore_password) must be a non-empty string")
        return v.strip()
    
    @validator('user_domain')
    def validate_user_domain(cls, v):
        """Validate user domain is provided."""
        if not v or not isinstance(v, str):
            raise ValueError("User domain must be a non-empty string")
        return v.strip()
    
    @validator('base_url')
    def validate_base_url(cls, v):
        """Validate and clean base URL."""
        return v.rstrip('/')


class CrosscoreTokenResponse(BaseTokenResponse):
    """Crosscore token response model."""
    # Crosscore returns token in nested structure: {"token": {"access_token": "...", "expires_in": 3600}}
    
    @classmethod
    def from_crosscore_response(cls, response_data: Dict[str, Any]) -> CrosscoreTokenResponse:
        """Create token response from Crosscore API response format."""
        token_data = response_data.get("token", {})
        return cls(
            access_token=token_data.get("access_token", ""),
            expires_in=token_data.get("expires_in", 3600),
            token_type=token_data.get("token_type", "Bearer"),
            scope=token_data.get("scope")
        )
