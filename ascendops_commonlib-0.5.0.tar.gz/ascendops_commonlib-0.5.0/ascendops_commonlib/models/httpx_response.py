""" pydantic model for HTTPX Manager Response """

import typing
from pydantic import BaseModel


class HTTPXResponse(BaseModel):
    """ HTTPXResponse """
    status: str
    data: typing.Any | None = None
    headers: dict
    code: int | None = None
    reason: str | None = None
    retries: int = 0
    invocations: dict | None = None
