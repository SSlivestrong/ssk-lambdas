"""JWT-based authentication models."""

from .common_models import BaseCredential, BaseTokenResponse
from pydantic import Field, validator
from typing import Optional


class EWSCredential(BaseCredential):
    """EWS JWT credential model."""
    client_id: str = Field(..., description="EWS Client ID")
    private_key: str = Field(..., description="Private key for JWT signing")
    token_url: str = Field(..., description="EWS token endpoint URL")
    audience: str = Field(default="https://api.experian.com", description="JWT audience")
    issuer: Optional[str] = Field(None, description="JWT issuer (defaults to client_id)")
    key_id: Optional[str] = Field(None, description="Key ID for JWT header")
    algorithm: str = Field(default="RS256", description="JWT algorithm")
    
    @validator('client_id', 'private_key', 'token_url')
    def validate_required_fields(cls, v):
        """Validate required fields are non-empty strings."""
        if not v or not isinstance(v, str):
            raise ValueError("Field must be a non-empty string")
        return v.strip()
    
    @validator('issuer', always=True)
    def set_issuer_default(cls, v, values):
        """Set issuer to client_id if not provided."""
        return v or values.get('client_id')
    
    @validator('token_url')
    def validate_token_url(cls, v):
        """Validate and clean token URL."""
        return v.rstrip('/')


class EWSTokenResponse(BaseTokenResponse):
    """EWS token response model."""
    refresh_token: Optional[str] = Field(None, description="Refresh token if provided")
    id_token: Optional[str] = Field(None, description="ID token if provided")
