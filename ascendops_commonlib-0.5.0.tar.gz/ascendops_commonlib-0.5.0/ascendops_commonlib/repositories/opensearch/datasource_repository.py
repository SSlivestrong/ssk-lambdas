"""
Data layer to interact with Datasource objects
"""
from ascendops_commonlib.entities.opensearch.datasource import Datasource


def opensearch_get_datasources(**kwargs) -> "list[Datasource]":
    """
    Gets all datasources

    Parameters
        include_fields - Optional[list[str]]: document fields to include in returned document
        exclude_fields - Optional[list[str]]: document fields to exclude in returned document

    Returns:
        list of all Datasource objects
    """

    include_fields = kwargs.get("include_fields")
    exclude_fields = kwargs.get("exclude_fields")

    search = Datasource.create_search_object(
        include_fields=include_fields, exclude_fields=exclude_fields
    )
    search = search.query("match_all")
    return search.execute().hits


def opensearch_create_datasource(
    datasource: Datasource, created_by: str, refresh="false"
) -> Datasource:
    """To create a datasource document
    Params:
        datasource: datasource to create
        created_by: creator of this datasource
        refresh: specifies opensearch refresh behavior
    Returns:
        datasource object
    """
    datasource.created_by = created_by
    datasource.insert_document(refresh=refresh)
    return datasource


def opensearch_get_datasource(datasource_uid: str) -> Datasource:
    """
    Gets a datasource document with uid
    Params:
        - datasource_uid: datasource object unique identifier
    Returns:
        datasource object
    """
    return Datasource.get(datasource_uid)


def opensearch_get_datasource_by_name(name):
    """To retrieve datasource documents with  datasource name by case insensitive(if datasource name is not null)"""

    if name:
        query_spec = {
            "query": {"term": {"name": {"value": name, "case_insensitive": "true"}}}
        }
        search = Datasource.create_search_object()
        search.update_from_dict(query_spec)
    return search.execute()


def opensearch_update_datasource(
    datasource: Datasource, updated_by: str, refresh="wait_for"
) -> Datasource:
    """
    To update a datasource document
    Parameters
        datasource: datasource to update
        updated_by: user who updated datasource
        refresh: specifies opensearch refresh behavior

    """
    datasource.updated_by = updated_by
    datasource.update_document(refresh=refresh)
    return datasource
