"""setup module"""

from setuptools import setup, find_packages

setup(
    name="ascendops_commonlib",
    version="0.5.0",
    packages=find_packages(),
    install_requires=[
        "aiomysql==0.2.0",
        "aws-encryption-sdk==4.0.1",
        "boto3==1.37.1",
        "elasticsearch==7.12.0",
        "jpype1==1.5.2",
        "kafka-python==2.1.5",
        "lz4==4.4.4",
        "opensearch-dsl==2.1.0",
        "orjson==3.10.16",
        "pydantic==2.11.3",
        "redis==5.2.1",
        "requests-aws4auth==1.3.1",
        "httpx>=0.27.0",  # Async HTTP client
        "pyjwt>=2.8.0",   # For JWT handling
        "python-dateutil>=2.8.2",  # For date/time handling
    ],
    extras_require={
        "test": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "freezegun>=1.2.2",
            "pytest-asyncio>=0.21.0",
            "pytest-mock>=3.11.1"
        ]
    },
)
