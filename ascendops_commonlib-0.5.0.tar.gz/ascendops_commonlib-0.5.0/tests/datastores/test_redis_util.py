""" Test cases for redis_util.py """

import os
import unittest
from unittest.mock import patch, MagicMock
from logging import Logger
from ascendops_commonlib.datastores.redis_util import RedisCache


class TestRedisCache(unittest.TestCase):
    """Test Redis_util class"""

    @patch("ascendops_commonlib.datastores.redis_util.os.getenv")
    @patch("ascendops_commonlib.datastores.redis_util.SecretsManagerUtil.get_secret")
    @patch("ascendops_commonlib.datastores.redis_util.KMSCrypto.init")
    @patch("ascendops_commonlib.datastores.redis_util.redis.Redis")
    @patch("ascendops_commonlib.datastores.redis_util.redis.ConnectionPool")
    def test_init_single_instance(self, mock_connection_pool, mock_redis, mock_kms_crypto, mock_get_secret, mock_getenv):
        """test init class with non cluster mode
        and mocking connection to a redis server"""

        mock_getenv.side_effect = lambda k, d=None: {
            "MEM_CACHE_CONN": "localhost:6379",
            "MEM_CACHE_SSL": "False",
            "MEM_CACHE_CONN_MODE": None,
        }.get(k, d)
        mock_get_secret.return_value = {"kms_key_id": "your_key_id"}
        mock_connection_pool.return_value = {"connected": True}
        mock_kms_crypto.return_value = "Success"

        RedisCache.init()

        mock_connection_pool.assert_called_once_with(
            host="localhost",
            port="6379",
            db=0,
            max_connections=10,
            socket_timeout=0.300,
            socket_connect_timeout=0.300,
            retry_on_timeout=3,
            socket_keepalive=True,
            username="",
            password="",
        )
        self.assertTrue(RedisCache().pool, {"connected": True})
        mock_redis.assert_called_once_with(connection_pool={"connected": True})

    @patch("ascendops_commonlib.datastores.redis_util.os.getenv")
    @patch("ascendops_commonlib.datastores.redis_util.SecretsManagerUtil.get_secret")
    @patch("ascendops_commonlib.datastores.redis_util.KMSCrypto.init")
    @patch("ascendops_commonlib.datastores.redis_util.redis.ConnectionPool")
    @patch("ascendops_commonlib.datastores.redis_util.redis.Redis")
    @patch("ascendops_commonlib.datastores.redis_util.redis.cluster.RedisCluster")
    def test_single_instance_connection(self, mock_redis_cluster, mock_redis, mock_connection_pool, mock_kms_init, mock_get_secret, mock_getenv):
        """
        Test case to ensure single instance connection is established in RedisCache.
        Args:
            mock_redis_cluster: Mock object for RedisCluster.
            mock_redis: Mock object for Redis.
            mock_connection_pool: Mock object for ConnectionPool.
            mock_kms_init: Mock object for KMS initialization.
            mock_get_secret: Mock object for getting secret.
            mock_getenv: Mock object for getting environment variables.
        """

        mock_getenv.side_effect = lambda k, d=None: {
            "MEM_CACHE_CONN": "localhost:6379",
            "MEM_CACHE_SSL": "False",
            "MEM_CACHE_CONN_MODE": None,
        }.get(k, d)
        mock_get_secret.return_value = {"user": "test_user", "password": "test_password"}

        # Initialize RedisCache
        RedisCache.init()

        # Assertions to ensure single instance connection is established
        mock_getenv.assert_any_call("MEM_CACHE_CONN")
        mock_getenv.assert_any_call("MEM_CACHE_SSL", "False")
        mock_getenv.assert_any_call("MEM_CACHE_CONN_MODE", None)
        mock_get_secret.assert_called_once()
        mock_kms_init.assert_called_once()
        mock_connection_pool.assert_called_once()
        mock_redis.assert_called_once_with(connection_pool=mock_connection_pool.return_value)
        self.assertIsNotNone(RedisCache.client_response_cache)
        self.assertIsNotNone(RedisCache.pool)

    # TODO: fix the unit tests for cluster mode
    # @patch.dict(os.environ, {"MEM_CACHE_CONN": "localhost:6379", "MEM_CACHE_SSL": "False", "MEM_CACHE_CONN_MODE": "cluster"})
    # @patch("ascendops_commonlib.datastores.redis_util.SecretsManagerUtil")
    # @patch("ascendops_commonlib.datastores.redis_util.KMSCrypto.init")
    # @patch("ascendops_commonlib.datastores.redis_util.redis.ConnectionPool")
    # @patch("ascendops_commonlib.datastores.redis_util.redis.Redis")
    # @patch("ascendops_commonlib.datastores.redis_util.redis.cluster.RedisCluster")
    # def test_init_cluster_instance(self, mock_redis_cluster, mock_redis, mock_connection_pool, mock_kms_crypto, mock_secrets_manager):
    #     """test init class with cluster mode
    #     and mocking connection to redis cluster"""

    #     mock_secrets_manager.return_value.get_secret.return_value = {"kms_key_id": "test_key", "user": "test_user", "password": "test_pass"}

    #     mock_redis_cluster.return_value = "mock_redis_cluster_client"
    #     mock_redis.return_value.ping.return_value = True
    #     mock_redis.return_value = "mock_redis_client"
    #     mock_connection_pool.return_value = "mock_connection_pool"

    #     RedisCache.init()

    #     if os.getenv("MEM_CACHE_CONN"):
    #         mock_secrets_manager.return_value.get_secret.assert_called_once()
    #         mock_connection_pool.assert_called_once()
    #         mock_redis_cluster.assert_called_once()

    #     self.assertIsNotNone(RedisCache.client_response_cache)
    #     RedisCache.client_response_cache = None

        # mock_getenv.side_effect = lambda k, d=None: {
        #     "MEM_CACHE_CONN": "localhost:6379",
        #     "MEM_CACHE_SSL": "False",
        #     "MEM_CACHE_CONN_MODE": "cluster",
        # }.get(k, d)
        # mock_get_secret.return_value = {"kms_key_id": "your_key_id", "user": "test_user", "password": "test_password"}
        # mock_redis_cluster.return_value = MagicMock()
        # mock_kms_crypto.return_value = "Success"

        # RedisCache.init()

        # mock_redis_cluster.assert_called_once_with(
        #     startup_nodes=[{"host": "localhost", "port": 6379}],
        #     decode_responses=True,
        #     username="test_user",
        #     password="test_password",
        #     ssl=False,
        #     max_connections=10,
        #     socket_timeout=0.300,
        #     socket_connect_timeout=0.300,
        #     socket_keepalive=True
        # )
        # self.assertIsNotNone(RedisCache.client_response_cache)
        # RedisCache.client_response_cache = None


    # @patch.dict(os.environ, {
    #     "MEM_CACHE_CONN": "localhost:6379",
    #     "MEM_CACHE_SSL": "False"
    # })
    # @patch("ascendops_commonlib.datastores.redis_util.SecretsManagerUtil")
    # @patch("ascendops_commonlib.datastores.redis_util.KMSCrypto.init")
    # @patch("ascendops_commonlib.datastores.redis_util.redis.Redis")
    # @patch("ascendops_commonlib.datastores.redis_util.RedisCluster")
    # def test_init_cluster_instance_2(self, mock_redis_cluster, mock_redis, mock_kmscrypto, mock_secrets_manager):
    #     """Test Redis Cluster initialization"""

    #     # Mock secrets manager response
    #     mock_secrets_manager.return_value.get_secret.return_value = {
    #         "kms_key_id": "test_key",
    #         "user": "test_user",
    #         "password": "test_pass",
    #         "mode": "cluster"
    #     }

    #     # Mock Redis Cluster instance
    #     mock_redis_cluster.return_value = MagicMock()
        
    #     # Run init method
    #     RedisCache.init()

    #     # Ensure RedisCluster is used
    #     mock_redis_cluster.assert_called_once()
        
    #     # Ensure client_response_cache is set
    #     self.assertIsNotNone(RedisCache.client_response_cache)

    # @patch("ascendops_commonlib.datastores.redis_util.os.getenv")
    # @patch("ascendops_commonlib.datastores.redis_util.SecretsManagerUtil.get_secret")
    # @patch("ascendops_commonlib.datastores.redis_util.KMSCrypto.init")
    # @patch("ascendops_commonlib.datastores.redis_util.redis.cluster.RedisCluster")
    # def test_redis_cluster_initialization(self, mock_redis_cluster, mock_kms_crypto, mock_get_secret, mock_getenv):
    #     """Test RedisCluster initialization with cluster mode"""

    #     mock_getenv.side_effect = lambda k, d=None: {
    #         "MEM_CACHE_CONN": "localhost:6379",
    #         "MEM_CACHE_SSL": "False",
    #         "MEM_CACHE_CONN_MODE": "cluster",
    #     }.get(k, d)
    #     mock_get_secret.return_value = {"kms_key_id": "your_key_id", "user": "test_user", "password": "test_password"}
    #     mock_redis_cluster.return_value = MagicMock()
    #     mock_kms_crypto.return_value = "Success"

    #     RedisCache.init()

    #     mock_redis_cluster.assert_called_once_with(host="localhost", port="6379", max_connections=10, socket_timeout=0.300, socket_connect_timeout=0.300, socket_keepalive=True, username="test_user", password="test_password")
    #     self.assertIsNotNone(RedisCache.client_response_cache)
    #     self.assertIsNone(RedisCache.pool)

    # @patch("ascendops_commonlib.datastores.redis_util.os.getenv")
    # @patch("ascendops_commonlib.datastores.redis_util.SecretsManagerUtil.get_secret")
    # @patch("ascendops_commonlib.datastores.redis_util.KMSCrypto.init")
    # @patch("ascendops_commonlib.datastores.redis_util.redis.cluster.RedisCluster")
    # def test_redis_cluster_initialization_exception(self, mock_redis_cluster, mock_kms_crypto, mock_get_secret, mock_getenv):
    #     """Test RedisCluster initialization with exception"""

    #     mock_getenv.side_effect = lambda k, d=None: {
    #         "MEM_CACHE_CONN": "localhost:6379",
    #         "MEM_CACHE_SSL": "False",
    #         "MEM_CACHE_CONN_MODE": "cluster",
    #     }.get(k, d)
    #     mock_get_secret.return_value = {"kms_key_id": "your_key_id", "user": "test_user", "password": "test_password"}
    #     mock_redis_cluster.side_effect = Exception("Cluster initialization failed")
    #     mock_kms_crypto.return_value = "Success"

    #     with self.assertRaises(Exception) as context:
    #         RedisCache.init()

    #     self.assertEqual(str(context.exception), "Cluster initialization failed")
    #     mock_redis_cluster.assert_called_once_with(host="localhost", port="6379", max_connections=10, socket_timeout=0.300, socket_connect_timeout=0.300, socket_keepalive=True, username="test_user", password="test_password")
    #     self.assertIsNone(RedisCache.client_response_cache)
    #     self.assertIsNone(RedisCache.pool)

    # @patch("ascendops_commonlib.datastores.redis_util.os.getenv")
    # @patch("ascendops_commonlib.datastores.redis_util.SecretsManagerUtil.get_secret")
    # @patch("ascendops_commonlib.datastores.redis_util.KMSCrypto.init")
    # @patch("ascendops_commonlib.datastores.redis_util.redis.Redis")
    # @patch("ascendops_commonlib.datastores.redis_util.redis.ConnectionPool")
    # def test_warmup(self, mock_connection_pool, mock_redis, mock_kms_init, mock_get_secret, mock_getenv):
    #     """Test warmup method"""

    #     # Mock environment variables and secrets
    #     mock_getenv.side_effect = lambda k, d=None: {"MEM_CACHE_CONN": "localhost:6379", "MEM_CACHE_SSL": "False", "MEM_CACHE_CONN_MODE": None}.get(k, d)
    #     mock_get_secret.return_value = {"user": "test_user", "password": "test_password"}

    #     # Mock Redis methods
    #     mock_redis_instance = MagicMock()
    #     mock_redis.return_value = mock_redis_instance
    #     mock_redis_instance.set.return_value = True
    #     mock_redis_instance.get.return_value = b'{"response":"200"}'

    #     # Initialize RedisCache and call warmup
    #     RedisCache.init()
    #     RedisCache.client_response_cache = mock_redis_instance
    #     RedisCache.warmup()

    #     # Assertions to ensure warmup is called correctly
    #     mock_redis_instance.set.assert_called_once_with("inquiry::bootstrap::warmup", '{"response":"200"}')
    #     mock_redis_instance.get.assert_called_once_with("inquiry::bootstrap::warmup")

    @patch("ascendops_commonlib.datastores.redis_util.RedisCache.set_in_redis")
    @patch("ascendops_commonlib.datastores.redis_util.RedisCache.get_from_redis")
    @patch("ascendops_commonlib.datastores.redis_util.logging.getLogger")
    def test_warmup_success(self, mock_get_logger, mock_get_from_redis, mock_set_in_redis):
        """test warmup with redis cache up and running"""

        mock_set_in_redis.return_value = None
        mock_get_from_redis.return_value = {"response": "200"}
        mock_logger_instance = MagicMock()
        mock_get_logger.return_value = mock_logger_instance

        RedisCache.warmup()

        mock_set_in_redis.assert_called_once_with("inquiry::bootstrap::warmup", {"response": "200"})
        mock_get_from_redis.assert_called_once_with("inquiry::bootstrap::warmup")
        mock_logger_instance.warning.assert_called_with("Redis Cache - warmup success")

    @patch("ascendops_commonlib.datastores.redis_util.RedisCache.set_in_redis")
    @patch("ascendops_commonlib.datastores.redis_util.RedisCache.get_from_redis")
    @patch("ascendops_commonlib.datastores.redis_util.logging.getLogger")
    def test_warmup_failure(self, mock_get_logger, mock_get_from_redis, mock_set_in_redis):
        """test warmup with redis cache throwing error"""

        mock_set_in_redis.side_effect = Exception("Some Error")
        mock_logger_instance = MagicMock()
        mock_get_logger.return_value = mock_logger_instance

        RedisCache.warmup()

        mock_set_in_redis.assert_called_once_with("inquiry::bootstrap::warmup", {"response": "200"})
        mock_get_from_redis.assert_not_called()
        mock_logger_instance.warning.assert_called_with("Redis Cache - warmup failed: %s", "Some Error")

    @patch("ascendops_commonlib.aws_utils.kms_crypto.KMSCrypto.encrypt_dict")
    @patch("ascendops_commonlib.datastores.redis_util.time.time")
    @patch("ascendops_commonlib.datastores.redis_util.logging.getLogger")
    @patch("ascendops_commonlib.datastores.redis_util.RedisCache.client_response_cache")
    def test_set_in_redis_success(self, mock_client_response_cache, mock_logger, mock_time, mock_encrypt_dict):
        """test set_in_redis method using mock encrypted value
        and redis cache is up and running"""

        mock_encrypt_dict.return_value = "encrypted_data"
        mock_logger_instance = MagicMock(spec=Logger)
        mock_logger.return_value = mock_logger_instance
        mock_time.side_effect = [0, 1]
        mock_client_response_cache.set.side_effect = "Success"

        key = "test_key"
        doc = {"test_key": "test_data"}
        ttl_in_sec = 10

        RedisCache().set_in_redis(key, doc, ttl_in_sec, mock_logger_instance)

        mock_encrypt_dict.assert_called_once_with(doc, mock_logger_instance)
        mock_logger_instance.debug.assert_called_once_with("adding into cache %s %d", key, len("encrypted_data"))
        mock_logger_instance.info.assert_called_once_with("timetaken to set in redis:%s", 1)
        mock_client_response_cache.set.assert_called_once_with(key, "encrypted_data", ex=ttl_in_sec)

    @patch("ascendops_commonlib.aws_utils.kms_crypto.KMSCrypto.encrypt_dict")
    @patch("ascendops_commonlib.datastores.redis_util.logging.getLogger")
    def test_set_in_redis_exception(self, mock_logger, mock_encrypt_dict):
        """test set_in_redis method mock encryption failed"""

        mock_encrypt_dict.side_effect = Exception("Encryption failed")
        mock_logger_instance = MagicMock(spec=Logger)
        mock_logger.return_value = mock_logger_instance

        key = "test_key"
        doc = {"data": "test_data"}
        ttl_in_sec = 10

        with self.assertRaises(RedisCache.MemCacheException) as context:
            RedisCache.set_in_redis(key, doc, ttl_in_sec, mock_logger_instance)

        self.assertEqual(str(context.exception), "failed to cache:Encryption failed")
        mock_encrypt_dict.assert_called_once_with(doc, mock_logger_instance)
        mock_logger_instance.debug.assert_not_called()
        mock_logger_instance.info.assert_not_called()
        RedisCache.client_response_cache.set.assert_not_called()

    @patch("ascendops_commonlib.aws_utils.kms_crypto.KMSCrypto.decrypt_dict")
    @patch("ascendops_commonlib.datastores.redis_util.time.time")
    @patch("ascendops_commonlib.datastores.redis_util.logging.getLogger")
    @patch("ascendops_commonlib.datastores.redis_util.RedisCache.client_response_cache")
    def test_get_from_redis_success(self, mock_client_response_cache, mock_logger, mock_time, mock_decrypt_dict):
        """test get_from_redis method uses return value from redis cache and decrypt it"""

        mock_decrypt_dict.return_value = {"data": "test_data"}
        mock_logger_instance = MagicMock(spec=Logger)
        mock_logger.return_value = mock_logger_instance
        mock_time.side_effect = [0, 1]
        mock_client_response_cache.get.return_value = "encrypted_data"
        key = "test_key"

        result = RedisCache.get_from_redis(key, mock_logger_instance)

        mock_time.assert_called()
        mock_client_response_cache.get.assert_called_once_with(key)
        mock_decrypt_dict.assert_called_once_with("encrypted_data")
        mock_logger_instance.info.assert_called_once_with("timetaken to get from redis:%s", 1)
        self.assertEqual(result, {"data": "test_data"})

    @patch("ascendops_commonlib.datastores.redis_util.time.time")
    @patch("ascendops_commonlib.datastores.redis_util.logging.getLogger")
    @patch("ascendops_commonlib.datastores.redis_util.RedisCache.client_response_cache")
    def test_get_from_redis_exception(self, mock_client_response_cache, mock_logger, mock_time):
        """test get_from_redis with redis cache throwing exception"""

        mock_logger_instance = MagicMock(spec=Logger)
        mock_logger.return_value = mock_logger_instance
        mock_time.side_effect = [0, 1]
        key = "test_key"
        mock_client_response_cache.get.side_effect = Exception("Cache read failed")

        with self.assertRaises(RedisCache.MemCacheException) as context:
            RedisCache.get_from_redis(key, mock_logger_instance)

        self.assertEqual(str(context.exception), "failed while reading from cache:Cache read failed")
        mock_time.assert_called()
        mock_client_response_cache.get.assert_called_once_with(key)
        mock_logger_instance.info.assert_not_called()

        RedisCache.client_response_cache = None

        with self.assertRaises(RedisCache.MemCacheException) as context:
            RedisCache.get_from_redis(key, mock_logger_instance)

        self.assertEqual(str(context.exception), "failed while reading from cache:failed while reading from cache: client not initialized")
