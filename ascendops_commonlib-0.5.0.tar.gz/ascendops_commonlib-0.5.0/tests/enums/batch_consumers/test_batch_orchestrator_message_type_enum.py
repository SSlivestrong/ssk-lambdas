""" Unit tests for BatchOrchestratorMessageTypeEnum """

import unittest
import json
from ascendops_commonlib.enums.batch_consumers.batch_orchestrator_message_type_enum import (
    BatchOrchestratorMessageTypeEnum,
)


class TestBatchOrchestratorMessageTypeEnum(unittest.TestCase):
    """Unit tests for BatchOrchestratorMessageTypeEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(
            BatchOrchestratorMessageTypeEnum("start"), BatchOrchestratorMessageTypeEnum.START
        )
        self.assertEqual(
            BatchOrchestratorMessageTypeEnum("exec-end"), BatchOrchestratorMessageTypeEnum.EXEC_END
        )


    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(BatchOrchestratorMessageTypeEnum.START.value, "start")
        self.assertEqual(BatchOrchestratorMessageTypeEnum.EXEC_END.value, "exec-end")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(
            BatchOrchestratorMessageTypeEnum.START, BatchOrchestratorMessageTypeEnum["START"]
        )
        self.assertEqual(
            BatchOrchestratorMessageTypeEnum.EXEC_END, BatchOrchestratorMessageTypeEnum["EXEC_END"]
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(
            json.dumps(BatchOrchestratorMessageTypeEnum.START), '"start"'
        )
        self.assertEqual(json.dumps(BatchOrchestratorMessageTypeEnum.EXEC_END), '"exec-end"')
