""" Unit tests for ModelExecutionTypeEnum """

import unittest
import json
from ascendops_commonlib.enums.client_contract.model_execution_type_enum import (
    ModelExecutionTypeModeEnum,
)


class TestModelExecutionTypeEnum(unittest.TestCase):
    """Unit tests for ModelExecutionTypeEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(
            ModelExecutionTypeModeEnum("batch"),
            ModelExecutionTypeModeEnum.BATCH,
        )
        self.assertEqual(
            ModelExecutionTypeModeEnum("batch-and-realtime"),
            ModelExecutionTypeModeEnum.REALTIME_AND_BATCH,
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(ModelExecutionTypeModeEnum.BATCH.value, "batch")
        self.assertEqual(
            ModelExecutionTypeModeEnum.REALTIME_AND_BATCH.value, "batch-and-realtime"
        )

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(
            ModelExecutionTypeModeEnum.BATCH,
            ModelExecutionTypeModeEnum["BATCH"],
        )
        self.assertEqual(
            ModelExecutionTypeModeEnum.REALTIME_AND_BATCH,
            ModelExecutionTypeModeEnum["REALTIME_AND_BATCH"],
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(ModelExecutionTypeModeEnum.BATCH), '"batch"')
        self.assertEqual(
            json.dumps(ModelExecutionTypeModeEnum.REALTIME_AND_BATCH),
            '"batch-and-realtime"',
        )
