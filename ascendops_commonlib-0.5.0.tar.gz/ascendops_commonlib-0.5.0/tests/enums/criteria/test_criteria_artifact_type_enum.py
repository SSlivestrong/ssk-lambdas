""" Unit tests for CriteriaArtifactTypeEnum """

import unittest
import json
from ascendops_commonlib.enums.criteria.criteria_artifact_type_enum import (
    CriteriaArtifactTypeEnum,
)


class TestCriteriaArtifactTypeEnum(unittest.TestCase):
    """Unit tests for CriteriaArtifactEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(
            CriteriaArtifactTypeEnum("attributes"), CriteriaArtifactTypeEnum.ATTRIBUTES
        )
        self.assertEqual(
            CriteriaArtifactTypeEnum("pickle"), CriteriaArtifactTypeEnum.PICKLE
        )
        self.assertEqual(
            CriteriaArtifactTypeEnum("pickle_rt"), CriteriaArtifactTypeEnum.PICKLE_RT
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(CriteriaArtifactTypeEnum.ATTRIBUTES.value, "attributes")
        self.assertEqual(CriteriaArtifactTypeEnum.PICKLE.value, "pickle")
        self.assertEqual(CriteriaArtifactTypeEnum.PICKLE_RT.value, "pickle_rt")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(
            CriteriaArtifactTypeEnum.ATTRIBUTES, CriteriaArtifactTypeEnum["ATTRIBUTES"]
        )
        self.assertEqual(
            CriteriaArtifactTypeEnum.PICKLE, CriteriaArtifactTypeEnum["PICKLE"]
        )
        self.assertEqual(
            CriteriaArtifactTypeEnum.PICKLE_RT, CriteriaArtifactTypeEnum["PICKLE_RT"]
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(
            json.dumps(CriteriaArtifactTypeEnum.ATTRIBUTES), '"attributes"'
        )
        self.assertEqual(json.dumps(CriteriaArtifactTypeEnum.PICKLE), '"pickle"')
        self.assertEqual(json.dumps(CriteriaArtifactTypeEnum.PICKLE_RT), '"pickle_rt"')
