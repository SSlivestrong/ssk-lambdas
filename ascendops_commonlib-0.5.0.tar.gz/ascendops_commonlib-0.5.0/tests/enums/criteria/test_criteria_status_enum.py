""" Unit tests for CriteriaStatusEnum """

import unittest
import json
from ascendops_commonlib.enums.criteria.criteria_status_enum import CriteriaStatusEnum


class TestCriteriaStatusEnum(unittest.TestCase):
    """Unit tests for CriteriaStatusEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(CriteriaStatusEnum("active"), CriteriaStatusEnum.ACTIVE)
        self.assertEqual(CriteriaStatusEnum("test"), CriteriaStatusEnum.TEST)
        self.assertEqual(CriteriaStatusEnum("draft"), CriteriaStatusEnum.DRAFT)

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(CriteriaStatusEnum.ACTIVE.value, "active")
        self.assertEqual(CriteriaStatusEnum.TEST.value, "test")
        self.assertEqual(CriteriaStatusEnum.DRAFT.value, "draft")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(CriteriaStatusEnum.ACTIVE, CriteriaStatusEnum["ACTIVE"])
        self.assertEqual(CriteriaStatusEnum.TEST, CriteriaStatusEnum["TEST"])
        self.assertEqual(CriteriaStatusEnum.DRAFT, CriteriaStatusEnum["DRAFT"])

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(CriteriaStatusEnum.ACTIVE), '"active"')
        self.assertEqual(json.dumps(CriteriaStatusEnum.TEST), '"test"')
        self.assertEqual(json.dumps(CriteriaStatusEnum.DRAFT), '"draft"')
