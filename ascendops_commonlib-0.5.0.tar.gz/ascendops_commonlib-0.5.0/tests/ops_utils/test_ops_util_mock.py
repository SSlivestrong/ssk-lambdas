"""
mock test module for app_util module
"""

import time
import unittest
# from freezegun import freeze_time

from ascendops_commonlib.ops_utils import ops_util


class TestGetEpochMillis(unittest.TestCase):
    """Class to test get_epoch_millis method"""

    def test_get_epoch_millis(self):
        """
        Test case for the get_epoch_millis function.

        This test verifies that the get_epoch_millis function returns the current epoch time in milliseconds.
        It compares the result with the current time and allows a difference of up to 1 millisecond due to the time it takes to call the function.
        """
        # Get the current epoch time in milliseconds
        current_millis = round(time.time() * 1000)

        # Call the function
        result_millis = ops_util.get_epoch_millis()

        # The result should be very close to the current time
        # We allow a difference of up to 1 millisecond due to the time it takes to call the function
        self.assertTrue(abs(result_millis - current_millis) <= 1)
