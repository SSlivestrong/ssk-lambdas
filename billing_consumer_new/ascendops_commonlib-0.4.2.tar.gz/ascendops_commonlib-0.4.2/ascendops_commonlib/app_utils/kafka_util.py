"""
All AWS MSK - Kafka related stuffs
"""

import logging
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.aws_utils import s3_util
from ascendops_commonlib.aws_utils.secrets_manager_util import SecretsManagerUtil

log = logging.getLogger("ascendopscommon")

class KafkaWriter():
    """This will be translate to memcached"""
    KAFKA_PARAMS = {"security_protocol": ops_config.SECURITY_PROTOCOL}

    @staticmethod
    def on_app_start():
        """Call only one time"""   
        if ops_config.SECURITY_PROTOCOL == "SSL":
            try:
                KafkaWriter.KAFKA_PARAMS.update(KafkaWriter.get_kafka_params()) 
                log.warning("kafka parameters set")
            except Exception as xcp:
                log.error("KafkaWriter startup Error: %s", str(xcp))

    @staticmethod
    def get_kafka_params():
        """To retrieve PEM files from S3, and password from Secret Manger.
        An application MUST be aware to avoid calling this multiple times.
        """
        s3_util.download_pem_files()
        return  {
            "private_key_pwd": KafkaWriter.retrieve_password(),
            "cafile_path": s3_util.CACERT_LOCAL_PATH,        
            "certfile_path": s3_util.PUBLIC_CERT_LOCAL_PATH,
            "keyfile_path": s3_util.PRIVATE_KEY_LOCAL_PATH
        }
    
    @staticmethod
    def retrieve_password():
        """ To retrieve password from Secret Manager """
        try:
            secrets_util = SecretsManagerUtil()
            msk_secret = secrets_util.get_secret(f"{ops_config.SECRETS_ENV}-msk-config")
            msk_password = msk_secret["private_key_password"]
            return msk_password
        except Exception as xcp:
            log.error("Error retrieving msk password: %s", str(xcp))
