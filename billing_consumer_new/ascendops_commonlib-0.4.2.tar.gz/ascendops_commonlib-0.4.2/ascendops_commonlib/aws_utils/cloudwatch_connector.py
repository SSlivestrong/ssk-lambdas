""" Connects to cloudwatch - wrapper around boto3 cloudwatch client """
import logging
from typing import Optional
from ascendops_commonlib.aws_utils.aws_client_util import STSClientUtil

log = logging.getLogger("ascendopscommon")


class CloudwatchConnector:
    """Connects to cloudwatch - wrapper around boto3 cloudwatch client"""

    def __init__(self, role_arn: Optional[str] = None):
        """creates boto3 sagemaker client
        Params:
            role_arn - optional role to assume when connecting to cloudwatch
        """

        sts_client = STSClientUtil()
        self.cloudwatch_client = sts_client.get_client("cloudwatch", role_arn=role_arn)

    def describe_alarms(self, alarm_names: "list[str]") -> dict:
        """Describe alarms details
        Params:
            alarm_names - list of alarm names that indicate which logs should be deleted
        Returns:
            dict - see boto3 describe alarms documentation
        """
        return self.cloudwatch_client.describe_alarms(AlarmNames=alarm_names)

    def delete_alarms(self, alarm_names: "list[str]") -> None:
        """Deletes alarms
        Params:
            alarm_names - list of alarm names that indicate which alarms should be deleted
        Returns:
            None
        """
        self.cloudwatch_client.delete_alarms(AlarmNames=alarm_names)
        log.info("Deleted alarms: %s", alarm_names)
