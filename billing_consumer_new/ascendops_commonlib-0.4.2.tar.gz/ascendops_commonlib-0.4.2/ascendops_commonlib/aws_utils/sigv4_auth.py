import json
from datetime import datetime, timezone
import hashlib
import hmac
from ascendops_commonlib.ops_utils import ops_config


class SigV4Auth:

    def __init__(self) -> None:
        pass

    @staticmethod
    def get_auth_header_amz_date(credentials, algorithm, canonical_uri="", payload="", canonical_querystring = "", http_method="POST", host="", service=""):
        """ returns sigv4 Auth header """

        x_amz_datetime = SigV4Auth.generate_x_amz_datetime()
        signing_key = SigV4Auth.set_signing_key(credentials, x_amz_datetime, service)
        authorization_header = SigV4Auth.create_authorization_header(
            x_amz_datetime,
            signing_key,
            credentials,
            algorithm,
            canonical_uri,
            payload,
            canonical_querystring,
            host,
            http_method,
            service
        )
        return authorization_header, x_amz_datetime

    @staticmethod
    def generate_x_amz_datetime():
        return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    @staticmethod
    def sign(key, msg):
        return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

    @staticmethod
    def set_signing_key(credentials, x_amz_datetime, service):
        date_key = SigV4Auth.sign(("AWS4" + credentials.secret_key).encode("utf-8"), x_amz_datetime[:8])
        region_key = SigV4Auth.sign(date_key, ops_config.DEFAULT_REGION)
        service_key = SigV4Auth.sign(region_key, service)
        signing_key = SigV4Auth.sign(service_key, "aws4_request")
        return signing_key

    @staticmethod
    def create_authorization_header(x_amz_datetime, signing_key, credentials, algorithm, canonical_uri, payload, canonical_querystring, host, http_method, service):
        canonical_headers = "host:" + host + "\n" + "x-amz-date:" + x_amz_datetime + "\n"
        signed_headers = "host;x-amz-date"
        payload_hash = hashlib.sha256(json.dumps(payload).encode("utf-8")).hexdigest()

        canonical_request = f"{http_method}\n{canonical_uri}\n{canonical_querystring}\n{canonical_headers}\n{signed_headers}\n{payload_hash}"
        credential_scope = f"{x_amz_datetime[:8]}/{ops_config.DEFAULT_REGION}/{service}/aws4_request"
        string_to_sign = f"{algorithm}\n{x_amz_datetime}\n{credential_scope}\n{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"

        signature = hmac.new(signing_key, (string_to_sign).encode("utf-8"), hashlib.sha256).hexdigest()

        authorization_header = f"{algorithm} Credential={credentials.access_key}/{credential_scope}, SignedHeaders={signed_headers}, Signature={signature}"
        return authorization_header
