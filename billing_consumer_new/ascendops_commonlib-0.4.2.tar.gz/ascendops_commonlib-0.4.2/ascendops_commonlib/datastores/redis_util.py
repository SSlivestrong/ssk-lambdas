from logging import Logger
import logging
import stat
from ascendops_commonlib.aws_utils.kms_crypto import KMSCrypto
from ascendops_commonlib.aws_utils.secrets_manager_util import SecretsManagerUtil
from ascendops_commonlib.ops_utils import ops_config
import time, os
import redis
from redis.cluster import RedisCluster


class RedisCache:
    
    client_response_cache = None
    pool = None
    
    def __init__(self) -> None:
        pass

    @staticmethod
    def init() -> None:
        """ Initialize the Redis Cache """
        if os.getenv("MEM_CACHE_CONN"):
            secrets_util = SecretsManagerUtil()
            mem_cache_config = secrets_util.get_secret(f"{ops_config.SECRETS_ENV}-mem-cache-config")
            mem_cache_params = {
                "host": os.getenv("MEM_CACHE_CONN", "localhost:6379").split(":")[0],
                "port": os.getenv("MEM_CACHE_CONN", "localhost:6379").split(":")[1],
                "db": 0,
                "kms_key_id": mem_cache_config.get("kms_key_id", "") if mem_cache_config else "",
                "max_connections": 10,
                "socket_timeout": 0.300,
                "socket_connect_timeout": 0.300,
                "retry_on_timeout": 3,
                "socket_keepalive": True,
                "ssl": os.getenv("MEM_CACHE_SSL", "False") == "True",
                "mode": os.getenv("MEM_CACHE_CONN_MODE", None)
            }
            if ops_config.IS_AWS is True:
                mem_cache_params["username"] =  mem_cache_config.get("user", "") if mem_cache_config else ""
                mem_cache_params["password"] = mem_cache_config.get("password", "") if mem_cache_config else ""

            KMSCrypto.init(mem_cache_params.pop("kms_key_id"))
            mode = mem_cache_params.pop("mode", None)
            if mode and mode == "cluster":
                mem_cache_params.pop("db", None)
                mem_cache_params.pop("retry_on_timeout", None)
                try:
                    RedisCache.client_response_cache = RedisCluster(**mem_cache_params)
                except Exception as exp:
                    if ops_config.IS_AWS is True:
                        raise exp
            else:
                mem_cache_params.pop("ssl", None)
                RedisCache.pool = redis.ConnectionPool(**mem_cache_params)
                RedisCache.client_response_cache = redis.Redis(connection_pool=RedisCache.pool)
            
            RedisCache.warmup()
    
    class MemCacheException(Exception):
        pass
    
    @staticmethod
    def warmup():
        log = logging.getLogger("WARMUP")
        try:
            RedisCache.set_in_redis("inquiry::bootstrap::warmup", {"response":"200"})
            RedisCache.get_from_redis("inquiry::bootstrap::warmup")
            log.warning("Redis Cache - warmup success")
        except Exception as exp:
            log.warning("Redis Cache - warmup failed: %s", str(exp))

    @staticmethod
    def set_in_redis(key: str, doc: dict, ttl_in_sec: float = None, logger: Logger = None):
        """ Set the value in Redis Cache """
        try:
            enc = KMSCrypto.encrypt_dict(doc, logger)
            if logger:
                logger.debug("adding into cache %s %d", key, len(enc))

            st = time.time()
            RedisCache.client_response_cache.set(key, enc, ex=ttl_in_sec)
            if logger:
                logger.info("timetaken to set in redis:%s", time.time() -st)
        except Exception as exp:
            raise RedisCache.MemCacheException("failed to cache:" + str(exp))

    @staticmethod
    def get_from_redis(key: str, logger: Logger = None) -> dict:
        """ Get the value from Redis Cache """
        try:
            st = time.time()
            if RedisCache.client_response_cache:
                enc = RedisCache.client_response_cache.get(key)
                doc = KMSCrypto.decrypt_dict(enc) if enc else None
                if logger:
                    logger.info("timetaken to get from redis:%s", time.time() -st)
                return doc
            else:
                raise RedisCache.MemCacheException("failed while reading from cache: client not initialized")
        except Exception as exp:
            raise RedisCache.MemCacheException("failed while reading from cache:" + str(exp))
