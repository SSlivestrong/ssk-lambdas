""" Entity to represent Solution source """
from typing import Optional
from opensearch_dsl import Text, Keyword, Boolean, InnerDoc, Object, MetaField

from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.entities.opensearch.fields.na_enum_opensearch_field import (
    NAEnumOpensearchField,
)
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.enums.datasource.datasource_type_enum import DatasourceTypeEnum


class DatasourceField(InnerDoc):
    """Defines datasource field details"""

    field_name: Optional[str] = Keyword()
    field_type: Optional[str] = Keyword()
    default_value: Optional[str] = Keyword()
    is_multi: Optional[bool] = Boolean()
    is_mandatory: Optional[bool] = Boolean()
    env_flag: Optional[bool] = Boolean()
    values: Optional["list[str]"] = Text(multi=True)


class Datasource(NABaseDocument):
    """Opensearch Entity to represent datasource entity"""

    name: Optional[str] = Keyword()
    description: Optional[str] = Text()
    datasource_fields: Optional[DatasourceField] = Object(DatasourceField)
    datasource_type: Optional[DatasourceTypeEnum] = NAEnumOpensearchField(
        DatasourceTypeEnum
    )

    def update_from_dict(self, dictionary: dict) -> None:
        """updates datasource properties from a dictionary"""

        if "description" in dictionary:
            self.description = dictionary.get("description")

        if "datasource_fields" in dictionary:
            self.datasource_fields = dictionary.get("datasource_fields")

        if "datasource_type" in dictionary:
            self.datasource_type = dictionary.get("datasource_type")

        super().update_from_dict(dictionary)

    class Index:
        """Opensearch Index where solution documents are stored"""

        name: str = ops_config.DATASOURCE_INDEX_NAME

    class Meta:
        """Defines properties for Opensearch Mapping"""

        # overrides default dynamic value
        # controls whether new fields are added dynamically to index mapping
        dynamic: MetaField = MetaField("true")
