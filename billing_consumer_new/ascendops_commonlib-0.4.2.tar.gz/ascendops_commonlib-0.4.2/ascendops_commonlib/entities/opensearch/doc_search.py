""" DocSearch for any operations search object  """
from opensearch_dsl import Search

from ascendops_commonlib.enums.general.order_by_enum import OrderByEnum


class DocSearch(Search):
    """DocSearch for any operations search object"""

    @classmethod
    def search(cls, doc):
        return DocSearch(index=doc.Index.name, doc_type=[doc])

    def filter_term(self, field, value):
        return self.filter("term", **{field: value})

    def query_term(self, field, value):
        return self.query("term", **{field: value})

    def query_terms(self, field, values):
        return self.query("terms", **{field: values})

    def search_doc(self, search_fields, search_str, partial_match=False):
        match = "multi_match"
        if partial_match:
            match = "query_string"
            search_str = "*" + search_str + "*"
        return self.query(match, query=search_str, fields=search_fields)

    def sort_doc(self, sort_field, sort_order=OrderByEnum.ASC):
        if sort_order == OrderByEnum.DESC:
            sort_field = "-" + sort_field
        return self.sort(sort_field)

    def search_sort_doc(self, **kwargs):
        sort_order = kwargs.get("sort_order", OrderByEnum.ASC)
        sort_field = kwargs.get("sort_field", None)
        search_str = kwargs.get("search_str", None)
        search_fields = kwargs.get("search_fields", None)
        partial_match = kwargs.get("partial_match", False)

        search = self

        if search_str and search_fields:
            search = search.search_doc(
                search_fields=search_fields,
                search_str=search_str,
                partial_match=partial_match,
            )

        if sort_field:
            search = search.sort_doc(sort_field, sort_order)

        return search

    def get_page(self, page_number, page_size):
        """gets page results according to  no. of items in a page and page no. requested"""

        # Calculate total number of items
        total_items = self.count()
        if total_items <= 0:
            return self

        # Calculate total number of pages
        total_pages = (total_items + page_size - 1) // page_size

        if 1 <= page_number <= total_pages:
            start_index = (page_number - 1) * page_size
            end_index = page_number * page_size
            page_data = self[start_index:end_index]
        else:
            raise Exception("Invalid page number and page size.")

        return page_data
