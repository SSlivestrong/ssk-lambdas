"""
    Entity describing a configuration document for a variety of types of configuration
"""
from typing import Optional
from opensearch_dsl import Object

from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.entities.opensearch.fields.na_enum_opensearch_field import (
    NAEnumOpensearchField,
)

from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.enums.solution.solution_config_type_enum import (
    SolutionConfigTypeEnum,
)


class SolutionConfiguration(NABaseDocument):
    """Entity describing a configuration document for a variety of types of configuration"""

    # type of configuration
    config_type: Optional[SolutionConfigTypeEnum] = NAEnumOpensearchField(
        SolutionConfigTypeEnum
    )
    # where specific configuration is stored
    # each can have its own schema
    # runtime allows query during runtime of the contents of config
    # NOTE: with dynamic as false, will not be able to query upon contents
    config: Optional[dict] = Object(dynamic=False)

    class Index:
        """index storing all app configurations"""

        name: str = ops_config.SOLUTION_CONFIGURATION_INDEX_NAME
