""" Enum that defines the execution type """
from enum import Enum, unique


@unique
# Inherits from str as well so that enum is json serializable
class ModelExecutionTypeModeEnum(str, Enum):
    """defines available execution types"""

    # synchronously executes a model
    REALTIME_AND_BATCH: str = "batch-and-realtime"
    # asynchronously executes a model
    BATCH: str = "batch"
