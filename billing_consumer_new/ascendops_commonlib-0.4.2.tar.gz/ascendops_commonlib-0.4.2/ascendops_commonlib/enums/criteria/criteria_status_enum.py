""" Enum to define criteria lifecycle status """

from enum import Enum, unique


@unique
class CriteriaStatusEnum(str, Enum):
    """Enum to define criteria status"""

    # criteria is available for testing
    TEST: str = "test"
    # criteria is available for execution in production
    ACTIVE: str = "active"
    # criteria has been created but not available for testing
    DRAFT: str = "draft"
