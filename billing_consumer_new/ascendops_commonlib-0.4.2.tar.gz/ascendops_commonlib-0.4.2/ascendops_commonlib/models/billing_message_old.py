
""" billing message object model """
from typing import List, Optional, Union
from pydantic import BaseModel

class Name(BaseModel):
    """ Consumer Name object """
    last_name: str
    first_name: str
    middle_name: Union[str, None] = None
    generation_code: Union[str, None] = None
    prefix: Union[str, None] = None


class License(BaseModel):
    """ License object """
    number: Union[str, None] = None
    state: Union[str, None] = None


class SecondaryId(BaseModel):
    """ Secondary ID object """
    type: str
    value: str
    region: Union[str, None] = None
    country: Union[str, None] = None
    expiration: Union[str, None] = None


class Phone(BaseModel):
    """ Phone object """
    number: str
    type: Union[str, None] = None


class Address(BaseModel):
    """ Address object """
    line1: str
    line2: Union[str, None] = None
    city: Union[str, None] = None
    state: Union[str, None] = None
    zip_code: Union[str, None] = None
    country: Union[str, None] = None


class Employment(BaseModel):
    """ Employment object """
    employer_name: str
    employer_address: Union[Address, None] = None


class ApplicantPII(BaseModel):
    """ Primary Applicant object """
    name: Name
    dob: Union[str, None] = None
    ssn: Union[str, None] = None
    ein: Union[str, None] = None
    tin: Union[str, None] = None
    driverslicense: Union[License, None] = None
    secondary_id: Union[SecondaryId, None] = None
    phone: Union[List[Phone], None] = None
    email_id: Union[str, None] = None
    employment: Union[Employment, None] = None
    current_address: Union[Address, None] = None
    previous_address: Union[List[Address], None] = None
    inquiry_address: Union[Address, None] = None
    epin: Union[str, None] = None 


class BillingCodes(BaseModel):
    productCode: str
    index: str

class BillingMessage(BaseModel):
    transaction_id: str
    solution_id: str
    subcode: str
    client_id: str = ""
    arf_version: str
    is_silent_launch_enabled: Optional[bool] = False
    product_codes: List[BillingCodes]
    applicant_pii: ApplicantPII
    end_date: Optional[int] = None