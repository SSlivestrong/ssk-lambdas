log_templates = {

    "app_startup": {},

    "message": {
        "inquiry": {
            "event_type": "GoInquiryCost",
            "request_timestamp": None,
            "response_timestamp": None,
            "latency": None,
            "systems": [],
            "success": True
        },
        "model_calculation": {
            "go_txn_id": "",
            "solution_id": "",
            "request_timestamp": None,
            "response_timestamp": None,
            "latency": None,
            "client_app_id": "",
            "client_id": "",
            "subcode": "",
            "success": True
        }
    },

    "cw_tags": {
        "inquiry": {
            "go_txn_id": "",
            "solution_id": "",
            "client_app_id": "",
            "client_id": "",
            "subcode": "",
            "client_txn_id": "",
            "experian_txn_id": ""
        }
    },

    "system": {
        "service_name": "", # CCR, CLARITY, ATB
        "system_txn_id": None,
        "status": None,
        "latency": None,
        "event_type": "EXTERNAL_CALL",
        "exception": ""
    },

    "sagemaker": {
        "id": "", # model_uid
        "service_name": "SAGEMAKER",
        "status": None,
        "latency": None,
        "event_type": "EXTERNAL_CALL",
        "endpoint_name": "",
        "attempt": 1,
        "exception": ""
    },

    "redis": {
        "method": "GET", # GET/SET
        "cache_txn_id_key": "",
        "cached_keys": [],
        "success": True,
        "latency": None,
        "service_name": "REDIS",
        "event_type": "EXTERNAL_CALL",
        "attempt": 1,
        "exception": ""
    },

    "elasticsearch": {
        "service_name": "ELASTICSEARCH",
        "event_type": "EXT_CONNECTION",
        "event_priority": None,
        "transaction_id": "",
        "file_name": "",
        "caller_method": "",
        "call_stack": "",
        "ltime": ""
    }

}