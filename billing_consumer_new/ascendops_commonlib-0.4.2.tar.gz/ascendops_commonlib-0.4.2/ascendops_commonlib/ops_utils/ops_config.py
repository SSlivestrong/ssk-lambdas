""" list all the common constants """
import os

# AWS common constants
IAM_PROFILE = os.getenv("IAM_PROFILE", None)
DEFAULT_REGION = os.getenv("DEFAULT_REGION", "us-east-1")
RUNTIME_ENV = os.getenv("RUNTIME_ENV", "uat")
IS_AWS = False if IAM_PROFILE else True
SECRETS_ENV = os.getenv("SECRETS_ENV", "uat")
SIGV4_ALGORITHM = "AWS4-HMAC-SHA256"
AWS_ACCOUNT = os.getenv("AWS_ACCOUNT")

# Services
AWS_SERVICE_DDB = "dynamodb"
AWS_SERVICE_ES = "es"
SUBSCRIBER_INFO_BASE_URL = os.getenv("SUBSCRIBER_INFO_BASE_URL", "")

# ES Service
DEFAULT_ES_HOST = os.getenv(
    "DEFAULT_ES_HOST",
    "vpc-ascend-go-eef5s7znpmxkto5mf7w7huwdni.us-east-1.es.amazonaws.com",
)
DEFAULT_ES_PORT = os.getenv("DEFAULT_ES_PORT", "443")
DEFAULT_ES_ROLE = os.getenv(
    "DEFAULT_ES_ROLE", "arn:aws:iam::994075455914:role/dev-es-role"
)
DEFAULT_ES_SNIFFER_TIMEOUT = int(os.getenv("ES_SNIFFER_TIMEOUT", "3600"))

# Environment Variables
APP_DIR = os.getenv("APP_DIR", "/Users/c74745a/tmp")
LOG_LEVEL = int(os.getenv("LOG_LEVEL", "20"))

# ElasticSearch indices
MODEL_INDEX_NAME = os.getenv("MODEL_INDEX_NAME", "model_v11")
MODEL_CODE_INDEX_NAME = os.getenv("MODEL_CODE_INDEX_NAME", "model_code")
SOLUTION_INDEX_NAME = os.getenv("SOLUTION_INDEX_NAME", "solution")
SOLUTION_CONFIGURATION_INDEX_NAME = os.getenv(
    "SOLUTION_CONFIGURATION_INDEX_NAME", "solution_configuration"
)
SOLUTION_TEST_HISTORY_INDEX_NAME = os.getenv(
    "SOLUTION_TEST_HISTORY_INDEX_NAME", "solution_test_history"
)
SOLUTION_TEST_CASE_CONFIG_INDEX_NAME = os.getenv(
    "SOLUTION_TEST_CASE_CONFIG_INDEX_NAME", "solution_test_case_config"
)
SOLUTION_TEST_SUITE_CONFIG_INDEX_NAME = os.getenv(
    "SOLUTION_TEST_SUITE_CONFIG_INDEX_NAME", "solution_test_suite_config"
)
SOLUTION_XREF_INDEX_NAME = os.getenv("SOLUTION_XREF_INDEX_NAME", "solution_xref")
FEATURE_INDEX_NAME = os.getenv("FEATURE_INDEX_NAME", "feature")
DATASET_INDEX_NAME = os.getenv("DATASET_INDEX_NAME", "dataset")
CLIENT_INDEX_NAME = os.getenv("CLIENT_INDEX_NAME", "client")
SUBCODE_INDEX_NAME = os.getenv("SUBCODE_INDEX_NAME", "subcode")
PRODUCT_CODE_INDEX_NAME = os.getenv("PRODUCT_CODE_INDEX_NAME", "product_code")
CRITERIA_INDEX_NAME = os.getenv("CRITERIA_INDEX_NAME", "criteria")
CRITERIA_EXEC_HISTORY_INDEX_NAME = os.getenv(
    "CRITERIA_EXEC_HISTORY_INDEX_NAME", "criteria_execution_history"
)
DECISION_INDEX_NAME = os.getenv("DECISION_INDEX_NAME", "strategy")
CLIENT_CONTRACT_INDEX_NAME = os.getenv("CLIENT_CONTRACT_INDEX_NAME", "client_contract")
REGRESSION_EXECUTION_HISTORY_INDEX_NAME = os.getenv(
    "REGRESSION_EXECUTION_HISTORY_INDEX_NAME", "regression_execution_history"
)
ARF_COMPARISON_EXEC_HISTORY_INDEX_NAME = os.getenv(
    "ARF_COMPARISON_EXEC_HISTORY", "arf_comparison_exec_history"
)
DATASOURCE_INDEX_NAME = os.getenv("DATASOURCE_INDEX_NAME", "datasource")

# Kafka Config
SECURITY_PROTOCOL = os.getenv("SECURITY_PROTOCOL", "local")
MSK_SECRET_NAME = os.getenv("MSK_SECRET_NAME", "uat-batch-transformation-msk")
MSK_CERT_BUCKET_NAME = os.getenv(
    "MSK_CERT_BUCKET_NAME", "uat-experian-us-east-1-262403030294"
)
CACERT_S3_PATH = os.getenv("CACERT_S3_PATH", "certs/cacerts.pem")
PUBLIC_CERT_S3_PATH = os.getenv("PUBLIC_CERT_S3_PATH", "certs/uat-public-cert.pem")
PRIVATE_KEY_S3_PATH = os.getenv("PRIVATE_KEY_S3_PATH", "certs/uat-private-key.pem")
CACERT_FILE_NAME = os.getenv("CACERT_FILE_NAME", "cacerts.pem")
PUBLIC_CERT_FILE_NAME = os.getenv("PUBLIC_CERT_FILE_NAME", "uat-public-cert.pem")
PRIVATE_KEY_FILE_NAME = os.getenv("PRIVATE_KEY_FILE_NAME", "uat-private-key.pem")

NUMBER_OF_MSG_HANDLERS = int(os.getenv("NUMBER_OF_MSG_HANDLERS", "50"))
MSK_BOOTSTRAP_SERVERS = os.getenv("MSK_BOOTSTRAP_SERVERS", "localhost:9092")
MSK_BATCH_TOPIC = os.getenv("MSK_BATCH_TOPIC", "test")
MSK_ERROR_TOPIC = os.getenv("MSK_ERROR_TOPIC", "error")
COMSUMER_POLL_TIMEOUT = int(os.getenv("COMSUMER_POLL_TIMEOUT", "10"))
MAX_POLL_INTERVAL_MS = int(os.getenv("MAX_POLL_INTERVAL_MS", "300000"))
SESSION_TIMEOUT_MS = int(os.getenv("SESSION_TIMEOUT_MS", "10000"))
HEARTBEAT_INTERVAL_MS = int(os.getenv("HEARTBEAT_INTERVAL_MS", "3000"))

# RDS Config
ANALYTICS_RDS_BILLING_TABLE_NAME = os.getenv("ANALYTICS_RDS_BILLING_TABLE_NAME", "silent_billing_history")
ANALYTICS_RDS_DATABASE_SCHEMA = os.getenv("ANALYTICS_RDS_DATABASE_SCHEMA", "uat_analytics")
ANALYTICS_RDS_KEY_NAME = os.getenv("ANALYTICS_RDS_KEY_NAME", "uat-analytics-ops-rw")
ANALYTICS_RDS_DATABASE_USERNAME = os.getenv("ANALYTICS_RDS_DATABASE_USERNAME", "username")
ANALYTICS_RDS_DATABASE_PASSWORD = os.getenv("ANALYTICS_RDS_DATABASE_PASSWORD", "password")
ANALYTICS_RDS_DATABASE_HOST = os.getenv("ANALYTICS_RDS_DATABASE_HOST", "host")
ANALYTICS_RDS_DATABASE_PORT = os.getenv("ANALYTICS_RDS_DATABASE_PORT", "port")
EXTRACT_FILE_BUCKET_NAME = os.getenv("EXTRACT_FILE_BUCKET_NAME", "s3://uat-experian-us-east-1-262403030294")
EXTRACT_FILE_BUCKET_PREFIX = os.getenv("EXTRACT_FILE_BUCKET_PREFIX", "testcheck/C17780E/testunitprice/extract.csv")

# Regression Test Suite Config
RTS_HEADER = "Test-Engine"
RTS_RECORD_KEY = "record_case_code"
RTS_REPLAY_KEY = "replay_testcase_id"
RTS_RECORD_LOG = "Record"
RTS_REPLAY_LOG = "Replay"