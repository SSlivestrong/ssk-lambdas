"""
    Performs operations related to solution configurations
"""
from ascendops_commonlib.entities.opensearch.arf_comparison_exec_history import (
    ArfComparisonExecHistory,
)


def opensearch_get_arf_comparison_exec_histories(
    **kwargs,
) -> list["ArfComparisonExecHistory"]:
    """Gets arf comparison execution details for a solution

    Parameters
        include_fields - Optional[list[str]]: document fields to include in returned document
        exclude_fields - Optional[list[str]]: document fields to exclude in returned document
    Returns:
        list of arf comparison execution for a solution

    """
    uid = kwargs.get("uid")
    solution_date = kwargs.get("solution_date")
    solution_id = kwargs.get("solution_id")
    status = kwargs.get("status")
    include_fields = kwargs.get("include_fields")
    exclude_fields = kwargs.get("exclude_fields")
    search = ArfComparisonExecHistory.create_search_object(
        include_fields=include_fields, exclude_fields=exclude_fields
    )
    term_queries_added = False
    if uid is not None:
        search = search.query("term", uid=uid)
        term_queries_added = True
    if solution_id is not None:
        search = search.query("term", solution_id=solution_id)
        term_queries_added = True
    if solution_date is not None:
        search = search.query("term", solution_date=solution_date)
        term_queries_added = True
    if status is not None:
        search = search.query("term", status=status)
        term_queries_added = True
    if not term_queries_added:
        search = search.query("match_all")

    return search.execute().hits


def opensearch_get_arf_comparison_exec_history(uid: str) -> ArfComparisonExecHistory:
    """Gets arf comparison execution details for a solution
    Returns:
        arf comparison execution found with uid

    """

    arf_exec_history = ArfComparisonExecHistory.get(uid)
    return arf_exec_history


def opensearch_update_arf_comparison_exec_history(
    arf_exec_hist: ArfComparisonExecHistory, updated_by: str, refresh: str = "wait_for"
) -> ArfComparisonExecHistory:
    """To update a status of arf_comparison_exec_history document
    Params:
        arf_exec_hist: original document
        updated_by: who updated the document
        refresh: specifies opensearch refresh behavior

    Return:
        Upated arf comparison execution history document
    """
    arf_exec_hist.updated_by = updated_by
    arf_exec_hist.update_document(refresh=refresh)

    return arf_exec_hist
