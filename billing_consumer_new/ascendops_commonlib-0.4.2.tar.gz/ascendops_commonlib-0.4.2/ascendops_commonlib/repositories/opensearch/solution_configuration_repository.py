"""
    Performs operations related to solution configurations
"""
from ascendops_commonlib.entities.opensearch.solution_configuration import (
    SolutionConfiguration,
)
from ascendops_commonlib.enums.solution.solution_config_type_enum import (
    SolutionConfigTypeEnum,
)
from ascendops_commonlib.enums.solution.solution_segment_type_enum import (
    SolutionSegmentTypeEnum,
)


def opensearch_get_bureau_configuration_dictionaries() -> "list[dict]":
    """Gets all bureau configuration dictionaries
    Returns:
        list of bureau configuration dictionaries

    """
    search = SolutionConfiguration.create_search_object()
    search = search.query(
        "term", config_type=SolutionConfigTypeEnum.BUREAU_CONFIGURATION
    )
    solution_configurations: "list[SolutionConfiguration]" = search.execute()
    bureau_configurations = []
    for solution_config in solution_configurations:
        config_dict = solution_config.config.to_dict()
        bureau_config = {
            "uid": solution_config.uid,
            "created_on": solution_config.created_on,
            "created_by": solution_config.created_by,
            "updated_on": solution_config.updated_on,
            "updated_by": solution_config.updated_by,
            "service_name": config_dict.get("service_name"),
            "certificate_name": config_dict.get("certificate_name"),
            "data_source_names": config_dict.get("data_source_names"),
            "key_store_password": config_dict.get("key_store_password"),
            "bureau_market": config_dict.get("bureau_market"),
            "bureau_sub_market": config_dict.get("bureau_sub_market"),
            "industry_code": config_dict.get("industry_code"),
        }
        bureau_configurations.append(bureau_config)
    return bureau_configurations


def opensearch_get_bureau_service_dictionaries() -> "list[dict]":
    """Gets all bureau service dictionaries
    Returns:
        list of bureau service dictionaries
    """
    search = SolutionConfiguration.create_search_object()
    search = search.query("term", config_type=SolutionConfigTypeEnum.BUREAU_SERVICE)
    solution_configurations: "list[SolutionConfiguration]" = search.execute()
    bureau_services = []
    for solution_config in solution_configurations:
        config_dict = solution_config.config.to_dict()
        bureau_service = {
            "uid": solution_config.uid,
            "created_on": solution_config.created_on,
            "created_by": solution_config.created_by,
            "updated_on": solution_config.updated_on,
            "updated_by": solution_config.updated_by,
            "name": config_dict.get("name"),
        }
        bureau_services.append(bureau_service)
    return bureau_services


def opensearch_get_billing_service_dictionaries() -> "list[dict]":
    """Gets all billing service dictionaries
    Returns:
        list of billing service dictionaries
    """
    search = SolutionConfiguration.create_search_object()
    search = search.query("term", config_type=SolutionConfigTypeEnum.BILLING_SERVICE)
    solution_configurations: "list[SolutionConfiguration]" = search.execute()
    billing_services = []
    for solution_config in solution_configurations:
        config_dict = solution_config.config.to_dict()
        billing_service = {
            "uid": solution_config.uid,
            "created_on": solution_config.created_on,
            "created_by": solution_config.created_by,
            "updated_on": solution_config.updated_on,
            "updated_by": solution_config.updated_by,
            "name": config_dict.get("name"),
        }
        billing_services.append(billing_service)
    return billing_services


def opensearch_get_exclusion_default_dictionaries() -> "list[dict]":
    """Gets all exclusion default dictionaries
    Returns:
        list of exclusion default dictionaries
    """
    search = SolutionConfiguration.create_search_object()
    search = search.query("term", config_type=SolutionConfigTypeEnum.EXCLUSION_DEFAULT)
    solution_configurations: "list[SolutionConfiguration]" = search.execute()
    exclusion_defaults = []
    for solution_config in solution_configurations:
        config_dict = solution_config.config.to_dict()
        exclusion_default = {
            "uid": solution_config.uid,
            "created_on": solution_config.created_on,
            "created_by": solution_config.created_by,
            "updated_on": solution_config.updated_on,
            "updated_by": solution_config.updated_by,
            "criteria": config_dict.get("criteria"),
            "return_score": config_dict.get("return_score"),
            "default_score": config_dict.get("default_score"),
        }
        exclusion_defaults.append(exclusion_default)
    return exclusion_defaults


def opensearch_get_bureau_certificate_dictionaries() -> "list[dict]":
    """Gets all bureau certificate dictionaries
    Returns:
        list of bureau certificate dictionaries
    """
    search = SolutionConfiguration.create_search_object()
    search = search.query("term", config_type=SolutionConfigTypeEnum.BUREAU_CERTIFICATE)
    solution_configurations: "list[SolutionConfiguration]" = search.execute()
    bureau_certificates = []
    for solution_config in solution_configurations:
        config_dict = solution_config.config.to_dict()
        bureau_certificate = {
            "uid": solution_config.uid,
            "created_on": solution_config.created_on,
            "created_by": solution_config.created_by,
            "updated_on": solution_config.updated_on,
            "updated_by": solution_config.updated_by,
            "name": config_dict.get("name"),
        }
        bureau_certificates.append(bureau_certificate)
    return bureau_certificates


def opensearch_get_segment_dictionaries(segment_type=None) -> "list[dict]":
    """Gets all segment configurations. Segments are part of the ARF response
    and are used in solution to determine in what segment of the ARF data should go
    Returns:
        list of segment configurations
    """
    search = SolutionConfiguration.create_search_object()
    search = search.query("term", config_type=SolutionConfigTypeEnum.SEGMENT)
    solution_configurations: "list[SolutionConfiguration]" = search.execute()
    segment_configurations = []
    for solution_config in solution_configurations:
        config_dict = solution_config.config.to_dict()
        segment_configuration = {
            "uid": solution_config.uid,
            "created_on": solution_config.created_on,
            "created_by": solution_config.created_by,
            "updated_on": solution_config.updated_on,
            "updated_by": solution_config.updated_by,
            "segment_value": config_dict.get("segment_value"),
            "fifth_factor_code_segment": config_dict.get("fifth_factor_code_segment"),
        }
        if not segment_type:
            segment_configuration["segment_type"] = (
                SolutionSegmentTypeEnum(config_dict.get("segment_type"))
                if config_dict.get("segment_type") is not None
                else None
            )
            segment_configurations.append(segment_configuration)
        elif config_dict.get("segment_type") == segment_type:
            segment_configuration["segment_type"] = (
                SolutionSegmentTypeEnum(segment_type)
                if segment_type is not None
                else None
            )
            segment_configurations.append(segment_configuration)
    return segment_configurations


def opensearch_get_keyword_dictionaries() -> "list[dict]":
    """Get all keyword configuration. Keywords are part of the inquiry string. Each keyword has
    a different meaning
    Returns:
        list of keyword configurations
    """
    search = SolutionConfiguration.create_search_object()
    search = search.query("term", config_type=SolutionConfigTypeEnum.KEYWORD)
    solultion_configurations: "list[SolutionConfiguration]" = search.execute()
    keyword_configurations = []
    for solution_config in solultion_configurations:
        config_dict = solution_config.config.to_dict()
        keyword_configuration = {
            "uid": solution_config.uid,
            "created_on": solution_config.created_on,
            "created_by": solution_config.created_by,
            "updated_on": solution_config.updated_on,
            "updated_by": solution_config.updated_by,
            "keyword": config_dict.get("keyword"),
        }
        keyword_configurations.append(keyword_configuration)
    return keyword_configurations


def opensearch_get_bureau_datasource_dictionaries() -> "list[dict]":
    """Get all datasources for a bureau
    Returns:
        list of datasource configuration dictionaries
    """
    search = SolutionConfiguration.create_search_object()
    search = search.query("term", config_type=SolutionConfigTypeEnum.BUREAU_DATA_SOURCE)
    solultion_configurations: "list[SolutionConfiguration]" = search.execute()
    datasource_configurations = []
    for solution_config in solultion_configurations:
        config_dict = solution_config.config.to_dict()
        datasource_configuration = {
            "uid": solution_config.uid,
            "created_on": solution_config.created_on,
            "created_by": solution_config.created_by,
            "updated_on": solution_config.updated_on,
            "updated_by": solution_config.updated_by,
            "bureau_datasource": config_dict.get("bureau_datasource"),
        }
        datasource_configurations.append(datasource_configuration)
    return datasource_configurations


def opensearch_create_solution_config(
    solution_configuration: SolutionConfiguration, refresh="false"
) -> SolutionConfiguration:
    """To create a solution configuration  document
    Params:
        solution configuration: defines properties of solution configuration object
    Return:
        Solution configuration object
    """
    solution_configuration.insert_document(refresh=refresh)
    return solution_configuration
