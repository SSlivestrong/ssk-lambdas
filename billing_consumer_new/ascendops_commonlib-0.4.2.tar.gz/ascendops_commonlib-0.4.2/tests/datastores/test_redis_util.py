""" Test cases for redis_util.py """
import unittest
from unittest.mock import patch, MagicMock 
from logging import Logger
from ascendops_commonlib.datastores.redis_util import RedisCache

class TestRedisCache(unittest.TestCase):
    """ Test Redis_util class """   
    
    @patch('ascendops_commonlib.datastores.redis_util.KMSCrypto.init')    
    @patch('ascendops_commonlib.datastores.redis_util.redis.Redis')            
    @patch('ascendops_commonlib.datastores.redis_util.redis.ConnectionPool')  
    def test_init_single_instance(self,mock_connection_pool,mock_redis,mock_kms_crypto) :
        """ test init class with non cluster mode 
        and mocking connection to a redis server """
        
        test_config = {"kms_key_id" : "your_key_id"}
        mock_connection_pool.return_value={"connected" : True}
        mock_kms_crypto.return_value = 'Success'
        
        RedisCache.init(test_config)
        
        mock_connection_pool.assert_called_once_with(**test_config)
        self.assertTrue(RedisCache().pool, {"connected" : True})
        mock_redis.assert_called_once_with(connection_pool={"connected" : True})
     
    @patch('ascendops_commonlib.datastores.redis_util.KMSCrypto.init')  
    @patch('ascendops_commonlib.datastores.redis_util.RedisCluster')
    def test_init_cluster_instance(self, mock_redis_cluster,mock_kms_crypto) :
        """ test init class with cluster mode 
        and mocking connection to redis cluster"""
        
        test_config = {"kms_key_id" : "your_key_id","mode" : "cluster"}
        mock_redis_cluster.return_value= 'test'
        mock_kms_crypto.return_value = 'Success'
        
        RedisCache.init(test_config)
        
        mock_redis_cluster.assert_called_once_with(**test_config)
        self.assertTrue(RedisCache().client_response_cache, 'test')
        RedisCache.client_response_cache=None
    
    @patch('ascendops_commonlib.datastores.redis_util.KMSCrypto.init') 
    @patch('ascendops_commonlib.datastores.redis_util.IS_AWS')
    @patch('ascendops_commonlib.datastores.redis_util.RedisCluster')
    def test_init_cluster_instance_exception(self, mock_redis_cluster,mock_is_aws,mock_kms_crypto):
        """ test init class with cluster mode
        with redis cluster throwing exception"""
        
        test_config = {"kms_key_id": "test_value", "mode": "cluster"}
        mock_redis_cluster.side_effect = Exception('Error')
        mock_is_aws.return_value=True
        mock_kms_crypto.return_value = 'Success'
        
        with self.assertRaises(Exception) as exp:
            RedisCache().init(test_config)

        mock_redis_cluster.assert_called_once_with(**test_config)    
        RedisCache.client_response_cache = None
        
        
    @patch('ascendops_commonlib.datastores.redis_util.RedisCache.set_in_redis')
    @patch('ascendops_commonlib.datastores.redis_util.RedisCache.get_from_redis')
    @patch('ascendops_commonlib.datastores.redis_util.logging.getLogger')
    def test_warmup_success(self, mock_get_logger, mock_get_from_redis, mock_set_in_redis):
        """ test warmup with redis cache up and running"""
        
        mock_set_in_redis.return_value = None
        mock_get_from_redis.return_value = {"response" : "200"}
        mock_logger_instance = MagicMock()
        mock_get_logger.return_value = mock_logger_instance
        
        RedisCache.warmup()
        
        mock_set_in_redis.assert_called_once_with("inquiry::bootstrap::warmup", {"response" : "200"})
        mock_get_from_redis.assert_called_once_with("inquiry::bootstrap::warmup")
        mock_logger_instance.warning.assert_called_with("Redis Cache - warmup success")
        
    @patch('ascendops_commonlib.datastores.redis_util.RedisCache.set_in_redis')
    @patch('ascendops_commonlib.datastores.redis_util.RedisCache.get_from_redis')
    @patch('ascendops_commonlib.datastores.redis_util.logging.getLogger')
    def test_warmup_failure(self, mock_get_logger, mock_get_from_redis, mock_set_in_redis):
        """ test warmup with redis cache throwing error"""
        
        mock_set_in_redis.side_effect = Exception("Some Error")
        mock_logger_instance = MagicMock()
        mock_get_logger.return_value = mock_logger_instance
        
        RedisCache.warmup()
        
        mock_set_in_redis.assert_called_once_with("inquiry::bootstrap::warmup", {"response" : "200"})
        mock_get_from_redis.assert_not_called()    
        mock_logger_instance.warning.assert_called_with("Redis Cache - warmup failed: %s", "Some Error")
        
    @patch('ascendops_commonlib.aws_utils.kms_crypto.KMSCrypto.encrypt_dict') 
    @patch('ascendops_commonlib.datastores.redis_util.time.time') 
    @patch('ascendops_commonlib.datastores.redis_util.logging.getLogger')
    @patch('ascendops_commonlib.datastores.redis_util.RedisCache.client_response_cache')  
    def test_set_in_redis_success(self, mock_client_response_cache,mock_logger, mock_time,mock_encrypt_dict) :
        """ test set_in_redis method using mock encrypted value 
        and redis cache is up and running  """
        
        mock_encrypt_dict.return_value = "encrypted_data"
        mock_logger_instance = MagicMock(spec=Logger)
        mock_logger.return_value = mock_logger_instance
        mock_time.side_effect =[0,1]
        mock_client_response_cache.set.side_effect ='Success'
        
        key = "test_key"
        doc = {"test_key": "test_data"}
        ttl_in_sec = 10
        
        RedisCache().set_in_redis(key, doc, ttl_in_sec, mock_logger_instance)
        
        mock_encrypt_dict.assert_called_once_with(doc, mock_logger_instance)
        mock_logger_instance.debug.assert_called_once_with("adding into cache %s %d", key, len("encrypted_data"))
        mock_logger_instance.info.assert_called_once_with("timetaken to set in redis:%s", 1)
        mock_client_response_cache.set.assert_called_once_with(key, "encrypted_data", ex=ttl_in_sec)
        
    @patch('ascendops_commonlib.aws_utils.kms_crypto.KMSCrypto.encrypt_dict') 
    @patch('ascendops_commonlib.datastores.redis_util.logging.getLogger')
    def test_set_in_redis_exception(self, mock_logger,mock_encrypt_dict) :
        """ test set_in_redis method mock encryption failed  """
        
        mock_encrypt_dict.side_effect = Exception("Encryption failed")
        mock_logger_instance = MagicMock(spec=Logger)
        mock_logger.return_value = mock_logger_instance
        
        key = "test_key"
        doc = {"data": "test_data"}
        ttl_in_sec = 10
        
        with self.assertRaises(RedisCache.MemCacheException) as context:
            RedisCache.set_in_redis(key, doc, ttl_in_sec, mock_logger_instance)
            
        self.assertEqual(str(context.exception), "failed to cache:Encryption failed")
        mock_encrypt_dict.assert_called_once_with(doc, mock_logger_instance)
        mock_logger_instance.debug.assert_not_called()
        mock_logger_instance.info.assert_not_called()
        RedisCache.client_response_cache.set.assert_not_called()      
                 
    @patch('ascendops_commonlib.aws_utils.kms_crypto.KMSCrypto.decrypt_dict') 
    @patch('ascendops_commonlib.datastores.redis_util.time.time') 
    @patch('ascendops_commonlib.datastores.redis_util.logging.getLogger')  
    @patch('ascendops_commonlib.datastores.redis_util.RedisCache.client_response_cache') 
    def test_get_from_redis_success(self,mock_client_response_cache, mock_logger, mock_time,mock_decrypt_dict) :
        """ test get_from_redis method uses return value from redis cache and decrypt it"""
        
        mock_decrypt_dict.return_value = {"data": "test_data"}
        mock_logger_instance = MagicMock(spec=Logger)
        mock_logger.return_value = mock_logger_instance
        mock_time.side_effect =[0,1]
        mock_client_response_cache.get.return_value = 'encrypted_data'
        key = "test_key"
        
        result = RedisCache.get_from_redis(key, mock_logger_instance)
        
        mock_time.assert_called()
        mock_client_response_cache.get.assert_called_once_with(key)
        mock_decrypt_dict.assert_called_once_with("encrypted_data")
        mock_logger_instance.info.assert_called_once_with("timetaken to get from redis:%s", 1)
        self.assertEqual(result, {"data": "test_data"})
         
    @patch('ascendops_commonlib.datastores.redis_util.time.time') 
    @patch('ascendops_commonlib.datastores.redis_util.logging.getLogger')
    @patch('ascendops_commonlib.datastores.redis_util.RedisCache.client_response_cache')
    def test_get_from_redis_exception(self, mock_client_response_cache, mock_logger, mock_time) :
        """ test get_from_redis with redis cache throwing exception"""
        
        mock_logger_instance = MagicMock(spec=Logger)
        mock_logger.return_value = mock_logger_instance
        mock_time.side_effect =[0,1]
        key = "test_key"
        mock_client_response_cache.get.side_effect = Exception("Cache read failed")
        
        with self.assertRaises(RedisCache.MemCacheException) as context:
            RedisCache.get_from_redis(key, mock_logger_instance)
        
        self.assertEqual(str(context.exception), "failed while reading from cache:Cache read failed")
        mock_time.assert_called()
        mock_client_response_cache.get.assert_called_once_with(key)
        mock_logger_instance.info.assert_not_called()
        
        RedisCache.client_response_cache = None
        
        with self.assertRaises(RedisCache.MemCacheException) as context:
            RedisCache.get_from_redis(key, mock_logger_instance)
        
        self.assertEqual(str(context.exception), "failed while reading from cache:failed while reading from cache: client not initialized")
        
        