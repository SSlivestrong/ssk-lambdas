""" Unit tests for Datasource entity """

import unittest
from ascendops_commonlib.entities.opensearch.datasource import Datasource
from ascendops_commonlib.enums.datasource.datasource_type_enum import DatasourceTypeEnum


class TestDatasource(unittest.TestCase):
    """Unit tests for Datasource"""

    def setUp(self) -> None:
        """Creates datasource object populated with fields before each test"""
        self.datasource = Datasource()

        self.original_name = "name_1"
        self.original_description = "description_1"
        self.original_datasource_fields = {
            "field_name": "field_name_1",
            "field_type": "int",
            "default_value": "5",
            "is_multi": True,
            "is_mandatory": True,
            "env_flag": True,
            "values": ["5", "10"],
        }
        self.original_datasource_type = DatasourceTypeEnum.EQUIFAX

        self.datasource.name = self.original_name
        self.datasource.description = self.original_description
        self.datasource.datasource_fields = self.original_datasource_fields
        self.datasource.datasource_type = self.original_datasource_type

    def test_update_from_dict_full_payload(self):
        """Test update from dict with all editable fields"""

        # ARRANGE
        # set update fields
        updated_description = "description_2"
        updated_datasource_type = DatasourceTypeEnum.CLARITY
        updated_datasource_fields = {
            "field_name": "field_name_2",
            "field_type": "string",
            "default_value": "yes",
            "is_multi": False,
            "is_mandatory": False,
            "env_flag": False,
            "values": ["yes", "no"],
        }

        # ACT
        self.datasource.update_from_dict(
            {
                "description": updated_description,
                "datasource_fields": updated_datasource_fields,
                "datasource_type": updated_datasource_type,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(self.datasource.name, self.original_name)

        # these fields should be updated
        self.assertEqual(self.datasource.description, updated_description)
        self.assertEqual(self.datasource.datasource_fields, updated_datasource_fields)
        self.assertEqual(self.datasource.datasource_type, updated_datasource_type)

    def test_update_from_dict_payload_with_nulls(self) -> None:
        """Test update from dict updates fields with null if given in payload"""

        # ARRANGE
        # set update fields
        updated_description = None
        updated_datasource_type = None
        updated_datasource_fields = None

        # ACT
        self.datasource.update_from_dict(
            {
                "description": updated_description,
                "datasource_fields": updated_datasource_fields,
                "datasource_type": updated_datasource_type,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(self.datasource.name, self.original_name)

        # these fields should be updated
        self.assertEqual(self.datasource.description, updated_description)
        self.assertEqual(self.datasource.datasource_fields, updated_datasource_fields)
        self.assertEqual(self.datasource.datasource_type, updated_datasource_type)

    def test_update_from_dict_partial_payload(self) -> None:
        """Tests that only fields included in dict update in datasource"""

        # ARRANGE
        # set update fields
        updated_description = "description_2"
        updated_datasource_type = DatasourceTypeEnum.CLARITY

        # act
        self.datasource.update_from_dict(
            {
                "description": updated_description,
                "datasource_type": updated_datasource_type,
            }
        )

        # assert
        # these fields should not be updated
        self.assertEqual(self.datasource.name, self.original_name)
        self.assertEqual(
            self.datasource.datasource_fields, self.original_datasource_fields
        )

        # these fields should be updated
        self.assertEqual(self.datasource.description, updated_description)
        self.assertEqual(self.datasource.datasource_type, updated_datasource_type)

    def test_update_from_dict_payload_uneditable_field(self) -> None:
        """Verify that update does not update uneditable fields within datasource"""

        # ARRANGE

        # set update fields
        updated_description = "description_2"
        updated_datasource_type = DatasourceTypeEnum.CLARITY

        # ACT
        self.datasource.update_from_dict(
            {
                "name": "name_2",
                "description": updated_description,
                "datasource_type": updated_datasource_type,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(self.datasource.name, self.original_name)
        self.assertEqual(
            self.datasource.datasource_fields, self.original_datasource_fields
        )

        # these fields should be updated
        self.assertEqual(self.datasource.description, updated_description)
        self.assertEqual(self.datasource.datasource_type, updated_datasource_type)
