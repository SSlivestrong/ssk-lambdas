""" Unit tests for BatchAppNameEnum """

import unittest
import json
from ascendops_commonlib.enums.batch_consumers.batch_app_name_enum import (
    BatchAppNameEnum,
)


class TestBatchAppNameEnum(unittest.TestCase):
    """Unit tests for BatchAppNameEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(
            BatchAppNameEnum("platform-api"), BatchAppNameEnum.PLATFORM_API
        )
        self.assertEqual(
            BatchAppNameEnum("dispatch-consumer"), BatchAppNameEnum.DISPATCH_CONSUMER
        )
        self.assertEqual(
            BatchAppNameEnum("pre-process-start"), BatchAppNameEnum.PRE_PROCESS_START
        )
        self.assertEqual(
            BatchAppNameEnum("pre-process-end"), BatchAppNameEnum.PRE_PROCESS_END
        )
        self.assertEqual(
            BatchAppNameEnum("model-exec-start"), BatchAppNameEnum.MODEL_EXEC_START
        )
        self.assertEqual(
            BatchAppNameEnum("model-exec-end"), BatchAppNameEnum.MODEL_EXEC_END
        )
        self.assertEqual(
            BatchAppNameEnum("post-process-start"), BatchAppNameEnum.POST_PROCESS_START
        )
        self.assertEqual(
            BatchAppNameEnum("post-process-end"), BatchAppNameEnum.POST_PROCESS_END
        )
        self.assertEqual(
            BatchAppNameEnum("notify-campaign-end-amps"),
            BatchAppNameEnum.NOTIFY_CAMPAIGN_END_AMPS,
        )
        self.assertEqual(
            BatchAppNameEnum("notify-campaign-end-mktg"),
            BatchAppNameEnum.NOTIFY_CAMPAIGN_END_MKTG,
        )
        self.assertEqual(
            BatchAppNameEnum("batch-processor-start"),
            BatchAppNameEnum.BATCH_PROCESSOR_START,
        )
        self.assertEqual(
            BatchAppNameEnum("batch-processor-end"),
            BatchAppNameEnum.BATCH_PROCESSOR_END,
        )
        self.assertEqual(
            BatchAppNameEnum("batch-orchestrator"), BatchAppNameEnum.BATCH_ORCHESTRATOR
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(BatchAppNameEnum.PLATFORM_API.value, "platform-api")
        self.assertEqual(BatchAppNameEnum.DISPATCH_CONSUMER.value, "dispatch-consumer")
        self.assertEqual(BatchAppNameEnum.PRE_PROCESS_START.value, "pre-process-start")
        self.assertEqual(BatchAppNameEnum.PRE_PROCESS_END.value, "pre-process-end")
        self.assertEqual(BatchAppNameEnum.MODEL_EXEC_START.value, "model-exec-start")
        self.assertEqual(BatchAppNameEnum.MODEL_EXEC_END.value, "model-exec-end")
        self.assertEqual(
            BatchAppNameEnum.POST_PROCESS_START.value, "post-process-start"
        )
        self.assertEqual(BatchAppNameEnum.POST_PROCESS_END.value, "post-process-end")
        self.assertEqual(
            BatchAppNameEnum.NOTIFY_CAMPAIGN_END_AMPS.value, "notify-campaign-end-amps"
        )
        self.assertEqual(
            BatchAppNameEnum.NOTIFY_CAMPAIGN_END_MKTG.value, "notify-campaign-end-mktg"
        )
        self.assertEqual(
            BatchAppNameEnum.BATCH_PROCESSOR_START.value, "batch-processor-start"
        )
        self.assertEqual(
            BatchAppNameEnum.BATCH_PROCESSOR_END.value, "batch-processor-end"
        )
        self.assertEqual(
            BatchAppNameEnum.BATCH_ORCHESTRATOR.value, "batch-orchestrator"
        )

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(
            BatchAppNameEnum.PLATFORM_API, BatchAppNameEnum["PLATFORM_API"]
        )
        self.assertEqual(
            BatchAppNameEnum.DISPATCH_CONSUMER, BatchAppNameEnum["DISPATCH_CONSUMER"]
        )
        self.assertEqual(
            BatchAppNameEnum.PRE_PROCESS_START, BatchAppNameEnum["PRE_PROCESS_START"]
        )
        self.assertEqual(
            BatchAppNameEnum.PRE_PROCESS_END, BatchAppNameEnum["PRE_PROCESS_END"]
        )
        self.assertEqual(
            BatchAppNameEnum.MODEL_EXEC_START, BatchAppNameEnum["MODEL_EXEC_START"]
        )
        self.assertEqual(
            BatchAppNameEnum.MODEL_EXEC_END, BatchAppNameEnum["MODEL_EXEC_END"]
        )

        self.assertEqual(
            BatchAppNameEnum.POST_PROCESS_START, BatchAppNameEnum["POST_PROCESS_START"]
        )
        self.assertEqual(
            BatchAppNameEnum.POST_PROCESS_END, BatchAppNameEnum["POST_PROCESS_END"]
        )
        self.assertEqual(
            BatchAppNameEnum.NOTIFY_CAMPAIGN_END_AMPS,
            BatchAppNameEnum["NOTIFY_CAMPAIGN_END_AMPS"],
        )
        self.assertEqual(
            BatchAppNameEnum.NOTIFY_CAMPAIGN_END_MKTG,
            BatchAppNameEnum["NOTIFY_CAMPAIGN_END_MKTG"],
        )
        self.assertEqual(
            BatchAppNameEnum.BATCH_PROCESSOR_START,
            BatchAppNameEnum["BATCH_PROCESSOR_START"],
        )
        self.assertEqual(
            BatchAppNameEnum.BATCH_PROCESSOR_END,
            BatchAppNameEnum["BATCH_PROCESSOR_END"],
        )
        self.assertEqual(
            BatchAppNameEnum.BATCH_ORCHESTRATOR, BatchAppNameEnum["BATCH_ORCHESTRATOR"]
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(BatchAppNameEnum.PLATFORM_API), '"platform-api"')
        self.assertEqual(
            json.dumps(BatchAppNameEnum.DISPATCH_CONSUMER), '"dispatch-consumer"'
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.PRE_PROCESS_START), '"pre-process-start"'
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.PRE_PROCESS_END), '"pre-process-end"'
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.MODEL_EXEC_START), '"model-exec-start"'
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.MODEL_EXEC_END), '"model-exec-end"'
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.POST_PROCESS_START), '"post-process-start"'
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.POST_PROCESS_END), '"post-process-end"'
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.NOTIFY_CAMPAIGN_END_AMPS),
            '"notify-campaign-end-amps"',
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.NOTIFY_CAMPAIGN_END_MKTG),
            '"notify-campaign-end-mktg"',
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.BATCH_PROCESSOR_START),
            '"batch-processor-start"',
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.BATCH_PROCESSOR_END), '"batch-processor-end"'
        )
        self.assertEqual(
            json.dumps(BatchAppNameEnum.BATCH_ORCHESTRATOR), '"batch-orchestrator"'
        )
