""" Unit tests for SolutionModelTypeEnum """

import unittest
import json
from ascendops_commonlib.enums.solution.solution_model_type_enum import (
    SolutionModelTypeEnum,
)


class TestSolutionModelTypeEnum(unittest.TestCase):
    """Unit tests for SolutionModelTypeEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(SolutionModelTypeEnum("score"), SolutionModelTypeEnum.SCORE)
        self.assertEqual(
            SolutionModelTypeEnum("score_only"), SolutionModelTypeEnum.SCORE_ONLY
        )
        self.assertEqual(
            SolutionModelTypeEnum("score_and_attribute"),
            SolutionModelTypeEnum.SCORE_AND_ATTRIBUTE,
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(SolutionModelTypeEnum.SCORE.value, "score")
        self.assertEqual(SolutionModelTypeEnum.SCORE_ONLY.value, "score_only")
        self.assertEqual(
            SolutionModelTypeEnum.SCORE_AND_ATTRIBUTE.value, "score_and_attribute"
        )

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(SolutionModelTypeEnum.SCORE, SolutionModelTypeEnum["SCORE"])
        self.assertEqual(
            SolutionModelTypeEnum.SCORE_ONLY, SolutionModelTypeEnum["SCORE_ONLY"]
        )
        self.assertEqual(
            SolutionModelTypeEnum.SCORE_AND_ATTRIBUTE,
            SolutionModelTypeEnum["SCORE_AND_ATTRIBUTE"],
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(SolutionModelTypeEnum.SCORE), '"score"')
        self.assertEqual(json.dumps(SolutionModelTypeEnum.SCORE_ONLY), '"score_only"')
        self.assertEqual(
            json.dumps(SolutionModelTypeEnum.SCORE_AND_ATTRIBUTE),
            '"score_and_attribute"',
        )
