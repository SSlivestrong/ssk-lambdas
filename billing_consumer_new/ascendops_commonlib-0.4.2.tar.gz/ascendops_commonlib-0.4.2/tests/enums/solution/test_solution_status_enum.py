""" Unit tests for SolutionStatusEnum """

import unittest
import json
from ascendops_commonlib.enums.solution.solution_status_enum import (
    SolutionStatusEnum,
)


class TestSolutionStatusEnum(unittest.TestCase):
    """Unit tests for SolutionStatusEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(SolutionStatusEnum("draft"), SolutionStatusEnum.DRAFT)
        self.assertEqual(SolutionStatusEnum("test"), SolutionStatusEnum.TEST)
        self.assertEqual(SolutionStatusEnum("ready"), SolutionStatusEnum.READY)
        self.assertEqual(SolutionStatusEnum("prod"), SolutionStatusEnum.PROD)
        self.assertEqual(SolutionStatusEnum("archived"), SolutionStatusEnum.ARCHIVED)

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(SolutionStatusEnum.DRAFT.value, "draft")
        self.assertEqual(SolutionStatusEnum.TEST.value, "test")
        self.assertEqual(SolutionStatusEnum.READY.value, "ready")
        self.assertEqual(SolutionStatusEnum.PROD.value, "prod")
        self.assertEqual(SolutionStatusEnum.ARCHIVED.value, "archived")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(SolutionStatusEnum.DRAFT, SolutionStatusEnum["DRAFT"])
        self.assertEqual(SolutionStatusEnum.TEST, SolutionStatusEnum["TEST"])
        self.assertEqual(SolutionStatusEnum.READY, SolutionStatusEnum["READY"])
        self.assertEqual(SolutionStatusEnum.PROD, SolutionStatusEnum["PROD"])
        self.assertEqual(SolutionStatusEnum.ARCHIVED, SolutionStatusEnum["ARCHIVED"])

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(SolutionStatusEnum.DRAFT), '"draft"')
        self.assertEqual(json.dumps(SolutionStatusEnum.TEST), '"test"')
        self.assertEqual(json.dumps(SolutionStatusEnum.READY), '"ready"')
        self.assertEqual(json.dumps(SolutionStatusEnum.PROD), '"prod"')
        self.assertEqual(json.dumps(SolutionStatusEnum.ARCHIVED), '"archived"')
