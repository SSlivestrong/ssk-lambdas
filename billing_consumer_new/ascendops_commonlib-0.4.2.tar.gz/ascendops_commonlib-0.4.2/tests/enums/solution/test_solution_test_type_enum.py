""" Unit tests for SolutionTestTypeEnum """

import unittest
import json
from ascendops_commonlib.enums.solution.solution_test_type_enum import (
    SolutionTestTypeEnum,
)


class TestSolutionTestTypeEnum(unittest.TestCase):
    """Unit tests for SolutionTestTypeEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(SolutionTestTypeEnum("common"), SolutionTestTypeEnum.COMMON)
        self.assertEqual(SolutionTestTypeEnum("custom"), SolutionTestTypeEnum.CUSTOM)

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(SolutionTestTypeEnum.COMMON.value, "common")
        self.assertEqual(SolutionTestTypeEnum.CUSTOM.value, "custom")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(SolutionTestTypeEnum.COMMON, SolutionTestTypeEnum["COMMON"])
        self.assertEqual(SolutionTestTypeEnum.CUSTOM, SolutionTestTypeEnum["CUSTOM"])

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(SolutionTestTypeEnum.COMMON), '"common"')
        self.assertEqual(json.dumps(SolutionTestTypeEnum.CUSTOM), '"custom"')
