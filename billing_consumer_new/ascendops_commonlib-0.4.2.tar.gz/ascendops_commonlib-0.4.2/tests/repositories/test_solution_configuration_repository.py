import unittest
from unittest.mock import MagicMock, patch, call
import datetime
from ascendops_commonlib.repositories.opensearch import (
    solution_configuration_repository,
)
from ascendops_commonlib.entities.opensearch.solution_configuration import (
    SolutionConfiguration,
)
from ascendops_commonlib.enums.solution.solution_config_type_enum import (
    SolutionConfigTypeEnum,
)


class TestSolutionConfigurationRepository(unittest.TestCase):
    """Unit tests for solution_configuration_repository"""

    def test_opensearch_get_bureau_configuration_dictionaries(self):
        """test get bureau configuration dictionaries"""
        # ARRANGE
        uid = "uid_1"
        created_on = datetime.datetime.now()
        created_by = "created_by_1"
        updated_on = datetime.datetime.now()
        updated_by = "updated_by_1"
        service_name = "service_name_1"
        certificate_name = "certificate_name_1"
        data_source_names = ["name"]
        key_store_password = "key_store_password_1"
        bureau_market = "bureau_market_1"
        bureau_sub_market = "bureau_sub_market_1"
        industry_code = "industry_code_1"

        expected_docs = [
            {
                "uid": uid,
                "created_on": created_on,
                "created_by": created_by,
                "updated_on": updated_on,
                "updated_by": updated_by,
                "service_name": service_name,
                "certificate_name": certificate_name,
                "data_source_names": data_source_names,
                "key_store_password": key_store_password,
                "bureau_market": bureau_market,
                "bureau_sub_market": bureau_sub_market,
                "industry_code": industry_code,
            }
        ]

        # bureau config to return
        solution_config = SolutionConfiguration()
        solution_config.uid = uid
        solution_config.created_on = created_on
        solution_config.created_by = created_by
        solution_config.updated_on = updated_on
        solution_config.updated_by = updated_by
        solution_config.config = {
            "service_name": service_name,
            "certificate_name": certificate_name,
            "data_source_names": data_source_names,
            "key_store_password": key_store_password,
            "bureau_market": bureau_market,
            "bureau_sub_market": bureau_sub_market,
            "industry_code": industry_code,
        }

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search
        mock_search.execute.return_value = [solution_config]

        with patch.object(
            SolutionConfiguration, "create_search_object", return_value=mock_search
        ):

            # ACT
            actual_docs = (
                solution_configuration_repository.opensearch_get_bureau_configuration_dictionaries()
            )
            # ASSERT

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with(
                "term", config_type=SolutionConfigTypeEnum.BUREAU_CONFIGURATION
            )

            # check return value
            self.assertListEqual(expected_docs, actual_docs)

    def test_opensearch_get_bureau_service_dictionaries(self):
        """test get bureau service dictionaries"""
        # ARRANGE
        uid = "uid_1"
        created_on = datetime.datetime.now()
        created_by = "created_by_1"
        updated_on = datetime.datetime.now()
        updated_by = "updated_by_1"
        name = "name_1"

        expected_docs = [
            {
                "uid": uid,
                "created_on": created_on,
                "created_by": created_by,
                "updated_on": updated_on,
                "updated_by": updated_by,
                "name": name,
            }
        ]

        # bureau config to return
        solution_config = SolutionConfiguration()
        solution_config.uid = uid
        solution_config.created_on = created_on
        solution_config.created_by = created_by
        solution_config.updated_on = updated_on
        solution_config.updated_by = updated_by
        solution_config.config = {
            "name": name,
        }

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search
        mock_search.execute.return_value = [solution_config]

        with patch.object(
            SolutionConfiguration, "create_search_object", return_value=mock_search
        ):

            # ACT
            actual_docs = (
                solution_configuration_repository.opensearch_get_bureau_service_dictionaries()
            )
            # ASSERT

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with(
                "term", config_type=SolutionConfigTypeEnum.BUREAU_SERVICE
            )

            # check return value
            self.assertListEqual(expected_docs, actual_docs)

    def test_opensearch_get_billing_service_dictionaries(self):
        """test get billing service dictionaries"""
        # ARRANGE
        uid = "uid_1"
        created_on = datetime.datetime.now()
        created_by = "created_by_1"
        updated_on = datetime.datetime.now()
        updated_by = "updated_by_1"
        name = "name_1"

        expected_docs = [
            {
                "uid": uid,
                "created_on": created_on,
                "created_by": created_by,
                "updated_on": updated_on,
                "updated_by": updated_by,
                "name": name,
            }
        ]

        # bureau config to return
        solution_config = SolutionConfiguration()
        solution_config.uid = uid
        solution_config.created_on = created_on
        solution_config.created_by = created_by
        solution_config.updated_on = updated_on
        solution_config.updated_by = updated_by
        solution_config.config = {
            "name": name,
        }

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search
        mock_search.execute.return_value = [solution_config]

        with patch.object(
            SolutionConfiguration, "create_search_object", return_value=mock_search
        ):

            # ACT
            actual_docs = (
                solution_configuration_repository.opensearch_get_billing_service_dictionaries()
            )
            # ASSERT

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with(
                "term", config_type=SolutionConfigTypeEnum.BILLING_SERVICE
            )

            # check return value
            self.assertListEqual(expected_docs, actual_docs)

    def test_opensearch_get_exclusion_default_dictionaries(self):
        """test get exclusion default dictionaries"""
        # ARRANGE
        uid = "uid_1"
        created_on = datetime.datetime.now()
        created_by = "created_by_1"
        updated_on = datetime.datetime.now()
        updated_by = "updated_by_1"
        criteria = "criteria_1"
        return_score = True
        default_score = 9000

        expected_docs = [
            {
                "uid": uid,
                "created_on": created_on,
                "created_by": created_by,
                "updated_on": updated_on,
                "updated_by": updated_by,
                "criteria": criteria,
                "return_score": return_score,
                "default_score": default_score,
            }
        ]

        # bureau config to return
        solution_config = SolutionConfiguration()
        solution_config.uid = uid
        solution_config.created_on = created_on
        solution_config.created_by = created_by
        solution_config.updated_on = updated_on
        solution_config.updated_by = updated_by
        solution_config.config = {
            "criteria": criteria,
            "return_score": return_score,
            "default_score": default_score,
        }

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search
        mock_search.execute.return_value = [solution_config]

        with patch.object(
            SolutionConfiguration, "create_search_object", return_value=mock_search
        ):

            # ACT
            actual_docs = (
                solution_configuration_repository.opensearch_get_exclusion_default_dictionaries()
            )
            # ASSERT

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with(
                "term", config_type=SolutionConfigTypeEnum.EXCLUSION_DEFAULT
            )

            # check return value
            self.assertListEqual(expected_docs, actual_docs)

    def test_opensearch_get_bureau_certificate_dictionaries(self):
        """test get bureau certificates"""
        # ARRANGE
        uid = "uid_1"
        created_on = datetime.datetime.now()
        created_by = "created_by_1"
        updated_on = datetime.datetime.now()
        updated_by = "updated_by_1"
        name = "name_1"

        expected_docs = [
            {
                "uid": uid,
                "created_on": created_on,
                "created_by": created_by,
                "updated_on": updated_on,
                "updated_by": updated_by,
                "name": name,
            }
        ]

        # bureau config to return
        solution_config = SolutionConfiguration()
        solution_config.uid = uid
        solution_config.created_on = created_on
        solution_config.created_by = created_by
        solution_config.updated_on = updated_on
        solution_config.updated_by = updated_by
        solution_config.config = {
            "name": name,
        }

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search
        mock_search.execute.return_value = [solution_config]

        with patch.object(
            SolutionConfiguration, "create_search_object", return_value=mock_search
        ):

            # ACT
            actual_docs = (
                solution_configuration_repository.opensearch_get_bureau_certificate_dictionaries()
            )
            # ASSERT

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with(
                "term", config_type=SolutionConfigTypeEnum.BUREAU_CERTIFICATE
            )

            # check return value
            self.assertListEqual(expected_docs, actual_docs)

    def test_opensearch_get_keyword_dictionaries(self):
        """get keyword dictionaries"""
        # ARRANGE
        uid = "uid_1"
        created_on = datetime.datetime.now()
        created_by = "created_by_1"
        updated_on = datetime.datetime.now()
        updated_by = "updated_by_1"
        keyword = "name_1"

        expected_docs = [
            {
                "uid": uid,
                "created_on": created_on,
                "created_by": created_by,
                "updated_on": updated_on,
                "updated_by": updated_by,
                "keyword": keyword,
            }
        ]

        # bureau config to return
        solution_config = SolutionConfiguration()
        solution_config.uid = uid
        solution_config.created_on = created_on
        solution_config.created_by = created_by
        solution_config.updated_on = updated_on
        solution_config.updated_by = updated_by
        solution_config.config = {
            "keyword": keyword,
        }

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search
        mock_search.execute.return_value = [solution_config]

        with patch.object(
            SolutionConfiguration, "create_search_object", return_value=mock_search
        ):

            # ACT
            actual_docs = (
                solution_configuration_repository.opensearch_get_keyword_dictionaries()
            )
            # ASSERT

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with(
                "term", config_type=SolutionConfigTypeEnum.KEYWORD
            )

            # check return value
            self.assertListEqual(expected_docs, actual_docs)

    def test_opensearch_get_bureau_datasource_dictionaries(self):
        # ARRANGE
        uid = "uid_1"
        created_on = datetime.datetime.now()
        created_by = "created_by_1"
        updated_on = datetime.datetime.now()
        updated_by = "updated_by_1"
        bureau_datasource = {"source": "value"}

        expected_docs = [
            {
                "uid": uid,
                "created_on": created_on,
                "created_by": created_by,
                "updated_on": updated_on,
                "updated_by": updated_by,
                "bureau_datasource": bureau_datasource,
            }
        ]

        # bureau config to return
        solution_config = SolutionConfiguration()
        solution_config.uid = uid
        solution_config.created_on = created_on
        solution_config.created_by = created_by
        solution_config.updated_on = updated_on
        solution_config.updated_by = updated_by
        solution_config.config = {
            "bureau_datasource": bureau_datasource,
        }

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search
        mock_search.execute.return_value = [solution_config]

        with patch.object(
            SolutionConfiguration, "create_search_object", return_value=mock_search
        ):

            # ACT
            actual_docs = (
                solution_configuration_repository.opensearch_get_bureau_datasource_dictionaries()
            )
            # ASSERT

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with(
                "term", config_type=SolutionConfigTypeEnum.BUREAU_DATA_SOURCE
            )

            # check return value
            self.assertListEqual(expected_docs, actual_docs)

    def test_opensearch_create_solution_config(self):
        """test create document"""

        # ARRANGE
        expected_solution = SolutionConfiguration()

        with patch.object(
            SolutionConfiguration, "insert_document"
        ) as mock_insert_document:
            # ACT
            solution_configuration_repository.opensearch_create_solution_config(
                expected_solution
            )

            # ASSERT
            mock_insert_document.assert_called_once_with(refresh="false")
