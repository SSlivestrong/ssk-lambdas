"""Unit tests for BatchOrchestratorMessageSchema"""

import unittest
from pydantic import ValidationError
from ascendops_commonlib.schemas.pydantic.batch_consumers.batch_orchestrator_message_schema import (
    BatchOrchestratorMessageSchema,
)
from ascendops_commonlib.enums.batch_consumers.batch_app_name_enum import (
    BatchAppNameEnum,
)
from ascendops_commonlib.enums.batch_consumers.batch_orchestrator_message_type_enum import (
    BatchOrchestratorMessageTypeEnum,
)


class TestBatchOrchestratorMessageSchema(unittest.TestCase):
    """Unit tests for BatchOrchestratorMessageSchema"""

    def test_constructor_all_nulls_exception(self):
        """tests constructor throws exceptions with all null fields"""

        # ACT and ASSERT
        with self.assertRaises(ValidationError) as context_manaager:
            BatchOrchestratorMessageSchema(
                message_source=None,
                message_type=None,
                go_campaign_id=None,
                ops_exec_chain_id=None,
                model_uid=None,
                go_model_exec_id=None,
            )

        # counts the number of errors attributed to the fields in the schema
        error_schema_field_count = {
            "message_source": 0,
            "message_type": 0,
            "go_campaign_id": 0,
            "ops_exec_chain_id": 0,
            "model_uid": 0,
            "go_model_exec_id": 0,
        }

        # read errors from ValidationError
        validation_errors = context_manaager.exception.errors()

        # expecting 3 validation errors
        self.assertEqual(len(validation_errors), 4)

        for error in validation_errors:
            schema_fields_involved_in_error = error.get("loc")
            for field in schema_fields_involved_in_error:
                self.assertTrue(
                    field in error_schema_field_count,
                    f"Validation error found for unexpected field - {field}",
                )
                error_schema_field_count[field] += 1

        # check that expected fields failed validation
        self.assertEqual(error_schema_field_count["message_source"], 1)
        self.assertEqual(error_schema_field_count["message_type"], 1)
        self.assertEqual(error_schema_field_count["go_campaign_id"], 1)
        self.assertEqual(error_schema_field_count["ops_exec_chain_id"], 1)
        self.assertEqual(error_schema_field_count["model_uid"], 0)
        self.assertEqual(error_schema_field_count["go_model_exec_id"], 0)

    def test_constructor_empty_string_exception(self):
        """Tests that schema throws exception for messages that contain empty strings"""

        # ACT and ASSERT
        with self.assertRaises(ValidationError) as context_manaager:
            BatchOrchestratorMessageSchema(
                message_source=BatchAppNameEnum.DISPATCH_CONSUMER,
                message_type=BatchOrchestratorMessageTypeEnum.START,
                go_campaign_id="",
                ops_exec_chain_id="",
                model_uid="",
                go_model_exec_id="",
            )

        # counts the number of errors attributed to the fields in the schema
        error_schema_field_count = {
            "message_source": 0,
            "message_type": 0,
            "go_campaign_id": 0,
            "ops_exec_chain_id": 0,
            "model_uid": 0,
            "go_model_exec_id": 0,
        }

        # read errors from ValidationError
        validation_errors = context_manaager.exception.errors()

        # expecting 3 validation errors
        self.assertEqual(len(validation_errors), 4)

        for error in validation_errors:
            schema_fields_involved_in_error = error.get("loc")
            for field in schema_fields_involved_in_error:
                self.assertTrue(
                    field in error_schema_field_count,
                    f"Validation error found for unexpected field - {field}",
                )
                error_schema_field_count[field] += 1

        # check that expected fields failed validation
        self.assertEqual(error_schema_field_count["message_source"], 0)
        self.assertEqual(error_schema_field_count["message_type"], 0)
        self.assertEqual(error_schema_field_count["go_campaign_id"], 1)
        self.assertEqual(error_schema_field_count["ops_exec_chain_id"], 1)
        self.assertEqual(error_schema_field_count["model_uid"], 1)
        self.assertEqual(error_schema_field_count["go_model_exec_id"], 1)

    def test_constructor_start_message_success(self):
        """tests that the start message is constructed successfully"""
        message_source = BatchAppNameEnum.DISPATCH_CONSUMER
        message_type = BatchOrchestratorMessageTypeEnum.START
        go_campaign_id = "123_campaign_id"
        ops_exec_chain_id = "123_chain_id"
        model_uid = None
        go_model_exec_id = None
        # ACT
        message = BatchOrchestratorMessageSchema(
            message_source=message_source,
            message_type=message_type,
            go_campaign_id=go_campaign_id,
            ops_exec_chain_id=ops_exec_chain_id,
            model_uid=model_uid,
            go_model_exec_id=go_model_exec_id,
        )

        self.assertEqual(message.message_source, message_source)
        self.assertEqual(message.message_type, message_type)
        self.assertEqual(message.go_campaign_id, go_campaign_id)
        self.assertEqual(message.ops_exec_chain_id, ops_exec_chain_id)
        self.assertEqual(message.model_uid, model_uid)
        self.assertEqual(message.go_model_exec_id, go_model_exec_id)

    def test_constructor_exec_end_message_success(self):
        """tests success case for exec end message construction"""

        message_source = BatchAppNameEnum.POST_PROCESS_END
        message_type = BatchOrchestratorMessageTypeEnum.EXEC_END
        go_campaign_id = "123_campaign_id"
        ops_exec_chain_id = "123_chain_id"
        model_uid = "123_model_uid"
        go_model_exec_id = "123_go_model_exec_id"
        # ACT
        message = BatchOrchestratorMessageSchema(
            message_source=message_source,
            message_type=message_type,
            go_campaign_id=go_campaign_id,
            ops_exec_chain_id=ops_exec_chain_id,
            model_uid=model_uid,
            go_model_exec_id=go_model_exec_id,
        )

        self.assertEqual(message.message_source, message_source)
        self.assertEqual(message.message_type, message_type)
        self.assertEqual(message.go_campaign_id, go_campaign_id)
        self.assertEqual(message.ops_exec_chain_id, ops_exec_chain_id)
        self.assertEqual(message.model_uid, model_uid)
        self.assertEqual(message.go_model_exec_id, go_model_exec_id)

    def test_constructor_custom_validator_exec_end_exception(self):
        """tests the custom validator based on message type"""
        with self.assertRaises(ValidationError) as context_manaager:
            BatchOrchestratorMessageSchema(
                message_source=BatchAppNameEnum.POST_PROCESS_END,
                message_type=BatchOrchestratorMessageTypeEnum.EXEC_END,
                go_campaign_id="123_campaign_id",
                ops_exec_chain_id="123_chain_id",
                model_uid=None,
                go_model_exec_id=None,
            )

            # counts the number of errors attributed to the fields in the schema
        error_schema_field_count = {
            "message_source": 0,
            "message_type": 0,
            "go_campaign_id": 0,
            "ops_exec_chain_id": 0,
            "model_uid": 0,
            "go_model_exec_id": 0,
        }

        # read errors from ValidationError
        validation_errors = context_manaager.exception.errors()

        # expecting 3 validation errors
        self.assertEqual(len(validation_errors), 2)

        for error in validation_errors:
            schema_fields_involved_in_error = error.get("loc")
            for field in schema_fields_involved_in_error:
                self.assertTrue(
                    field in error_schema_field_count,
                    f"Validation error found for unexpected field - {field}",
                )
                error_schema_field_count[field] += 1

        # check that expected fields failed validation
        self.assertEqual(error_schema_field_count["message_source"], 0)
        self.assertEqual(error_schema_field_count["message_type"], 0)
        self.assertEqual(error_schema_field_count["go_campaign_id"], 0)
        self.assertEqual(error_schema_field_count["ops_exec_chain_id"], 0)
        self.assertEqual(error_schema_field_count["model_uid"], 1)
        self.assertEqual(error_schema_field_count["go_model_exec_id"], 1)

    def test_message_model_dump(self):
        """tests that message dumped to a dictionary has value expected by consumer"""

        # ARRANGE
        expected_message_dict = {
            "message_source": "post-process-end",
            "message_type": "exec-end",
            "go_campaign_id": "123_campaign_id",
            "ops_exec_chain_id": "123_chain_id",
            "model_uid": "123_model_uid",
            "go_model_exec_id": "123_go_model_exec_id",
        }

        message = BatchOrchestratorMessageSchema(
            message_source=BatchAppNameEnum.POST_PROCESS_END,
            message_type=BatchOrchestratorMessageTypeEnum.EXEC_END,
            go_campaign_id="123_campaign_id",
            ops_exec_chain_id="123_chain_id",
            model_uid="123_model_uid",
            go_model_exec_id="123_go_model_exec_id",
        )

        # ACT
        actual_message_dict = message.model_dump()

        # ASSERT
        self.assertDictEqual(actual_message_dict, expected_message_dict)
