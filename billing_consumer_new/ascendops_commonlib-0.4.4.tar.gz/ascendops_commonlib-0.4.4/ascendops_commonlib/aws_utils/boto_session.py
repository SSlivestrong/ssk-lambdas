
import botocore.session, boto3

class BotoSession:
    botocore_session = None
    boto3_session = None

    @staticmethod
    def init(region_name=None, profile=None):
        if not BotoSession.botocore_session:
            BotoSession.botocore_session = botocore.session.get_session()
            BotoSession.boto3_session = boto3.Session(
                profile_name=profile,
                region_name=region_name,
                botocore_session=BotoSession.botocore_session)