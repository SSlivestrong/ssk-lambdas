""" Entity to represent client contract entity """
from datetime import datetime
from typing import Optional
from opensearch_dsl import Text, Keyword, Integer, Date


from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.entities.opensearch.fields.na_enum_opensearch_field import (
    NAEnumOpensearchField,
)
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.enums.client_contract.model_execution_type_enum import (
    ModelExecutionTypeModeEnum,
)
from ascendops_commonlib.enums.client_contract.client_contract_model_type_enum import (
    ClientContractModelTypeEnum,
)


class ClientContract(NABaseDocument):
    """Defining properties for client contract not part of BaseDocument"""

    client_uid: Optional[str] = Keyword()
    client_name: Optional[str] = Keyword()
    email: Optional[str] = Text()
    phone_number: Optional[str] = Text()
    name: Optional[str] = Keyword()
    execution_type: Optional[ModelExecutionTypeModeEnum] = NAEnumOpensearchField(
        ModelExecutionTypeModeEnum
    )
    model_type: Optional[ClientContractModelTypeEnum] = NAEnumOpensearchField(
        ClientContractModelTypeEnum
    )
    contract_start_date: Optional[datetime] = Date(format="yyyy-MM-dd")
    contract_end_date: Optional[datetime] = Date(format="yyyy-MM-dd")
    max_model_count: Optional[int] = Integer()

    def update_from_dict(self, dictionary: dict) -> None:
        """updates client properties from a dictionary"""

        if "name" in dictionary:
            self.name = dictionary.get("name")
        if "email" in dictionary:
            self.email = dictionary.get("email")
        if "phone_number" in dictionary:
            self.phone_number = dictionary.get("phone_number")
        if "execution_type" in dictionary:
            self.execution_type = dictionary.get("execution_type")
        if "model_type" in dictionary:
            self.model_type = dictionary.get("model_type")
        if "contract_start_date" in dictionary:
            self.contract_start_date = dictionary.get("contract_start_date")
        if "contract_end_date" in dictionary:
            self.contract_end_date = dictionary.get("contract_end_date")
        if "max_model_count" in dictionary:
            self.max_model_count = dictionary.get("max_model_count")

        super().update_from_dict(dictionary)

    class Index:
        """Opensearch Index where client documents are stored"""

        name: str = ops_config.CLIENT_CONTRACT_INDEX_NAME
