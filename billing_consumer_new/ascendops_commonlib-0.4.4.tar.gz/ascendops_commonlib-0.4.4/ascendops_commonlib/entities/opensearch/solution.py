""" Entity to represent Solution source """
from typing import Optional
from opensearch_dsl import Nested, Text, Keyword, Boolean, InnerDoc, Object, MetaField

from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.entities.opensearch.fields.na_enum_opensearch_field import (
    NAEnumOpensearchField,
)
from ascendops_commonlib.enums.solution.solution_status_enum import SolutionStatusEnum
from ascendops_commonlib.ops_utils import ops_config


class ExclusionDefault(InnerDoc):
    """Defines Exclusion defaults of a model"""

    criteria: Optional[str] = Keyword()
    default_score: Optional[str] = Keyword()
    return_score: Optional[bool] = Boolean()


class HitProductCode(InnerDoc):
    """defines a hit product code"""

    hit: Optional[str] = Keyword()


class HitNoHitProductCode(InnerDoc):
    """defines hit and no hit product code"""

    hit: Optional[str] = Keyword()
    nohit: Optional[str] = Keyword()


class IncludeAttribute(InnerDoc):
    """Defines  include attributes of a model"""

    selection: Optional[str] = Keyword()
    selected_attributes: Optional["list[str]"] = Text(multi=True)


class SolutionModel(InnerDoc):
    """Defines solution model details"""

    model_name: Optional[str] = Keyword()
    model_type_indicator: Optional[str] = Keyword()
    model_display_indicator: Optional[str] = Keyword()
    model_response: Optional[str] = Keyword()
    model_type: Optional[str] = Keyword()
    segment: Optional[str] = Keyword()
    score_fifth_factor_code_segment: Optional[str] = Keyword()
    include_attributes: Optional[IncludeAttribute] = Object(IncludeAttribute)
    product_code: Optional[HitNoHitProductCode] = Object(HitNoHitProductCode)
    exclusion_scores: Optional["list[str]"] = Text(multi=True)
    conditional_attributes: Optional[dict] = Object()


class SolutionCriteria(InnerDoc):
    """Defines solution criteria details"""

    criteria_name: Optional[str] = Keyword()
    criteria_code: Optional[str] = Keyword()
    is_optional: Optional[bool] = Boolean()


class Solution(NABaseDocument):
    """Opensearch Entity to represent solution entity"""

    solution_id: Optional[str] = Keyword()
    version: Optional[str] = Keyword()
    status: Optional[SolutionStatusEnum] = NAEnumOpensearchField(SolutionStatusEnum)
    solution_type: Optional[str] = Keyword()
    platform_version: Optional[str] = Keyword()
    description: Optional[str] = Text()
    is_available_for_integration_testing: Optional[bool] = Boolean()
    exclusion_defaults: Optional["list[ExclusionDefault]"] = Object(ExclusionDefault)
    product_code_stand_alone_custom_model: Optional[HitProductCode] = Object(
        HitProductCode
    )
    product_code_excluded_in_billing: Optional["list[str]"] = Text(multi=True)
    product_code_map: Optional[dict] = Object()
    send_billing_message: Optional[bool] = Boolean()
    models: Optional["list[SolutionModel]"] = Nested(SolutionModel)
    product_code: Optional[HitNoHitProductCode] = Object(HitNoHitProductCode)
    send_parsed_keyword_to_dcr: Optional[bool] = Boolean()
    prefix_zeros_for_segments: Optional["list[str]"] = Text(multi=True)
    instant_prescreen: Optional[bool] = Boolean()
    instant_prequal: Optional[bool] = Boolean()
    instant_credit: Optional[bool] = Boolean()
    prescreen_of_one: Optional[bool] = Boolean()
    prequal_of_one: Optional[bool] = Boolean()
    enable_cache_credit_profile: Optional[bool] = Boolean()
    enable_cache_solution_document: Optional[bool] = Boolean()
    data_configuration: Optional[dict] = Object()
    criteria: Optional["list[SolutionCriteria]"] = Object(SolutionCriteria)
    keywords: Optional["list[str]"] = Text(multi=True)
    fattr_attributes_response: Optional[str] = Keyword()
    auto_generate_client_reference_number: Optional[bool] = Boolean()
    preferred_inquiry_type: Optional[str] = Keyword()
    use_881_model_attributes: Optional[bool] = Boolean()
    address_mismatch_indicator: Optional[bool] = Boolean()
    is_matterhorn_migration: Optional[bool] = Boolean()

    class Index:
        """Opensearch Index where solution documents are stored"""

        name: str = ops_config.SOLUTION_INDEX_NAME

    class Meta:
        """Override default meta behavior from base document"""

        dynamic: MetaField = MetaField("false")
