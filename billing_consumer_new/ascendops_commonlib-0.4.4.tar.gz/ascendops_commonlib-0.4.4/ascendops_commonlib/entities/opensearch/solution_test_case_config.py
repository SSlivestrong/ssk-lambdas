""" configuration for a specific solution test case """
from opensearch_dsl import Text, Keyword, Float, Boolean

from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.entities.opensearch.fields.na_enum_opensearch_field import (
    NAEnumOpensearchField,
)
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.enums.solution.solution_test_type_enum import (
    SolutionTestTypeEnum,
)


class SolutionTestCaseConfig(NABaseDocument):
    """configuration for a specific solution test case"""

    # test case alias
    alias: str = Keyword()
    # test case display name
    name: str = Keyword()
    # version of the test
    version: float = Float()
    # denotes the type of test. This affects how the results of the test are evaluated
    test_type: SolutionTestTypeEnum = NAEnumOpensearchField(SolutionTestTypeEnum)
    # testing pii that results in the test case specified by alias/ name.
    input_pii: str = Text()
    daas_test: bool = Boolean()

    class Index:
        """index where solution test case config documents are stored"""

        name: str = ops_config.SOLUTION_TEST_CASE_CONFIG_INDEX_NAME
