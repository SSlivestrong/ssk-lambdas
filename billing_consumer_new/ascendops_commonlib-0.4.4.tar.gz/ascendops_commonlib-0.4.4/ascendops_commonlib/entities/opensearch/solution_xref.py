""" Entity to represent solution xref """
from typing import Optional
from opensearch_dsl import Keyword, Boolean

from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.ops_utils import ops_config


class SolutionXRef(NABaseDocument):
    """Opensearch Entity to represent solution xref"""

    r_keyword: Optional[str] = Keyword()
    m_info_keyword: Optional[str] = Keyword()
    silent_launch_flag: Optional[bool] = Boolean()
    exclude_keyword: Optional[str] = Keyword()

    class Index:
        """Opensearch Index where solution xref documents are stored"""

        name: str = ops_config.SOLUTION_XREF_INDEX_NAME
