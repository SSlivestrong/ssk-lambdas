""" Entity to represent strategy entity """
from typing import Optional
from opensearch_dsl import Text, Keyword, Object, MetaField

from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.ops_utils import ops_config


class Strategy(NABaseDocument):
    """Defining properties for strategy not part of BaseDocument"""

    strategy_id: Optional[str] = Keyword()
    strategy_path: Optional[str] = Text()
    mapping_doc: Optional[str] = Text()
    swagger_doc: Optional[str] = Text()
    da_agent_version: Optional[str] = Keyword()
    system_datasets: Optional[dict] = Object()
    client_uid: Optional[str] = Keyword()

    class Index:
        """Opensearch Index where strategy documents are stored"""

        name: str = ops_config.DECISION_INDEX_NAME

    class Meta:
        """Defines properties for Opensearch Mapping"""

        # overrides default dynamic value
        # controls whether new fields are added dynamically to index mapping
        dynamic: MetaField = MetaField("false")
