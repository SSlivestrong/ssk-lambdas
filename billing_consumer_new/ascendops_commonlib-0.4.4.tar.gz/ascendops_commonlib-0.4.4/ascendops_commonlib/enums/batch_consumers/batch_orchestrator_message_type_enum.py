""" Represents the type of message sent to batch orchestrator app """
from enum import Enum, unique

@unique
# Inherits from str as well so that enum is json serializable
class BatchOrchestratorMessageTypeEnum(str, Enum):
    """Represents the type of message sent to batch orchestrator app"""

    # this message type is sent once per campaign. This message type starts the model chain execution
    START: str = "start"
    # this message type may be sent multiple times per campaign. This message type means a specific model in the chain has finished execution
    EXEC_END: str = "exec-end"
