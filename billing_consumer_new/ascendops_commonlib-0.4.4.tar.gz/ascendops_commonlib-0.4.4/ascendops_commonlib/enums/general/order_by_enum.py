""" Enum that defines the how to order a list """
from enum import Enum, unique

# Inherits from str as well so that enum is json serializable
@unique
class OrderByEnum(str, Enum):
    """Enum that defines the how to order a list"""

    DESC: str = "desc"
    ASC: str = "asc"
