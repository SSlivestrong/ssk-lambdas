""" Enum that defines the category of a model used by a model """
from enum import Enum

# Inherits from str as well so that enum is json serializable
class ModelCategoryEnum(Enum):
    """ Defines the type of an input feature """
    # feature is defined by Experian datasets
    SCORE = "score"
    # feature is defined by external sources, such as Clarity
    SCORE_AAC = "score_aac"
    # feature is defined by marketing
    MULTI_SCORE = "multi_score"
    # feature is defined by client
    MULTI_SCORE_AAC = "multi_score_aac"
    # feature is a Key (row identifier/experian_consumer_key, etc)
    ATTRIBUTE = "attribute"
    # feature is an Object (to be used for Decision (PL) models)
    OBJECT = "object"
    # feature is a Decision model ouptut
    DECISION = "decision"
