""" Enum that defines the lifecycle statuses available for a solution """

from enum import Enum, unique


# Inherits from str as well so that enum is json serializable
@unique
class SolutionStatusEnum(str, Enum):
    """defines the lifecycle statuses available for a solution"""

    DRAFT: str = "draft"
    TEST: str = "test"
    READY: str = "ready"
    PROD: str = "prod"
    ARCHIVED: str = "archived"
