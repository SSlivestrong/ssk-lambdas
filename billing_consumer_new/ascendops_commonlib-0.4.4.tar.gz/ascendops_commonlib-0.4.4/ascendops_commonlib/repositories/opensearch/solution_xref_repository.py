"""
    Performs operations relatated to soutions
"""
from ascendops_commonlib.entities.opensearch.solution_xref import SolutionXRef


def opensearch_get_xref_documents(**kwargs) -> list[SolutionXRef]:
    """To retrieve a Solution document with uid
    Parameters
        solution_id - Optional[str]: solution id to filter xref docs by
        include_fields - Optional[list[str]]: document fields to include in returned document
        exclude_fields - Optional[list[str]]: document fields to exclude in returned document
    Return:
        Solution_xref object
    """
    solution_id = kwargs.get("solution_id")
    include_fields = kwargs.get("include_fields")
    exclude_fields = kwargs.get("exclude_fields")

    search = SolutionXRef.create_search_object(
        include_fields=include_fields, exclude_fields=exclude_fields
    )

    term_queries_added = False

    if solution_id is not None:
        search = search.query("term", solution_id=solution_id)
        term_queries_added = True
    if not term_queries_added:
        search = search.query("match_all")
    return search.execute().hits


def opensearch_get_xref(uid) -> SolutionXRef:
    """To retrieve a Solution document with uid
    Return:
        Solution_xref object
    """
    return SolutionXRef.get(uid)


def opensearch_create_xref(
    solution_xref: SolutionXRef, created_by: str, refresh: str = "false"
) -> SolutionXRef:
    """To create a Solution extra references
    Params:
        SolutionXRef: defines properties of solution extra references object
        created_by: creator of solution xref
        refresh: specifies opensearch refresh behavior

    Return:
        SolutionXRef object
    """
    SolutionXRef.created_by = created_by
    solution_xref.insert_document(refresh=refresh)
    return solution_xref


def opensearch_update_xref(
    solution_xref: SolutionXRef, update_json: dict, refresh: str = "wait_for"
) -> SolutionXRef:
    """To update a solution extra references document
    Params:
        solution_xref: defines properties of solution object
        update_json: contains properties to update
        refresh: specifies opensearch refresh behavio
    Return:
        Solution extra references object
    """
    for row in update_json:
        solution_xref[row] = update_json[row]
    solution_xref.update_document(refresh=refresh)
    return solution_xref
