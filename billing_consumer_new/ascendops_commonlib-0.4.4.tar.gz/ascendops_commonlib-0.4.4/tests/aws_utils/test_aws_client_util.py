"""
This module contains unit tests for 'sts_client.py' module
"""

import unittest
from unittest.mock import MagicMock, patch
from ascendops_commonlib.aws_utils.aws_client_util import STSClientUtil

class TestSTSClientUtil(unittest.TestCase):
    """
    class for testing STSClientUtil class
    """

    # @patch('boto3.Session')
    # def test_create_client_with_role(self, mock_session):
    #     region = "us-east-1"
    #     profile_name = "default"
    #     service = "s3"
    #     role_arn = "arn:aws:iam::12345789012:role/test-role"

    #     mock_session.return_value.client.return_value.assume_role.return_value = {
    #         "Credentials": {
    #             "AccessKeyId": "pytest_access_key",
    #             "SecretAccessKey": "pytest_secret_key",
    #             "SessionToken": "pytest_session_token"
    #         }
    #     }

    #     aws_client = STSClientUtil(region, profile_name)
    #     client = aws_client.get_client(service, role_arn)
    #     self.assertIsNotNone(client)

    #     mock_session.assert_called_once_with(profile_name=profile_name, region_name=region)
    #     mock_session.return_value.client.assert_called_once_with("sts")
    #     mock_session.return_value.client.return_value.assume_role.assert_called_once_with(
    #         RoleArn=role_arn,
    #         RoleSessionName="AssumeRoleSession1"
    #     )

    # def setUp(self):
    #     """
    #     initialize the client
    #     """
    #     self.client = STSClientUtil()

    # def test_get_client_without_assume_role(self):
    #     """
    #     get client with no role assume
    #     """
    #     s3_client = self.client.get_client("s3")
    #     self.assertEqual(s3_client._service_model.service_name, "s3")

    # def test_get_client_with_assume_role(self):
    #     """
    #     get client with assume role
    #     """
    #     mock_sts_client = MagicMock()
    #     mock_sts_client.assume_role.return_value = MagicMock(return_value={
    #         "Credentials": {
    #             "AccessKeyId": "pytest_access_key",
    #             "SecretAccessKey": "pytest_secret_key",
    #             "SessionToken": "pytest_session_token"
    #         }
    #     })

    #     with patch("boto3.client", return_value=mock_sts_client):
    #         s3_client = self.client.get_client("s3", role_arn="arn:aws:iam::123456789012:role/test-role")
    #         self.assertEqual(s3_client._service_model.service_name, "s3")

    # def test_get_client_no_credentials_error(self):
    #     with self.assertRaises(Exception) as context:
    #         s3_client = self.client.get_client("s3", t="profile-not-exist")
    #     self.assertIn("Credentials not available: ", str(context.exception))
