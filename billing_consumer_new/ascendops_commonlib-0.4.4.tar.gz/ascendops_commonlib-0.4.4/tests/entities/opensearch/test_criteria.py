""" Unit tests for Criteria entity """

import unittest
from datetime import datetime
from ascendops_commonlib.entities.opensearch.criteria import Criteria
from ascendops_commonlib.enums.criteria.criteria_status_enum import CriteriaStatusEnum
from ascendops_commonlib.enums.criteria.offer_generator_version_enum import (
    OfferGeneratorVersionEnum,
)


class TestCriteria(unittest.TestCase):
    """Unit tests for Criteria"""

    def setUp(self) -> None:
        """Creates criteria object populated with fields before each test"""
        self.criteria = Criteria()

        self.original_criteria_name = "name_1"
        self.original_criteria_description = "description_1"
        self.original_criteria_code = "12345678"

        self.original_client_alias = "experian"
        self.original_client_uid = "123456"
        self.original_criteria_artifacts = []
        self.original_features = []

        self.original_outputs = []
        self.original_offer_generator_version = OfferGeneratorVersionEnum.SSOG_VERSION
        self.original_version = ""
        self.original_system_datasets = {}
        self.original_status = CriteriaStatusEnum.DRAFT
        self.original_rules = []
        self.original_deployed_on = None
        self.original_deployed_by = None
        self.original_generic_datasets = []
        self.original_external_datasets = []
        self.original_marketing_datasets = []
        self.original_custom_datasets = []
        self.original_ops_model_datasets = []

        self.criteria.criteria_name = self.original_criteria_name
        self.criteria.criteria_description = self.original_criteria_description
        self.criteria.criteria_code = self.original_criteria_code
        self.criteria.client_alias = self.original_client_alias
        self.criteria.client_uid = self.original_client_uid
        self.criteria.criteria_artifacts = self.original_criteria_artifacts
        self.criteria.features = self.original_features
        self.criteria.outputs = self.original_outputs
        self.criteria.offer_generator_version = self.original_offer_generator_version
        self.criteria.version = self.original_version
        self.criteria.system_datasets = self.original_system_datasets
        self.criteria.status = self.original_status
        self.criteria.rules = self.original_rules
        self.criteria.deployed_on = self.original_deployed_on
        self.criteria.deployed_by = self.original_deployed_by
        self.criteria.generic_datasets = self.original_generic_datasets
        self.criteria.external_datasets = self.original_external_datasets
        self.criteria.marketing_datasets = self.original_marketing_datasets
        self.criteria.custom_datasets = self.original_custom_datasets
        self.criteria.ops_model_datasets = self.original_ops_model_datasets

    def test_update_from_dict_full_payload(self) -> None:
        """Test update from dict with all editable fields"""

        # ARRANGE
        # set update fields
        updated_criteria_name = "name_2"
        updated_status = CriteriaStatusEnum.ACTIVE
        updated_deployed_on = datetime.now()
        updated_deployed_by = "Jane Doe"

        # ACT
        self.criteria.update_from_dict(
            {
                "criteria_name": updated_criteria_name,
                "status": updated_status,
                "deployed_on": updated_deployed_on,
                "deployed_by": updated_deployed_by,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(
            self.criteria.criteria_description, self.original_criteria_description
        )
        self.assertEqual(self.criteria.criteria_code, self.original_criteria_code)
        self.assertEqual(self.criteria.client_alias, self.original_client_alias)
        self.assertEqual(self.criteria.client_uid, self.original_client_uid)
        self.assertEqual(
            self.criteria.criteria_artifacts, self.original_criteria_artifacts
        )
        self.assertEqual(self.criteria.features, self.original_features)
        self.assertEqual(self.criteria.outputs, self.original_outputs)
        self.assertEqual(
            self.criteria.offer_generator_version, self.original_offer_generator_version
        )
        self.assertEqual(self.criteria.version, self.original_version)
        self.assertEqual(self.criteria.system_datasets, self.original_system_datasets)
        self.assertEqual(self.criteria.rules, self.original_rules)
        self.assertEqual(self.criteria.generic_datasets, self.original_generic_datasets)
        self.assertEqual(
            self.criteria.external_datasets, self.original_external_datasets
        )
        self.assertEqual(
            self.criteria.marketing_datasets, self.original_marketing_datasets
        )
        self.assertEqual(self.criteria.custom_datasets, self.original_custom_datasets)
        self.assertEqual(
            self.criteria.ops_model_datasets, self.original_ops_model_datasets
        )

        # these fields should be updated
        self.assertEqual(self.criteria.criteria_name, updated_criteria_name)
        self.assertEqual(self.criteria.status, updated_status)
        self.assertEqual(self.criteria.deployed_on, updated_deployed_on)
        self.assertEqual(self.criteria.deployed_by, updated_deployed_by)

    def test_update_from_dict_payload_with_nulls(self) -> None:
        """Test update from dict updates fields with null if given in payload"""

        # ARRANGE
        # set update fields
        updated_criteria_name = None
        updated_status = None
        updated_deployed_on = None
        updated_deployed_by = None

        # ACT
        self.criteria.update_from_dict(
            {
                "criteria_name": updated_criteria_name,
                "status": updated_status,
                "deployed_on": updated_deployed_on,
                "deployed_by": updated_deployed_by,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(
            self.criteria.criteria_description, self.original_criteria_description
        )
        self.assertEqual(self.criteria.criteria_code, self.original_criteria_code)
        self.assertEqual(self.criteria.client_alias, self.original_client_alias)
        self.assertEqual(self.criteria.client_uid, self.original_client_uid)
        self.assertEqual(
            self.criteria.criteria_artifacts, self.original_criteria_artifacts
        )
        self.assertEqual(self.criteria.features, self.original_features)
        self.assertEqual(self.criteria.outputs, self.original_outputs)
        self.assertEqual(
            self.criteria.offer_generator_version, self.original_offer_generator_version
        )
        self.assertEqual(self.criteria.version, self.original_version)
        self.assertEqual(self.criteria.system_datasets, self.original_system_datasets)
        self.assertEqual(self.criteria.rules, self.original_rules)
        self.assertEqual(self.criteria.generic_datasets, self.original_generic_datasets)
        self.assertEqual(
            self.criteria.external_datasets, self.original_external_datasets
        )
        self.assertEqual(
            self.criteria.marketing_datasets, self.original_marketing_datasets
        )
        self.assertEqual(self.criteria.custom_datasets, self.original_custom_datasets)
        self.assertEqual(
            self.criteria.ops_model_datasets, self.original_ops_model_datasets
        )

        # these fields should be updated
        self.assertEqual(self.criteria.criteria_name, updated_criteria_name)
        self.assertEqual(self.criteria.status, updated_status)
        self.assertEqual(self.criteria.deployed_on, updated_deployed_on)
        self.assertEqual(self.criteria.deployed_by, updated_deployed_by)

    def test_update_from_dict_partial_payload(self) -> None:
        """Tests that only fields included in dict update in criteria"""
        # ARRANGE
        # set update fields
        updated_status = CriteriaStatusEnum.ACTIVE
        updated_deployed_on = datetime.now()
        updated_deployed_by = "Jane Doe"

        # ACT
        self.criteria.update_from_dict(
            {
                "status": updated_status,
                "deployed_on": updated_deployed_on,
                "deployed_by": updated_deployed_by,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(
            self.criteria.criteria_description, self.original_criteria_description
        )
        self.assertEqual(self.criteria.criteria_code, self.original_criteria_code)
        self.assertEqual(self.criteria.client_alias, self.original_client_alias)
        self.assertEqual(self.criteria.client_uid, self.original_client_uid)
        self.assertEqual(
            self.criteria.criteria_artifacts, self.original_criteria_artifacts
        )
        self.assertEqual(self.criteria.features, self.original_features)
        self.assertEqual(self.criteria.outputs, self.original_outputs)
        self.assertEqual(
            self.criteria.offer_generator_version, self.original_offer_generator_version
        )
        self.assertEqual(self.criteria.version, self.original_version)
        self.assertEqual(self.criteria.system_datasets, self.original_system_datasets)
        self.assertEqual(self.criteria.rules, self.original_rules)
        self.assertEqual(self.criteria.generic_datasets, self.original_generic_datasets)
        self.assertEqual(
            self.criteria.external_datasets, self.original_external_datasets
        )
        self.assertEqual(
            self.criteria.marketing_datasets, self.original_marketing_datasets
        )
        self.assertEqual(self.criteria.custom_datasets, self.original_custom_datasets)
        self.assertEqual(
            self.criteria.ops_model_datasets, self.original_ops_model_datasets
        )
        self.assertEqual(self.criteria.criteria_name, self.original_criteria_name)

        # these fields should be updated
        self.assertEqual(self.criteria.status, updated_status)
        self.assertEqual(self.criteria.deployed_on, updated_deployed_on)
        self.assertEqual(self.criteria.deployed_by, updated_deployed_by)

    def test_update_from_dict_payload_uneditable_field(self) -> None:
        """Verify that update does not update uneditable fields within criteria"""

        # ARRANGE
        # set update fields
        updated_criteria_name = "name_2"
        updated_status = CriteriaStatusEnum.ACTIVE
        updated_deployed_on = datetime.now()
        updated_deployed_by = "Jane Doe"

        # ACT
        self.criteria.update_from_dict(
            {
                "criteria_name": updated_criteria_name,
                "criteria_description": "new description",
                "status": updated_status,
                "deployed_on": updated_deployed_on,
                "deployed_by": updated_deployed_by,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(
            self.criteria.criteria_description, self.original_criteria_description
        )
        self.assertEqual(self.criteria.criteria_code, self.original_criteria_code)
        self.assertEqual(self.criteria.client_alias, self.original_client_alias)
        self.assertEqual(self.criteria.client_uid, self.original_client_uid)
        self.assertEqual(
            self.criteria.criteria_artifacts, self.original_criteria_artifacts
        )
        self.assertEqual(self.criteria.features, self.original_features)
        self.assertEqual(self.criteria.outputs, self.original_outputs)
        self.assertEqual(
            self.criteria.offer_generator_version, self.original_offer_generator_version
        )
        self.assertEqual(self.criteria.version, self.original_version)
        self.assertEqual(self.criteria.system_datasets, self.original_system_datasets)
        self.assertEqual(self.criteria.rules, self.original_rules)
        self.assertEqual(self.criteria.generic_datasets, self.original_generic_datasets)
        self.assertEqual(
            self.criteria.external_datasets, self.original_external_datasets
        )
        self.assertEqual(
            self.criteria.marketing_datasets, self.original_marketing_datasets
        )
        self.assertEqual(self.criteria.custom_datasets, self.original_custom_datasets)
        self.assertEqual(
            self.criteria.ops_model_datasets, self.original_ops_model_datasets
        )

        # these fields should be updated
        self.assertEqual(self.criteria.criteria_name, updated_criteria_name)
        self.assertEqual(self.criteria.status, updated_status)
        self.assertEqual(self.criteria.deployed_on, updated_deployed_on)
        self.assertEqual(self.criteria.deployed_by, updated_deployed_by)
