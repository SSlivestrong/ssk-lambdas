""" Unit tests for ClientContractModelTypeEnum """

import unittest
import json
from ascendops_commonlib.enums.client_contract.client_contract_model_type_enum import (
    ClientContractModelTypeEnum,
)


class TestClientContractModelTypeEnum(unittest.TestCase):
    """Unit tests for ClientContractModelTypeEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(
            ClientContractModelTypeEnum("internal"),
            ClientContractModelTypeEnum.INTERNAL,
        )
        self.assertEqual(
            ClientContractModelTypeEnum("ais"),
            ClientContractModelTypeEnum.AIS,
        )
        self.assertEqual(
            ClientContractModelTypeEnum("zest"),
            ClientContractModelTypeEnum.ZEST,
        )
        self.assertEqual(
            ClientContractModelTypeEnum("h2o"),
            ClientContractModelTypeEnum.H2O,
        )
        self.assertEqual(
            ClientContractModelTypeEnum("data_robot"),
            ClientContractModelTypeEnum.DATA_ROBOT,
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(ClientContractModelTypeEnum.INTERNAL.value, "internal")
        self.assertEqual(ClientContractModelTypeEnum.AIS.value, "ais")
        self.assertEqual(ClientContractModelTypeEnum.ZEST.value, "zest")
        self.assertEqual(ClientContractModelTypeEnum.H2O.value, "h2o")
        self.assertEqual(ClientContractModelTypeEnum.DATA_ROBOT.value, "data_robot")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(
            ClientContractModelTypeEnum.INTERNAL,
            ClientContractModelTypeEnum["INTERNAL"],
        )
        self.assertEqual(
            ClientContractModelTypeEnum.AIS,
            ClientContractModelTypeEnum["AIS"],
        )
        self.assertEqual(
            ClientContractModelTypeEnum.ZEST,
            ClientContractModelTypeEnum["ZEST"],
        )
        self.assertEqual(
            ClientContractModelTypeEnum.H2O,
            ClientContractModelTypeEnum["H2O"],
        )
        self.assertEqual(
            ClientContractModelTypeEnum.DATA_ROBOT,
            ClientContractModelTypeEnum["DATA_ROBOT"],
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(ClientContractModelTypeEnum.INTERNAL), '"internal"')
        self.assertEqual(json.dumps(ClientContractModelTypeEnum.AIS), '"ais"')
        self.assertEqual(json.dumps(ClientContractModelTypeEnum.ZEST), '"zest"')

        self.assertEqual(
            json.dumps(ClientContractModelTypeEnum.H2O),
            '"h2o"',
        )

        self.assertEqual(
            json.dumps(ClientContractModelTypeEnum.DATA_ROBOT),
            '"data_robot"',
        )
