""" Unit tests for SolutionConfigTypeEnum """

import unittest
import json
from ascendops_commonlib.enums.solution.solution_config_type_enum import (
    SolutionConfigTypeEnum,
)


class TestSolutionConfigTypeEnum(unittest.TestCase):
    """Unit tests for SolutionConfigTypeEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(
            SolutionConfigTypeEnum("bureau-configuration"),
            SolutionConfigTypeEnum.BUREAU_CONFIGURATION,
        )
        self.assertEqual(
            SolutionConfigTypeEnum("bureau-service"),
            SolutionConfigTypeEnum.BUREAU_SERVICE,
        )
        self.assertEqual(
            SolutionConfigTypeEnum("bureau-certificate"),
            SolutionConfigTypeEnum.BUREAU_CERTIFICATE,
        )
        self.assertEqual(
            SolutionConfigTypeEnum("keyword"), SolutionConfigTypeEnum.KEYWORD
        )
        self.assertEqual(
            SolutionConfigTypeEnum("exclusion-default"),
            SolutionConfigTypeEnum.EXCLUSION_DEFAULT,
        )
        self.assertEqual(
            SolutionConfigTypeEnum("segment"), SolutionConfigTypeEnum.SEGMENT
        )
        self.assertEqual(
            SolutionConfigTypeEnum("bureau-data-source"),
            SolutionConfigTypeEnum.BUREAU_DATA_SOURCE,
        )
        self.assertEqual(
            SolutionConfigTypeEnum("billing-service"),
            SolutionConfigTypeEnum.BILLING_SERVICE,
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(
            SolutionConfigTypeEnum.BUREAU_CONFIGURATION.value, "bureau-configuration"
        )
        self.assertEqual(SolutionConfigTypeEnum.BUREAU_SERVICE.value, "bureau-service")
        self.assertEqual(
            SolutionConfigTypeEnum.BUREAU_CERTIFICATE.value, "bureau-certificate"
        )
        self.assertEqual(SolutionConfigTypeEnum.KEYWORD.value, "keyword")
        self.assertEqual(
            SolutionConfigTypeEnum.EXCLUSION_DEFAULT.value, "exclusion-default"
        )
        self.assertEqual(SolutionConfigTypeEnum.SEGMENT.value, "segment")
        self.assertEqual(
            SolutionConfigTypeEnum.BUREAU_DATA_SOURCE.value, "bureau-data-source"
        )
        self.assertEqual(
            SolutionConfigTypeEnum.BILLING_SERVICE.value, "billing-service"
        )

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(
            SolutionConfigTypeEnum.BUREAU_CONFIGURATION,
            SolutionConfigTypeEnum["BUREAU_CONFIGURATION"],
        )
        self.assertEqual(
            SolutionConfigTypeEnum.BUREAU_SERVICE,
            SolutionConfigTypeEnum["BUREAU_SERVICE"],
        )
        self.assertEqual(
            SolutionConfigTypeEnum.BUREAU_CERTIFICATE,
            SolutionConfigTypeEnum["BUREAU_CERTIFICATE"],
        )
        self.assertEqual(
            SolutionConfigTypeEnum.KEYWORD, SolutionConfigTypeEnum["KEYWORD"]
        )
        self.assertEqual(
            SolutionConfigTypeEnum.EXCLUSION_DEFAULT,
            SolutionConfigTypeEnum["EXCLUSION_DEFAULT"],
        )
        self.assertEqual(
            SolutionConfigTypeEnum.SEGMENT, SolutionConfigTypeEnum["SEGMENT"]
        )
        self.assertEqual(
            SolutionConfigTypeEnum.BUREAU_DATA_SOURCE,
            SolutionConfigTypeEnum["BUREAU_DATA_SOURCE"],
        )
        self.assertEqual(
            SolutionConfigTypeEnum.BILLING_SERVICE,
            SolutionConfigTypeEnum["BILLING_SERVICE"],
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(
            json.dumps(SolutionConfigTypeEnum.BUREAU_CONFIGURATION),
            '"bureau-configuration"',
        )
        self.assertEqual(
            json.dumps(SolutionConfigTypeEnum.BUREAU_SERVICE), '"bureau-service"'
        )
        self.assertEqual(
            json.dumps(SolutionConfigTypeEnum.BUREAU_CERTIFICATE),
            '"bureau-certificate"',
        )
        self.assertEqual(json.dumps(SolutionConfigTypeEnum.KEYWORD), '"keyword"')
        self.assertEqual(
            json.dumps(SolutionConfigTypeEnum.EXCLUSION_DEFAULT), '"exclusion-default"'
        )
        self.assertEqual(json.dumps(SolutionConfigTypeEnum.SEGMENT), '"segment"')
        self.assertEqual(
            json.dumps(SolutionConfigTypeEnum.BUREAU_DATA_SOURCE),
            '"bureau-data-source"',
        )
        self.assertEqual(
            json.dumps(SolutionConfigTypeEnum.BILLING_SERVICE), '"billing-service"'
        )
