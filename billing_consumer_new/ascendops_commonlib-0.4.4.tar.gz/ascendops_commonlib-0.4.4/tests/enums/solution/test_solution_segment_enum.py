""" Unit tests for SolutionSegmentTypeEnum """

import unittest
import json
from ascendops_commonlib.enums.solution.solution_segment_type_enum import (
    SolutionSegmentTypeEnum,
)


class TestSolutionSegmentTypeEnum(unittest.TestCase):
    """Unit tests for SolutionSegmentTypeEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(
            SolutionSegmentTypeEnum("score"), SolutionSegmentTypeEnum.SCORE
        )
        self.assertEqual(
            SolutionSegmentTypeEnum("attribute"), SolutionSegmentTypeEnum.ATTRIBUTE
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(SolutionSegmentTypeEnum.SCORE.value, "score")
        self.assertEqual(SolutionSegmentTypeEnum.ATTRIBUTE.value, "attribute")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(
            SolutionSegmentTypeEnum.SCORE, SolutionSegmentTypeEnum["SCORE"]
        )
        self.assertEqual(
            SolutionSegmentTypeEnum.ATTRIBUTE, SolutionSegmentTypeEnum["ATTRIBUTE"]
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(SolutionSegmentTypeEnum.SCORE), '"score"')
        self.assertEqual(json.dumps(SolutionSegmentTypeEnum.ATTRIBUTE), '"attribute"')
