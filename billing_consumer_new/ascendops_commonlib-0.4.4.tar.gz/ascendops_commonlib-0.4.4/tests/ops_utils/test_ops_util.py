"""
test module for app_util module
"""

import time
import unittest
from ascendops_commonlib.ops_utils import ops_util


class TestOpsUtil(unittest.TestCase):
    """Test case for the OpsUtil class"""

    def test_get_epoch_millis(self):
        """
        Test the get_epoch_millis method.

        This method tests the functionality of the get_epoch_millis method in the ops_util module.
        It checks if the returned value is an integer and falls within the expected range.

        Returns:
            None
        """
        before = round(time.time() * 1000)
        result = ops_util.get_epoch_millis()
        after = round(time.time() * 1000)
        assert isinstance(result, int)
        assert before <= result <= after

    def test_convert_epoch_millis_to_yyyymmddhhmmss(self):
        """Test the convert_epoch_millis_to_yyyymmddhhmmss method.

        This method tests the functionality of the convert_epoch_millis_to_yyyymmddhhmmss method
        by providing an epoch_millis value and comparing the result with the expected output.

        Args:
            None

        Returns:
            None

        Raises:
            AssertionError: If the result is not a string or if it does not match the expected result.
        """
        epoch_millis = 1602514800000
        expected_result = "2020-10-12 15:00:00"
        result = ops_util.convert_epoch_millis_to_yyyymmddhhmmss(epoch_millis)
        assert isinstance(result, str)
        assert result == expected_result

    def test_abs_datatype_value(self):
        """
        Test case for the abs_datatype_value method in the ops_util module.

        This method tests the behavior of the abs_datatype_value method for different data types.

        The method performs the following tests:
        - Test with INTEGER_TYPES: Tests the behavior of the method for integer data types.
        - Test with FLOAT_TYPES: Tests the behavior of the method for float data types.
        - Test with BOOLEAN_TYPES: Tests the behavior of the method for boolean data types.
        - Test with DATE_TYPES: Tests the behavior of the method for date data types.
        - Test with STRING_TYPES: Tests the behavior of the method for string data types.
        - Test with feature_datatype containing "decimal" or "varchar": Tests the behavior of the method for feature_datatypes that contain "decimal" or "varchar".
        - Test where raw_value is None: Tests the behavior of the method when the raw_value is None.
        - Test with a feature_datatype that is not in any of the defined types: Tests the behavior of the method for an undefined feature_datatype.

        The method uses assertions to check if the actual output of the abs_datatype_value method matches the expected output.

        Returns:
            None
        """
        # Test with INTEGER_TYPES
        for int_type in ["bigint", "int", "integer", "long", "number", "smallint"]:
            self.assertEqual(ops_util.abs_datatype_value(int_type, "123"), 123)
            self.assertEqual(ops_util.abs_datatype_value(int_type, "abc"), None)

        # Test with FLOAT_TYPES
        for float_type in ["double", "float", "numeric", "decimal"]:
            self.assertEqual(ops_util.abs_datatype_value(float_type, "123.45"), 123.45)
            self.assertEqual(ops_util.abs_datatype_value(float_type, "abc"), None)

        # Test with BOOLEAN_TYPES
        for bool_type in ["boolean"]:
            self.assertEqual(ops_util.abs_datatype_value(bool_type, "true"), True)
            self.assertEqual(ops_util.abs_datatype_value(bool_type, "false"), False)
            self.assertEqual(ops_util.abs_datatype_value(bool_type, "abc"), None)

        # Test with DATE_TYPES
        for date_type in ["date"]:
            self.assertEqual(ops_util.abs_datatype_value(date_type, "2022-01-01"), "2022-01-01")

        # Test with STRING_TYPES
        for string_type in ["alphanumeric", "string", "text"]:
            self.assertEqual(ops_util.abs_datatype_value(string_type, "abc"), "abc")

        # Test with feature_datatype containing "decimal" or "varchar"
        self.assertEqual(ops_util.abs_datatype_value("decimal(13,0)", "123.45"), 123.45)
        self.assertEqual(ops_util.abs_datatype_value("varchar(2)", "ab"), "ab")

        # Test where raw_value is None
        for datatype in ["bigint", "int", "integer", "long", "number", "smallint", "double", "float", "numeric", "decimal", "boolean", "date", "alphanumeric", "string", "text"]:
            self.assertEqual(ops_util.abs_datatype_value(datatype, None), None)

        # Test with a feature_datatype that is not in any of the defined types
        self.assertEqual(ops_util.abs_datatype_value("undefined_type", "abc"), None)
