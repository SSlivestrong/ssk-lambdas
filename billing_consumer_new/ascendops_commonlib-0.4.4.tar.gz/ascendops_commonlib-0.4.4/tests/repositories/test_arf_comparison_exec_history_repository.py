""" Unit tests for arf_comparison_exec_history_repository """
import unittest
from unittest.mock import MagicMock, patch, call
from ascendops_commonlib.repositories.opensearch import (
    arf_comparison_exec_history_repository,
)
from ascendops_commonlib.entities.opensearch.arf_comparison_exec_history import (
    ArfComparisonExecHistory,
)


class TestArfComparisonExecHistoryRepository(unittest.TestCase):
    """Unit tests for arf_comparison_exec_history_repository"""

    def test_opensearch_get_arf_comparison_exec_histories_all_kwargs(self):
        """tests get all documents with all kwargs given"""
        # ARRANGE
        uid = "uid_1"
        solution_date = "solution_date_!"
        solution_id = "solution_id_1"
        status = "status_!"
        include_fields = ["exec_id", "solution_id"]
        exclude_fields = ["status"]

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [ArfComparisonExecHistory()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            ArfComparisonExecHistory, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = arf_comparison_exec_history_repository.opensearch_get_arf_comparison_exec_histories(
                uid=uid,
                solution_date=solution_date,
                solution_id=solution_id,
                status=status,
                include_fields=include_fields,
                exclude_fields=exclude_fields,
            )
            # ASSERT
            # check include/ exclude are passed to search object

            mock_create_search_object.assert_called_once_with(
                include_fields=include_fields, exclude_fields=exclude_fields
            )

            # make sure all expected queries are added
            expected_query_calls = [
                call("term", uid=uid),
                call("term", solution_date=solution_date),
                call("term", solution_id=solution_id),
                call("term", status=status),
            ]
            mock_search.query.assert_has_calls(expected_query_calls, any_order=True)

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_get_arf_comparison_exec_histories_match_all(self):
        """tests get all documents when no term kwargs given"""
        # ARRANGE
        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [ArfComparisonExecHistory()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            ArfComparisonExecHistory, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = (
                arf_comparison_exec_history_repository.opensearch_get_arf_comparison_exec_histories()
            )
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=None, exclude_fields=None
            )

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with("match_all")

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_get_arf_comparison_exec_history(self):
        """tests get document"""
        # ARRANGE
        expected_doc = ArfComparisonExecHistory()
        uid = "uid_1"
        with patch.object(
            ArfComparisonExecHistory, "get", return_value=expected_doc
        ) as mock_get:
            # ACT
            actual_doc = arf_comparison_exec_history_repository.opensearch_get_arf_comparison_exec_history(
                "uid_1"
            )
            # ASSERT
            mock_get.assert_called_once_with(uid)
            self.assertEqual(expected_doc, actual_doc)

    def test_opensearch_update_arf_comparison_exec_history(self):
        """test update document"""
        # ARRANGE
        expected_hist = ArfComparisonExecHistory()
        updated_by = "John Doe"

        with patch.object(
            ArfComparisonExecHistory, "update_document"
        ) as mock_update_document:
            # ACT
            actual_contract = arf_comparison_exec_history_repository.opensearch_update_arf_comparison_exec_history(
                expected_hist, updated_by
            )

            # ASSERT
            mock_update_document.assert_called_once_with(refresh="wait_for")

            self.assertEqual(actual_contract.updated_by, updated_by)
