"""
This module provides a utility class to create sts client using boto3 session and create a client for a given service.
"""

import boto3
from botocore.exceptions import NoCredentialsError


class STSClientUtil:
    """
    class for sts client
    """
    def __init__(self, region_name="us-east-1", profile_name=None):
        """
        initialize region and profile name if any.
        """
        self.region_name = region_name
        self.profile_name = profile_name

    def get_client(self, service_name, role_arn=None):
        """
        get a boto3 client for a specific AWS service

        Params:
         - service_name: name of the AWS service like 's3', 'secretsmanager'
         - role_arn: ARN of the role to assume (optional)
        
        Returns:
         - boto3 client for the specified AWS service
        """

        session = boto3.Session(profile_name=self.profile_name, region_name=self.region_name)

        if role_arn:
            try:
                sts_client = session.client("sts", region_name=self.region_name)
                assumed_role_object = sts_client.assume_role(
                    RoleArn=role_arn,
                    RoleSessionName="AssumeRoleSession1"
                )
                credentials = assumed_role_object["Credentials"]

                client = session.client(
                    service_name=service_name,
                    region_name=self.region_name,
                    aws_access_key_id=credentials['AccessKeyId'],
                    aws_secret_access_key=credentials['SecretAccessKey'],
                    aws_session_token=credentials['SessionToken'],
                )
            except NoCredentialsError as xcp:
                raise xcp
        else:
            client = session.client(service_name=service_name, region_name=self.region_name)
        
        return client
