""" mysql utility """

import logging
import aiomysql
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.aws_utils.secrets_manager_util import SecretsManagerUtil


class aio_mysql():
    """ custom class for mysql db (aws rds) """

    def __init__(self) -> None:
        pass

    
    async def create_connections(self, size=4):
        """ estable mysql rds db conenction """
        self.logger = logging.getLogger("mysql_logger")
        try:
            secrets_util = SecretsManagerUtil()
            rds_secrets = secrets_util.get_secret(ops_config.RDS_SECRET_NAME)
            self.connection_pool = await aiomysql.create_pool(
                host=ops_config.RDS_HOST,
                user=rds_secrets["username"],
                password=rds_secrets["password"],
                db=ops_config.RDS_DB_SCHEMA,
                port=rds_secrets["port"],
                maxsize=size,
                pool_recycle=10800
            )
            self.logger.warning("========== Successfully connected to MySQL Database: %s ==========", ops_config.RDS_DB_SCHEMA)
        except Exception as xcp:
            self.logger.error("========== Error connecting to MySQL Database: %s ==========", str(xcp))
    
    
    async def close_connections(self):
        """
        Closes all active connections in the RDS/MySQL connection pool.

        This method ensures that all connections in the connection pool are properly closed.
        It first initiates the closing of the connection pool and then waits for all connections
        to be fully closed asynchronously.

        Raises:
            Any exceptions raised by the underlying connection pool's close or wait_closed methods.
        """
        self.connection_pool.close()
        await self.connection_pool.wait_closed()
    
    
    async def execute_query(self, query, table):
        """
        Executes the given SQL query asynchronously.

        Args:
            query (str): The SQL query to be executed.
            get_columns (bool, optional): If True, returns the column names along with the query result. Defaults to False.
            table (str, optional): The name of the table on which the query is executed. If not provided, it will be inferred from the query. Defaults to "".

        Returns:
            Union[List[Tuple], Tuple[List[Tuple], List[str]]]: If get_columns is False, returns the query result as a list of tuples.
            If get_columns is True, returns a tuple containing the query result and a list of column names.

        Raises:
            Exception: If there is an error executing the query, it logs the error and returns None.
        """
        response = None
        columns = []
        async with self.connection_pool.acquire() as connection:
            async with connection.cursor() as cursor:
                await cursor.execute(query)
                response = await cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                self.logger.warning("Executed query on table: %s", table)
                return response, columns
    
    
    async def bulk_insert_data(self, table: str, columns: tuple, data: list) -> None:
        """Inserts data into a MySQL table.
        Args:
            table (str): The name of the MySQL table to insert data into.
            columns (tuple): A tuple of column names to insert data into.
            data (list): A list of tuples containing the data to insert.
        Returns:
            None.
            
        Example:
            table = "mytable"
            columns = ("column1", "column2", "column3")
            data = [
                ("Value 1 for column 1", "Value 1 for column 2", "Value 1 for column 3"),
                ("Value 2 for column 1", "Value 2 for column 2", "Value 2 for column 3"),
                ("Value 3 for column 1", "Value 3 for column 2", "Value 3 for column 3")
            ]"""
        try:
            query = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({', '.join(['%s' for _ in range(len(columns))])})"
            async with self.connection_pool.acquire() as connection:
                async with connection.cursor() as cursor:
                    try:
                        await cursor.executemany(query, data)
                        self.logger.warning("Inserted records to table: %s", table)
                        await connection.commit()
                        self.logger.warning("commited records to table: %s", table)
                    except Exception as exp:
                        self.logger.error("Error inserting data to table: %s | Error:%s", table, str(exp))
            self.connection_pool.close()
            await self.connection_pool.wait_closed()
        except Exception as xcp:
            self.logger.error("Error in (method: bulk_insert_data):  MySQL DB %s |  Error:%s", ops_config.RDS_DB_SCHEMA, str(xcp))
