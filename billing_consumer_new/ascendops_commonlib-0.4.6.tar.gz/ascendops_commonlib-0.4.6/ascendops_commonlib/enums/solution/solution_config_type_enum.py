""" Enum that defines the type of configuration stored in the app configuration datastore """

from enum import Enum, unique


# Inherits from str as well so that enum is json serializable
@unique
class SolutionConfigTypeEnum(str, Enum):
    """defines the type of configuration stored in the app configuration datastore"""

    # configurations used for creating solution document
    BUREAU_CONFIGURATION = "bureau-configuration"
    BUREAU_SERVICE = "bureau-service"
    BUREAU_CERTIFICATE = "bureau-certificate"
    KEYWORD = "keyword"
    EXCLUSION_DEFAULT = "exclusion-default"
    SEGMENT = "segment"
    BUREAU_DATA_SOURCE = "bureau-data-source"
    BILLING_SERVICE = "billing-service"
