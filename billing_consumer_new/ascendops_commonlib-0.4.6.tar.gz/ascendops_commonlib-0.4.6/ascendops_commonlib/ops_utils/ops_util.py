""" Utility functions """

import time
import string
import secrets
from typing import Generator, Optional
from datetime import datetime, timezone
from time import gmtime, strftime


INTEGER_TYPES = ["bigint", "int", "integer", "long", "number", "smallint"]
FLOAT_TYPES = ["double", "float", "numeric", "decimal"]
BOOLEAN_TYPES = ["boolean"]
BOOLEAN_YES_TYPES = ["true", "yes", "1"]
BOOLEAN_NO_TYPES = ["false", "no", "0"]
DATE_TYPES = ["date"]
STRING_TYPES = ["alphanumeric", "string", "text"]


def get_epoch_millis() -> int:
    """
    Returns epoch time in milliseconds in UTC.

    Returns:
        An integer representing the current epoch time in milliseconds in UTC.

    Usage:
        >>> get_epoch_millis()
        1602514800000
    """
    return round(time.time() * 1000)


def get_epoch_millis_string() -> str:
    """
    Returns epoch time in milliseconds in UTC

    Returns:
        A string representing the current epoch time in milliseconds in UTC.

    Usage:
        >>> get_epoch_millis_string()
        "1602514800000"
    """
    return str(round(time.time() * 1000))


def get_epoch_seconds() -> int:
    """
    Returns epoch time in seconds

    Returns:
        An integer representing the current epoch time in seconds.

    Usage:
        >>> get_epoch_seconds()
        1602514800
    """
    return round(time.time())


def get_epoch_seconds_string() -> str:
    """
    Returns epoch time in seconds

    Returns:
        A string representing the current epoch time in seconds.

    Usage:
        >>> get_epoch_seconds_string()
        "1602514800"
    """
    return str(round(time.time()))


def convert_iso_to_epoch_millis(iso_date) -> int:
    """
    Converts iso_date to epoch time in milliseconds in UTC

    Args:
        iso_date: An ISO 8601 formatted date string.

    Returns:
        An integer representing the epoch time in milliseconds in UTC.

    Usage:
        >>> convert_iso_to_epoch_millis("2020-10-12T15:00:00.000Z")
        1602514800000
    """
    return round(datetime.fromisoformat(iso_date).timestamp() * 1000)


def convert_epoch_millis_to_utc_datetime(epoch_millis) -> datetime:
    """
    Converts epoch millis to datetime

    Args:
        epoch_millis: An integer representing the epoch time in milliseconds in UTC.

    Returns:
        A datetime object representing the epoch time in milliseconds in UTC.

    Usage:
        >>> convert_epoch_millis_to_utc_datetime(1602514800000)
        datetime.datetime(2020, 10, 12, 15, 0)
    """
    return datetime.fromtimestamp(epoch_millis / 1000, timezone.utc)


def convert_datetime_to_epoch_millis(datetime_obj) -> int:
    """
    Converts datetime obj to epoch millis

    Args:
        datetime_obj: A datetime object. Default timezone is assumed to be runtime timezone unless otherwise explicitly specified.
        Example:
            UTC: datetime(2020, 10, 12, 15, 0)
            PST: datetime(2020, 10, 12, 8, 0, tzinfo=ZoneInfo("America/Los_Angeles"))

    Returns:
        An integer representing the epoch time in milliseconds in UTC.

    Usage:
        >>> convert_datetime_to_epoch_millis(datetime(2020, 10, 12, 8, 0))
        1602514800000
    """
    return round(datetime_obj.timestamp() * 1000)


def convert_epoch_millis_to_yyyymmddhhmmss(epoch_millis) -> str:
    """
    Converts epoch millis to yyyymmddhhmmss string

    Args:
        epoch_millis: An integer representing the epoch time in milliseconds in UTC.

    Returns:
        A string representing the epoch time in yyyymmddhhmmss format.

    Usage:
        >>> convert_epoch_millis_to_yyyymmddhhmmss(1602514800000)
        "2020-10-12 15:00:00"
    """
    return datetime.fromtimestamp(epoch_millis / 1000, timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def check_if_max_time_passed(epoch_millis, max_seconds_passed) -> bool:
    """
    Returns true if more time than max_seconds_passed has elapsed since epoch millis, false otherwise

    Args:
        epoch_millis: An integer representing the epoch time in milliseconds in UTC.
        max_seconds_passed: An integer representing the max seconds that can have elapsed since epoch_millis.

    Returns:
        A boolean indicating if more time than max_seconds_passed has elapsed since epoch millis.

    Usage:
        >>> check_if_max_time_passed(1602514800000, 3600)
        True
    """
    # get current datetime from current to epoch to make sure timezone is consistent
    current_datetime = convert_epoch_millis_to_utc_datetime(get_epoch_millis())
    epoch_datetime = convert_epoch_millis_to_utc_datetime(epoch_millis)
    return (current_datetime - epoch_datetime).total_seconds() > max_seconds_passed


def generate_go_txn_id() -> str:
    """
    Generate a 23-char unique string for each request hitting Ascend-Go
    credit report endpoint. This must be used to store in AuditLog
    and Billing system.

    July 2022 - Use this string as M-text to support TCP requests, MUST upper it.
    Why? DCR echos back all upper case!!! See how wonderful it is?

    RMDLC-4020: go_txn_id: mmddYYYYHHMMSS********P
    * are replaced with random alphabet. Ending with P indicates primary.
    In Joint for secondary, we use S for billing.

    Returns:
        A string representing the unique go_txn_id.

    Usage:
        >>> generate_go_txn_id()
        "10122020080000ABCD1234P"
    """
    suffix = "".join(secrets.choice(string.ascii_letters) for _ in range(8))
    return datetime.now(timezone.utc).strftime("%m%d%Y%H%M%S") + suffix.upper() + "P"


def get_strfgmtime_shortyear() -> str:
    """
    Returns GM time as String in YYMMDDHHMMSS format

    Returns:
        A string representing the current time in YYMMDDHHMMSS format.

    Usage:
        >>> get_strfgmtime_shortyear()
        "20101215000000"
    """
    return strftime("%y%m%d%H%M%S", gmtime())


def get_strfgmtime_fullyear() -> str:
    """
    Returns GM time as String in YYYYMMDDHHMMSS format

    Returns:
        A string representing the current time in YYYYMMDDHHMMSS format.

    Usage:
        >>> get_strfgmtime_fullyear()
        "20201012150000"
    """
    return strftime("%Y%m%d%H%M%S", gmtime())


def divide_chunks(full_list, chunk_size) -> Generator[list, None, None]:
    """
    Returns a two dimensional list for a list with each chunk of max size 'n'

    Returns:
        A two dimensional list with each chunk of max size 'n'.

    Usage:
        >>> divide_chunks([1,2,3,4,5,6,7,8,9,10], 3)
        [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10]]
    """
    for each in range(0, len(full_list), chunk_size):
        yield full_list[each : each + chunk_size]


def get_yyyy_mm_dd() -> str:
    """
    Returns current date in yyyy-mm-dd format

    Returns:
        A string representing the current date in yyyy-mm-dd format.

    Usage:
        >>> get_yyyy_mm_dd()
        "2020-10-12"
    """
    return datetime.now().strftime("%Y-%m-%d")


def get_yy_mm_dd():
    """
    Returns current date in yy-mm-dd format

    Returns:
        A string representing the current date in yy-mm-dd format.

    Usage:
        >>> get_yy_mm_dd()
        "20-10-12"
    """
    return datetime.now().strftime("%y-%m-%d")


def get_yyyymmdd():
    """
    Returns current date in yyyymmdd format

    Returns:
        A string representing the current date in yyyymmdd format.

    Usage:
        >>> get_yyyymmdd()
        "20201012"
    """
    return datetime.now().strftime("%Y%m%d")


def get_yymmdd():
    """
    Returns current date in yymmdd format

    Returns:
        A string representing the current date in yymmdd format.

    Usage:
        >>> get_yymmdd()
        "201012"
    """
    return datetime.now().strftime("%y%m%d")


def get_hhmmsssss_in_utc():
    """
    Returns the current time in HHMMSSsss format (from UTC).

    Returns:
        A string representing the current time in HHMMSSsss format.

    Usage:
        >>> get_hhmmsssss_in_utc()
        "080000000"
    """
    return datetime.now(timezone.utc).strftime("%H%M%S%f")[:-3]


def abs_datatype_value(feature_datatype: str, raw_value: Optional[str] = None):
    """
    Get absolute value based on the feature datatype.

    This function handles all the following data types found in the features index:
    "","alphanumeric","bigint","boolean","date","decimal","decimal(13,0)","double","float","int","integer","long",
    "None","number","numeric","smallint","string","text","varchar","varchar(2)"

    Args:
        feature_datatype (str): The datatype of the feature.
        raw_value (Optional[str], optional): The raw value. Defaults to None.

    Returns:
        The absolute value based on the feature datatype. Returns None if the raw value is None or if the conversion fails.
    """

    if raw_value is None:
        return None
    try:
        if feature_datatype in INTEGER_TYPES:
            return int(raw_value)
        if feature_datatype in FLOAT_TYPES or "decimal" in feature_datatype:
            return float(raw_value)
        if feature_datatype in BOOLEAN_TYPES and raw_value.lower() in BOOLEAN_YES_TYPES:
            return True
        if feature_datatype in BOOLEAN_TYPES and raw_value.lower() in BOOLEAN_NO_TYPES:
            return False
        if feature_datatype in DATE_TYPES:
            return str(raw_value)
        if feature_datatype in STRING_TYPES or "varchar" in feature_datatype:
            return str(raw_value)
    except ValueError:
        return None

    return None
