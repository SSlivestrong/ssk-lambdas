"""
    Performs operations related to client contracts 
"""
from ascendops_commonlib.entities.opensearch.client_contract import ClientContract


def opensearch_get_client_contract(client_uid):
    """To retrieve a client document with uid
    Params:
       client_uid: uniquely identifies a client
    Return:
      Client contract object
    """
    return ClientContract.get(client_uid)


def opensearch_get_client_contracts(**kwargs) -> "list[ClientContract]":
    """To retrieve client contract documents with client_uid and client name (if client name is not null)
    Params:
        client_uid - Optional[str]: uniquely identifies a client
        name - Optional[str]: uniquely identifies a contract for the client
        client_name - Optional[str]: client name
        include_fields - Optional[list[str]]: document fields to include in returned document
        exclude_fields - Optional[list[str]]: document fields to exclude in returned document
    Return:
        list of client contract object
    """
    client_uid = kwargs.get("client_uid")
    name = kwargs.get("name")
    client_name = kwargs.get("client_name")
    include_fields = kwargs.get("include_fields")
    exclude_fields = kwargs.get("exclude_fields")

    search = ClientContract.create_search_object(
        include_fields=include_fields, exclude_fields=exclude_fields
    )

    term_queries_added = False

    if client_uid is not None:
        search = search.query("term", client_uid=client_uid)
        term_queries_added = True
    if name is not None:
        search = search.query("term", name=name)
        term_queries_added = True
    if client_name is not None:
        search = search.query("term", client_name=client_name)
        term_queries_added = True

    # if no term queries added, search all documents
    if not term_queries_added:
        search = search.query("match_all")
    return search.execute().hits


def opensearch_create_client_contract(
    client_contract: ClientContract, created_by: str, refresh="false"
) -> ClientContract:
    """To create a client contract document
    Params:
        client_json: defines properties of client object
        created_by: user who created the contract
        refresh: specifies opensearch refresh behavior

    Return:
        Client Contract object
    """
    client_contract.created_by = created_by
    client_contract.insert_document(refresh=refresh)
    return client_contract


def opensearch_update_client_contract(
    client_contract: ClientContract, updated_by: str, refresh="wait_for"
) -> ClientContract:
    """To update a client document
    Params:
        client_json: defines properties of client object
        refresh: specifies opensearch refresh behavior
    Return:
        Client object
    """
    client_contract.updated_by = updated_by
    client_contract.update_document(refresh=refresh)
    return client_contract
