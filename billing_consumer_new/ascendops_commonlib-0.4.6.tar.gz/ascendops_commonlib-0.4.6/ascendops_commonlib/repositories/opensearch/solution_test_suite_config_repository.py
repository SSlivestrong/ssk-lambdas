""" data layer to interact with test suite config objects """

from ascendops_commonlib.entities.opensearch.solution_test_suite_config import (
    SolutionTestSuiteConfig,
)


def opensearch_get_solution_test_suite_configs(
    **kwargs,
) -> list[SolutionTestSuiteConfig]:
    """Gets all test suite configs
    Parameters:
        include_fields - Optional[list[str]]: document fields to include in returned document
        exclude_fields - Optional[list[str]]: document fields to exclude in returned document
    Returns:
        list of test suite configs
    """
    include_fields = kwargs.get("include_fields")
    exclude_fields = kwargs.get("exclude_fields")

    search = SolutionTestSuiteConfig.create_search_object(
        include_fields=include_fields, exclude_fields=exclude_fields
    )

    search = search.query("match_all")

    return search.execute().hits
