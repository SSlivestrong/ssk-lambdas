""" setup module """

from setuptools import setup, find_packages

setup(
    name="ascendops_commonlib",
    version="0.4.6",
    packages=find_packages(),
    install_requires=[
        "boto3",
        "elasticsearch==7.12.0",
        "requests-aws4auth",
        "aws-encryption-sdk",
        "redis",
        "lz4",
        "kafka-python",
        "orjson",
        "opensearch-dsl",
        "pydantic",
    ],
    extras_require={
        "dev": ["pytest", "pytest-cov", "freezegun"],
        "test": ["pytest", "pytest-cov", "freezegun"],
    },
    classifiers=["Programming Language :: Python :: 3.11"],
)
