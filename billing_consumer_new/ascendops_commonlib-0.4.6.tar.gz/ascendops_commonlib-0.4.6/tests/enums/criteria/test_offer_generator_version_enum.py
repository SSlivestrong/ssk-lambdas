""" Unit tests for OfferGeneratorVersionEnum """

import unittest
import json
from ascendops_commonlib.enums.criteria.offer_generator_version_enum import (
    OfferGeneratorVersionEnum,
)


class TestOfferGeneratorVersionEnum(unittest.TestCase):
    """Unit tests for OfferGeneratorVersionEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(
            OfferGeneratorVersionEnum("v1.0"), OfferGeneratorVersionEnum.PYOG_VERSION
        )
        self.assertEqual(
            OfferGeneratorVersionEnum("v2.0"), OfferGeneratorVersionEnum.SSOG_VERSION
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(OfferGeneratorVersionEnum.PYOG_VERSION.value, "v1.0")
        self.assertEqual(OfferGeneratorVersionEnum.SSOG_VERSION.value, "v2.0")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(
            OfferGeneratorVersionEnum.PYOG_VERSION,
            OfferGeneratorVersionEnum["PYOG_VERSION"],
        )
        self.assertEqual(
            OfferGeneratorVersionEnum.SSOG_VERSION,
            OfferGeneratorVersionEnum["SSOG_VERSION"],
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(OfferGeneratorVersionEnum.PYOG_VERSION), '"v1.0"')
        self.assertEqual(json.dumps(OfferGeneratorVersionEnum.SSOG_VERSION), '"v2.0"')
