""" Unit tests for DatasourceTypeEnum """

import unittest
import json
from ascendops_commonlib.enums.datasource.datasource_type_enum import DatasourceTypeEnum


class TestDatasourceTypeEnum(unittest.TestCase):
    """Unit tests for DatasourceTypeEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(DatasourceTypeEnum("experian"), DatasourceTypeEnum.EXPERIAN)
        self.assertEqual(DatasourceTypeEnum("clarity"), DatasourceTypeEnum.CLARITY)
        self.assertEqual(DatasourceTypeEnum("equifax"), DatasourceTypeEnum.EQUIFAX)
        self.assertEqual(
            DatasourceTypeEnum("transunion"), DatasourceTypeEnum.TRANSUNION
        )
        self.assertEqual(DatasourceTypeEnum("fraud"), DatasourceTypeEnum.FRAUD)
        self.assertEqual(
            DatasourceTypeEnum("third_party"), DatasourceTypeEnum.THIRD_PARTY
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(DatasourceTypeEnum.EXPERIAN.value, "experian")
        self.assertEqual(DatasourceTypeEnum.CLARITY.value, "clarity")
        self.assertEqual(DatasourceTypeEnum.EQUIFAX.value, "equifax")
        self.assertEqual(DatasourceTypeEnum.TRANSUNION.value, "transunion")
        self.assertEqual(DatasourceTypeEnum.FRAUD.value, "fraud")
        self.assertEqual(DatasourceTypeEnum.THIRD_PARTY.value, "third_party")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(DatasourceTypeEnum.EXPERIAN, DatasourceTypeEnum["EXPERIAN"])
        self.assertEqual(DatasourceTypeEnum.CLARITY, DatasourceTypeEnum["CLARITY"])
        self.assertEqual(DatasourceTypeEnum.EQUIFAX, DatasourceTypeEnum["EQUIFAX"])
        self.assertEqual(
            DatasourceTypeEnum.TRANSUNION, DatasourceTypeEnum["TRANSUNION"]
        )
        self.assertEqual(DatasourceTypeEnum.FRAUD, DatasourceTypeEnum["FRAUD"])
        self.assertEqual(
            DatasourceTypeEnum.THIRD_PARTY, DatasourceTypeEnum["THIRD_PARTY"]
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(DatasourceTypeEnum.EXPERIAN), '"experian"')
        self.assertEqual(json.dumps(DatasourceTypeEnum.CLARITY), '"clarity"')
        self.assertEqual(json.dumps(DatasourceTypeEnum.EQUIFAX), '"equifax"')
        self.assertEqual(json.dumps(DatasourceTypeEnum.TRANSUNION), '"transunion"')
        self.assertEqual(json.dumps(DatasourceTypeEnum.FRAUD), '"fraud"')
        self.assertEqual(json.dumps(DatasourceTypeEnum.THIRD_PARTY), '"third_party"')
