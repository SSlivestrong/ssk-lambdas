""" Unit tests for SolutionTestStatusEnum """

import unittest
import json
from ascendops_commonlib.enums.solution.solution_test_status_enum import (
    SolutionTestStatusEnum,
)


class TestSolutionTestStatusEnum(unittest.TestCase):
    """Unit tests for SolutionTestStatusEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(
            SolutionTestStatusEnum("created"), SolutionTestStatusEnum.CREATED
        )
        self.assertEqual(
            SolutionTestStatusEnum("passed"), SolutionTestStatusEnum.PASSED
        )
        self.assertEqual(
            SolutionTestStatusEnum("failed"), SolutionTestStatusEnum.FAILED
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(SolutionTestStatusEnum.CREATED.value, "created")
        self.assertEqual(SolutionTestStatusEnum.PASSED.value, "passed")
        self.assertEqual(SolutionTestStatusEnum.FAILED.value, "failed")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(
            SolutionTestStatusEnum.CREATED, SolutionTestStatusEnum["CREATED"]
        )
        self.assertEqual(
            SolutionTestStatusEnum.PASSED, SolutionTestStatusEnum["PASSED"]
        )
        self.assertEqual(
            SolutionTestStatusEnum.FAILED, SolutionTestStatusEnum["FAILED"]
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(SolutionTestStatusEnum.CREATED), '"created"')
        self.assertEqual(json.dumps(SolutionTestStatusEnum.PASSED), '"passed"')
        self.assertEqual(json.dumps(SolutionTestStatusEnum.FAILED), '"failed"')
