""" Unit tests for client_contract_repository """
import unittest
from unittest.mock import MagicMock, patch, call

from ascendops_commonlib.repositories.opensearch import client_contract_repository
from ascendops_commonlib.entities.opensearch.client_contract import ClientContract


class TestClientContractRepository(unittest.TestCase):
    """Unit tests for client_contract_repository"""

    def test_opensearch_get_client_contracts_all_kwargs(self):
        """tests get all documents with all kwargs given"""
        # ARRANGE
        client_uid = "client_uid_1"
        name = "name_1"
        client_name = "client_name_1"
        include_fields = ["name", "client_name"]
        exclude_fields = ["client_uid"]

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [ClientContract()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            ClientContract, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = client_contract_repository.opensearch_get_client_contracts(
                client_uid=client_uid,
                name=name,
                client_name=client_name,
                include_fields=include_fields,
                exclude_fields=exclude_fields,
            )
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=include_fields, exclude_fields=exclude_fields
            )

            # make sure all expected queries are added
            expected_query_calls = [
                call("term", client_uid=client_uid),
                call("term", name=name),
                call("term", client_name=client_name),
            ]
            mock_search.query.assert_has_calls(expected_query_calls, any_order=True)

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_get_client_contracts_match_all(self):
        """tests get all documents when no term kwargs given"""
        # ARRANGE
        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [ClientContract()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            ClientContract, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = client_contract_repository.opensearch_get_client_contracts()
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=None, exclude_fields=None
            )

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with("match_all")

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_get_client_contract(self):
        """tests get document"""
        # ARRANGE
        expected_contract = ClientContract()
        uid = "uid_1"
        with patch.object(
            ClientContract, "get", return_value=expected_contract
        ) as mock_get:
            # ACT
            actual_contract = client_contract_repository.opensearch_get_client_contract(
                "uid_1"
            )
            # ASSERT
            mock_get.assert_called_once_with(uid)
            self.assertEqual(expected_contract, actual_contract)

    def test_opensearch_create_client_contract(self):
        """test create document"""

        # ARRANGE
        expected = ClientContract()
        created_by = "John Doe"

        with patch.object(ClientContract, "insert_document") as mock_insert_document:
            # ACT
            actual = client_contract_repository.opensearch_create_client_contract(
                expected, created_by
            )

            # ASSERT
            mock_insert_document.assert_called_once_with(refresh="false")

            self.assertEqual(actual.created_by, created_by)

    def test_opensearch_update_client_contract(self):
        """test update document"""

        # ARRANGE
        expected_contract = ClientContract()
        updated_by = "John Doe"

        with patch.object(ClientContract, "update_document") as mock_update_document:
            # ACT
            actual_contract = (
                client_contract_repository.opensearch_update_client_contract(
                    expected_contract, updated_by
                )
            )

            # ASSERT
            mock_update_document.assert_called_once_with(refresh="wait_for")

            self.assertEqual(actual_contract.updated_by, updated_by)
