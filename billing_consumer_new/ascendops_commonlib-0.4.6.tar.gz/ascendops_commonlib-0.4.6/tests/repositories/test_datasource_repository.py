""" Unit tests for test_datasource_repository """
import unittest
from unittest.mock import MagicMock, patch, call

from ascendops_commonlib.repositories.opensearch import (
    datasource_repository,
)
from ascendops_commonlib.entities.opensearch.datasource import Datasource


class TestDatasourceRepository(unittest.TestCase):
    """Unit tests for test_datasource_repository"""

    def test_opensearch_get_datasources_match_all(self):
        """tests get all documents with all kwargs given"""
        # ARRANGE
        include_fields = ["uid", "created_by"]
        exclude_fields = ["updated_by"]

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [Datasource()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            Datasource, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = datasource_repository.opensearch_get_datasources(
                include_fields=include_fields,
                exclude_fields=exclude_fields,
            )
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=include_fields, exclude_fields=exclude_fields
            )

            # make sure all expected queries are added
            expected_query_calls = [
                call("match_all"),
            ]
            mock_search.query.assert_has_calls(expected_query_calls, any_order=True)

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by ex
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_create_datasource(self):
        """test create document"""

        # ARRANGE
        datasource = Datasource()
        created_by = "John Doe"

        with patch.object(Datasource, "insert_document") as mock_insert_document:
            # ACT
            returned_datasource = datasource_repository.opensearch_create_datasource(
                datasource, created_by
            )

            # ASSERT
            mock_insert_document.assert_called_once_with(refresh="false")

            self.assertEqual(returned_datasource.created_by, created_by)

    def test_opensearch_update_datasource(self):
        """test update document"""

        # ARRANGE
        datasource = Datasource()
        updated_by = "John Doe"

        with patch.object(Datasource, "update_document") as mock_update_document:
            # ACT
            returned_datasource = datasource_repository.opensearch_update_datasource(
                datasource, updated_by
            )

            # ASSERT
            mock_update_document.assert_called_once_with(refresh="wait_for")

            self.assertEqual(returned_datasource.updated_by, updated_by)

    def test_opensearch_get_datasource(self):
        """tests get document"""
        # ARRANGE
        expected_datasource = Datasource()
        uid = "uid_1"
        with patch.object(
            Datasource, "get", return_value=expected_datasource
        ) as mock_get:
            # ACT
            actual_solution = datasource_repository.opensearch_get_datasource("uid_1")
            # ASSERT
            mock_get.assert_called_once_with(uid)
            self.assertEqual(expected_datasource, actual_solution)
