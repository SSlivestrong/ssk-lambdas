""" Unit tests for solution_repository """
import unittest
from unittest.mock import MagicMock, patch, call

from ascendops_commonlib.repositories.opensearch import solution_repository
from ascendops_commonlib.entities.opensearch.solution import Solution
from ascendops_commonlib.enums.solution.solution_status_enum import SolutionStatusEnum


class TestSolutionRepository(unittest.TestCase):
    """Unit tests for solution_repository"""

    def test_opensearch_get_solutions_all_kwargs(self):
        """tests get all documents with all kwargs given"""
        # ARRANGE
        solution_id = "solution_id_1"
        status = SolutionStatusEnum.DRAFT
        is_available_for_integration_testing = False
        include_fields = ["uid", "created_by"]
        exclude_fields = ["updated_by"]
        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [Solution()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            Solution, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = solution_repository.opensearch_get_solutions(
                solution_id=solution_id,
                status=status,
                is_available_for_integration_testing=is_available_for_integration_testing,
                include_fields=include_fields,
                exclude_fields=exclude_fields,
            )
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=include_fields, exclude_fields=exclude_fields
            )

            # make sure all expected queries are added
            expected_query_calls = [
                call("term", solution_id=solution_id),
                call("term", status=status),
                call(
                    "term",
                    is_available_for_integration_testing=is_available_for_integration_testing,
                ),
            ]
            mock_search.query.assert_has_calls(expected_query_calls, any_order=True)

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_get_solutions_match_all(self):
        """tests get all documents when no term kwargs given"""
        # ARRANGE
        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [Solution()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            Solution, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = solution_repository.opensearch_get_solutions()
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=None, exclude_fields=None
            )

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with("match_all")

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_get_solution(self):
        """tests get document"""
        # ARRANGE
        expected_solution = Solution()
        uid = "uid_1"
        with patch.object(Solution, "get", return_value=expected_solution) as mock_get:
            # ACT
            actual_solution = solution_repository.opensearch_get_solution("uid_1")
            # ASSERT
            mock_get.assert_called_once_with(uid)
            self.assertEqual(expected_solution, actual_solution)

    def test_opensearch_create_solution(self):
        """test create document"""

        # ARRANGE
        expected_solution = Solution()
        created_by = "John Doe"

        with patch.object(Solution, "insert_document") as mock_insert_document:
            # ACT
            actual_solution = solution_repository.opensearch_create_solution(
                expected_solution, created_by
            )

            # ASSERT
            mock_insert_document.assert_called_once_with(refresh="false")

            self.assertEqual(actual_solution.created_by, created_by)

    def test_opensearch_update_solution(self):
        """test update document"""
        # ARRANGE
        expected = Solution()
        update_json = {"send_parsed_keyword_to_dcr": False}

        with patch.object(Solution, "update_document") as mock_update_document:
            # ACT
            actual = solution_repository.opensearch_update_solution(
                expected, update_json
            )

            # ASSERT
            mock_update_document.assert_called_once_with(refresh="wait_for")

            self.assertEqual(
                actual.send_parsed_keyword_to_dcr,
                update_json["send_parsed_keyword_to_dcr"],
            )
