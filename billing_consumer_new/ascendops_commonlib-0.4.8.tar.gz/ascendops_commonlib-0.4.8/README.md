# North American Ascend Ops Common

This is a utility library for North American Ascend Ops commonly used modules, classes, functions and config variables. It includes interfaces for datastores like ElasticSearch (OpenSearch prefork v7.10), DynamoDB, Redis (AWS emory DB), AWS S3, etc; for event stores like AWS MSK, AWS Eventbridge, etc. It also include common utility modules like application logger, config variables, etc.,

This utility library is available as a package in the Experian JFrog Artifactory: https://artifacts.experian.local/ui/packages/pypi:%2F%2Fascendops_commonlib

---

## Table of Contents

---

-   [Ascend Ops Common](#ascend-ops-common)
    -   [Table of Contents](#table-of-contents)
    -   [Installation](#installation)
    -   [Usage](#usage)
        -   [App Utils](#app-utils)
            -   [App Util](#app-util)
            -   [App Config](#app-config)
        -   [Datastores](#datastores)
            -   [ElasticSearch (AWS Opensearch prefork v7.10)](#elasticsearch-aws-opensearch-prefork-v710)
        -   [Eventstores](#eventstores)
            -   [Kafka (AWS MSK)](#kafka-aws-msk)
            -   [AWS Eventbridge](#aws-eventbridge)
    -   [Contributing](#contributing)
        -   [Testing](#testing)
    -   [License](#license)

---

## Installation

---

To install the library, you should use pip to download from the Experian Jfrog Artifactory:

This package can be installed with pip using this index url

-   https://artifacts.experian.local/artifactory/api/pypi/ascend-ops/simple

Example Installation Command

```
pip install ascendops-commonlib --trusted-host artifacts.experian.local --extra-index-url https://artifacts.experian.local/artifactory/api/pypi/ascend-ops/simple
```

You can also install a locally built distribution for local testing

```
pip install path/to/ascendops_commonlib-0.1.tar.gz --trusted-host artifacts.experian.local
```

For example `(in the current file structure)`:

```
pip install dist/ascendops_commonlib-0.1.tar.gz --trusted-host artifacts.experian.local
```

##

## Usage

---

### App Utils

#### App Util

```
from ascendops_commonlib.ops_utils import ops_util

ops_util.get_epoch_millis()
# output: 1693180800000

ops_util.generate_go_txn_id()
# output: 08282023000000KUIYGUOVP
```

#### App Config

```
from ascendops_commonlib.ops_utils import ops_config
ops_config.DEFAULT_REGION
# output: us-east-1
```

<br/>

### Datastores

#### ElasticSearch (AWS Opensearch prefork v7.10)

```
from ascendops_commonlib.datastores.es_util import ESConnector

es = ESConnector()
es.index_document(<index_name>, <doc_id>, <doc>
```

<br/>

### Eventstores

#### Kafka (AWS MSK)

#### AWS Eventbridge

---

## Contributing

---

Limited to Ascend Ops limited internal team only right now. Follow along for further updates. Need `boto3-stubs` for type checking.

### Testing

Following exports were done before running pytest:

```
export IAM_PROFILE=uat-api-role
export DEFAULT_ES_HOST=vpc-uat-ascend-go-wdae7basbpxdvkgtpnicgu53jm.us-east-1.es.amazonaws.com
export DEFAULT_ES_PORT=443
export DEFAULT_ES_ROLE=arn:aws:iam::262403030294:role/uat-es-role
```

And then run with command: `pytest -r`

To see the code coverage report, use the `--cov` property with pytest. `pytest--cov` lib needs to be installed. And generate the coverage report:

```
pytest --cov=.
```

### Deployment

Jenkins pipeline: https://build.experian.local/job/GLOBAL/job/CIS/job/ascend_go/job/upload_to_artifactory/job/ascendops-commonlib/

This pipeline runs the tests, builds the package, and pushes to artifactory.

---

## License

---

This project is Experian proprietary
