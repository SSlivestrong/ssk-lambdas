""" Application Autoscaling Connector for a specific client """
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.aws_utils.application_autoscaling_connector import (
    ApplicationAutoscalingConnector,
)


class ClientApplicationAutoscalingConnector(ApplicationAutoscalingConnector):
    """Connects to application autoscaling using client role"""

    def __init__(self, client_alias: str) -> None:
        """Constructs a client application autoscaling connector
        Params:
            client_alias: alias of client
        """

        role_arn = f"arn:aws:iam::{ops_config.AWS_ACCOUNT}:role/{ops_config.RUNTIME_ENV}-{client_alias}-sagemaker"

        super().__init__(role_arn=role_arn)
