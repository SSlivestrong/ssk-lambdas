import json
from logging import Logger
import time
import aws_encryption_sdk
from ascendops_commonlib.aws_utils.boto_session import BotoSession
import lz4.frame

class KMSCrypto:

    materials_manager = None
    client: aws_encryption_sdk.EncryptionSDKClient = None

    def __init__(self) -> None:
        pass

    @staticmethod
    def init(kms_key_id):
        if KMSCrypto.materials_manager == None:
            BotoSession.init()
            cache = aws_encryption_sdk.LocalCryptoMaterialsCache(capacity=10)
            KMSCrypto.client = aws_encryption_sdk.EncryptionSDKClient(
                commitment_policy=aws_encryption_sdk.CommitmentPolicy.REQUIRE_ENCRYPT_ALLOW_DECRYPT
            )
            kms_prime_key = aws_encryption_sdk.StrictAwsKmsMasterKeyProvider(
                key_ids=[kms_key_id],
                botocore_session = BotoSession.botocore_session
                )
            KMSCrypto.materials_manager = aws_encryption_sdk.CachingCryptoMaterialsManager(
                master_key_provider=kms_prime_key,
                cache=cache,
                max_age=3600.0,
                max_messages_encrypted=500000)
    
    @staticmethod
    def encrypt_dict(doc: dict, logger: Logger = None) -> bytes:

        enc_txt = None
        try:            
            txt = json.dumps(doc).encode('utf-8')
            compressed_bytes = lz4.frame.compress(txt)
            if logger:
                logger.debug("encrypting")
            enc_txt, _ = KMSCrypto.client.encrypt(
                source=compressed_bytes,
                materials_manager=KMSCrypto.materials_manager
            )
        except Exception as exp:
            raise exp
        
        return enc_txt

    @staticmethod
    def decrypt_dict(enc_txt: bytes, logger: Logger = None) -> dict:
        
        decrypted_plaintext = None
        try:
            decrypted_plaintext, _ = KMSCrypto.client.decrypt(
                source=enc_txt,
                materials_manager=KMSCrypto.materials_manager
            )
        except Exception as exp:
            raise exp

        doc = json.loads(lz4.frame.decompress(decrypted_plaintext)) if decrypted_plaintext else None
    
        return doc
    