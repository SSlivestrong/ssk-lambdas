"""
This module provides a utility class for interacting with AWS Secrets Manager

The SecretsManagerUtil class provides a method for retrieving a secret value from AWS Secrets Manager.
This can be used to manage secrets in a secure and scalable way.

Usage:
    secrets_manager_util = SecretsManagerUtil(region_name="us-east-1")
    secret = secrets_manager_util.get_secret("my_secret_name)
    print(secret)

Classes:
    SecretsManagerUtil: Utility class for interacting with AWS Secrets Manager.
"""
import json
import boto3


class SecretsManagerUtil:
    """
    Utility class for interacting with AWS Secrets Manager.
    """

    def __init__(self, region_name="us-east-1"):
        """
        init method to create the secretsmanager client
        """
        self.client = boto3.client("secretsmanager", region_name=region_name)
    

    def get_secret(self, secret_name):
        """
        Retrive a secret value from AWS Secrets Manager.
        
        Params:
         - secret_name: name of the secret
        
        Returns:
         - secret value
        """
        try:
            response = self.client.get_secret_value(SecretId=secret_name)
        except Exception as xcp:
            raise xcp
        
        if "SecretString" in response:
            secret = response["SecretString"]
            return json.loads(secret)
        
        return None
