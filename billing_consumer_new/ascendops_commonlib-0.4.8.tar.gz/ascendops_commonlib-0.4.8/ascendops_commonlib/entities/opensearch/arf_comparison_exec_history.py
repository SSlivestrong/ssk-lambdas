""" Entity to represent comments """
from typing import Optional
from datetime import datetime
from opensearch_dsl import Keyword, Text

from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.entities.opensearch.fields.na_epoch_millis_date_field import (
    NAEpochMillisDateField,
)
from ascendops_commonlib.ops_utils import ops_config


class ArfComparisonExecHistory(NABaseDocument):
    """Opensearch Entity to represent Comments"""

    exec_id: Optional[str] = Keyword()
    solution_id: Optional[str] = Keyword()
    solution_date: Optional[str] = Keyword()
    status: Optional[str] = Keyword()
    failure_reason: Optional[str] = Text()
    exec_start_time: Optional[datetime] = NAEpochMillisDateField(format="epoch_millis")
    exec_end_time: Optional[datetime] = NAEpochMillisDateField(format="epoch_millis")

    class Index:
        """Opensearch Index where comment documents are stored"""

        name: str = ops_config.ARF_COMPARISON_EXEC_HISTORY_INDEX_NAME
