""" Extends opensearch_dsl Date class so that epoch millis format can be used """
from datetime import datetime, timezone
from opensearch_dsl import CustomField

# for example implementation of CustomField see SecretField
# https://github.com/opensearch-project/opensearch-dsl-py/blob/78e9fb4d66a8a323fceeeb25b74b9ce815368b1b/tests/test_document.py


class NAEpochMillisDateField(CustomField):
    """Epoch millisecond UTC timestamp Opensearch field"""

    builtin_type = "date"

    def _serialize(self, data):
        """serializes datetime to epoch millis timestamp"""
        return round(data.replace(tzinfo=timezone.utc).timestamp() * 1000)

    def _deserialize(self, data):
        """deserializes epoch timestamp into datetime"""
        # NOTE: in example of the library
        if isinstance(data, str):
            data = int(data)
        if isinstance(data, datetime):
            return data
        return datetime.utcfromtimestamp(data / 1000)
