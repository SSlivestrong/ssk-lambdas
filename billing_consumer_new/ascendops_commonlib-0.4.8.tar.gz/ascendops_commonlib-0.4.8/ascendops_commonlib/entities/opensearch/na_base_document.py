""" Base Document with common fields for all Opensearch documents """
from typing import Optional
import datetime
from opensearch_dsl import Document, Keyword, MetaField, Search

from ascendops_commonlib.entities.opensearch.fields.na_epoch_millis_date_field import (
    NAEpochMillisDateField,
)
from ascendops_commonlib.entities.opensearch.doc_search import DocSearch

# controls max documents returned in opensearch search
SEARCH_MAX_DOCUMENTS = 10000


class NABaseDocument(Document):
    """Base Document with common fields for all Opensearch documents"""

    uid: Optional[str] = Keyword()
    created_by: Optional[str] = Keyword()
    created_on: Optional[datetime.datetime] = NAEpochMillisDateField(
        format="epoch_millis"
    )
    updated_by: Optional[str] = Keyword()
    updated_on: Optional[datetime.datetime] = NAEpochMillisDateField(
        format="epoch_millis"
    )

    @classmethod
    def create_from_dict(cls, dictionary):
        """Creates a document from a dictionary"""
        # TODO: would be good to have some validation here to check the values in the dictionary
        # are the defined class attributes  but not sure if that is something that
        # can be done in python
        document = cls()
        document._from_dict(dictionary)
        return document

    @classmethod
    def create_search_object(
        cls,
        include_fields: Optional[list[str]] = None,
        exclude_fields: Optional[list[str]] = None,
        max_docs: int = SEARCH_MAX_DOCUMENTS,
    ) -> Search:
        """Creates a search object for the entity and sets max documents"""
        search = cls.search()
        if include_fields:
            search = search.source(includes=include_fields)
        if exclude_fields:
            search = search.source(excludes=exclude_fields)
        search = search[0:max_docs]
        return search

    @classmethod
    def create_doc_search_object(
        cls, include_fields=None, exclude_fields=None, max_docs=SEARCH_MAX_DOCUMENTS
    ) -> DocSearch:
        """Creates a doc_search object for the entity"""
        search = DocSearch.search(cls)
        if include_fields:
            search = search.source(includes=include_fields)
        if exclude_fields:
            search = search.source(excludes=exclude_fields)
        search = search[0:max_docs]
        return search

    @classmethod
    def query_fields(
        cls,
        query_map: dict,
        include_fields: Optional[list[str]] = None,
        exclude_fields: Optional[list[str]] = None,
    ) -> DocSearch:
        """Queries fields given as map(field_name, field_value)"""
        search = cls.create_doc_search_object(include_fields, exclude_fields)

        for field, value in query_map.items():
            if value:
                search = search.query_term(field=field, value=value)
        return search

    @classmethod
    def query_fields_values(
        cls,
        query_map: dict,
        include_fields: Optional[list[str]] = None,
        exclude_fields: Optional[list[str]] = None,
    ) -> DocSearch:
        """Queries fields given as map(field_name, list of field_values)"""
        search = cls.create_doc_search_object(include_fields, exclude_fields)

        for field, values in query_map.items():
            if type(values) is not list:
                raise Exception(f"found {type(values)} should be a list")
            null_safe_vals = [val for val in values if val is not None]
            if len(null_safe_vals) >= 1:
                search = search.query_terms(field=field, values=null_safe_vals)
        return search

    def update_from_dict(self, dictionary: dict) -> None:
        """updates properties from a dictionary, overload this method in child class to include other properties"""
        if "updated_by" in dictionary:
            self.updated_by = dictionary.get("updated_by")

    def set_create_document_metadata(self) -> None:
        """sets the metadata needed before creating a document in opensearch"""
        # set created time to now
        self.created_on = datetime.datetime.utcnow()
        # set updated time to now
        self.updated_on = datetime.datetime.utcnow()
        self.updated_by = self.created_by
        # set opensearch id to match uid property
        self.meta.id = self.uid

    def convert_to_opensearch_action(self, op_type) -> dict:
        """Returns object as a dictionary that can be used for an bulk operation
        See: https://opster.com/guides/opensearch/opensearch-operations/opensearch-py-bulk/ for
        more on bulk operations
        """
        # turn entity into a dictionary and include index and id metadata
        action_dict = self.to_dict(include_meta=True)

        # set op type in dictionary.
        action_dict["_op_type"] = op_type
        return action_dict

    def insert_document(self, refresh="false") -> bool:
        """saves a document in opensearch and sets create information"""

        self.set_create_document_metadata()
        return super().save(op_type="create", refresh=refresh)

    def update_document(self, refresh="wait_for") -> bool:
        """Updates document in opensearch and updates updated by info"""

        # updating document so set updated_on to now
        self.updated_on = datetime.datetime.utcnow()

        return super().save(refresh=refresh)

    def delete_document(self) -> None:
        """Deletes the entry in opensearch"""
        self.delete()

    class Meta:
        """Define default properties for Opensearch Mapping"""

        # throw an error if try to save document with unexpected fields
        dynamic: MetaField = MetaField("strict")

    class Index:
        """Define default properties for Opensearch Index"""

        # settings for opensearch index
        settings: dict = {"number_of_shards": 1, "number_of_replicas": 1}
