""" Entity to represent subcode """
from typing import Optional
from opensearch_dsl import Text, Keyword, MetaField

from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.ops_utils import ops_config


class Subcode(NABaseDocument):
    """Opensearch Entity to represent subcode entity"""

    name: Optional[str] = Text()
    client_name: Optional[str] = Text()
    client_uid: Optional[str] = Keyword()
    description: Optional[str] = Text()

    class Index:
        """Opensearch Index where subcode documents are stored"""

        name: str = ops_config.SUBCODE_INDEX_NAME

    class Meta:
        """Defines properties for Opensearch Mapping"""

        # overrides default dynamic value
        # controls whether new fields are added dynamically to index mapping
        dynamic: MetaField = MetaField("false")
