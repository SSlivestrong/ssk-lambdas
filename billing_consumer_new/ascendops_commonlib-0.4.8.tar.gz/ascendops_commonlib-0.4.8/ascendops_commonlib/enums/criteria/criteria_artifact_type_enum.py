""" Represents the type of artifacts that define a criteria. """

from enum import Enum, unique


# Inherits from str as well so that enum is json serializable
@unique
class CriteriaArtifactTypeEnum(str, Enum):
    """represents the type of criteria artifacts"""

    # this artifact defines the input and outputs of the criteria
    ATTRIBUTES: str = "attributes"

    # this artifact contains the criteria logic and is used in batch execution
    PICKLE: str = "pickle"

    # this artifact contains the criteria logic and is used in real-time execution
    PICKLE_RT: str = "pickle_rt"
