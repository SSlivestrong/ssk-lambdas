"""Helper functions
"""


def get_all_docs():
    """ query all definition
    """
    get_all_docs_query = {
        "query": {
            "match_all": {}
        }
    }

    return get_all_docs_query


def filter_by_term(field_name, field_value):
    """ query definition
    """
    filter_by_term_query = {
        "query": {
            "match": {
                field_name: field_value
            }
        }
    }

    return filter_by_term_query


def ids_list(list_of_doc_ids):
    """query definition
    """
    query = {
        "query": {
            "ids": {
                "values": list_of_doc_ids
            }
        }
    }
    return query


def filter_by_terms(fields_list):
    """query definition
    """
    dict_list = []
    for key, value in fields_list.items():
        dict_list.append({"term": {key: value}})
    query = {"query": {"bool": {"must": []}}}
    query['query']['bool']['must'] = dict_list

    return query


def nested_bool_should_t2(match_list, client_alias=None):
    """bool and should filters for two terms
    """
    query_spec = {
        "query": {
            "bool": {
                "should": list(map(lambda feature_name:
                                   {"bool": {"should": [
                                       {"match": {"name": feature_name}},
                                       {"match": {"alias": feature_name}}
                                   ]}}, match_list))
            }
        }
    }
    if client_alias:
        dataset_alias = f"{client_alias}_ds"
        query_spec = {
            "query": {
                "bool": {
                    "should": list(map(lambda feature_name:
                                       {
                                           "bool": {
                                               "should": [
                                                   {
                                                       "bool": {
                                                           "must": [
                                                               {"term": {"name": feature_name}},
                                                               {"term": {"dataset_alias": dataset_alias}}
                                                           ]
                                                       }
                                                   },
                                                   {
                                                       "bool": {
                                                           "must": [
                                                               {"term": {"alias": feature_name}},
                                                               {"term": {"dataset_alias": dataset_alias}}
                                                           ]
                                                       }
                                                   }
                                               ]
                                           }
                                       }, match_list))
                }
            }
        }
    return query_spec


def query_features_not_custom(features_list):
    """build a query to get all feature docs from features_list (name/alias) match but not a part of custom datasets
    returns: query_spec doc
    """
    query_spec = {
        "query": {
            "bool": {
                "should": list(map(lambda feature_name:
                    {
                        "bool": {
                            "should": [
                                {"match": {"name": feature_name}},
                                {"match": {"alias": feature_name}}
                            ],
                            "must_not": {
                                "term": {"type": "custom"}
                            }
                        }
                    }, features_list)),
            }
        }
    }

    return query_spec


def nested_client_custom_features(client_alias, feature_alias_name_map):
    """bool and should filters for two terms
    """
    client_dataset_alias = f"{client_alias}_ds"
    query_spec = {
        "query": {
            "bool": {
                "must": list(map(lambda feature_alias_name:
                    {
                        "bool": {
                            "should": [
                                {"match": {"alias": feature_alias_name[0]}},
                                {"match": {"name": feature_alias_name[1]}}
                            ],
                            "must": [
                                {"term": {"type": "custom"}},
                                {"term": {"dataset_alias": client_dataset_alias}}
                            ]
                        }
                    }, feature_alias_name_map.items()))
            }
        }
    }

    return query_spec


def nested_bool_should_t2_marketing_deprecated(match_list, client_alias, purpose_sub_type):
    """bool with should and must for marketing (Deprecated) 
    """
    query_spec = {
        "query": {
            "bool": {
                "should": list(map(lambda feature_name:
                                   {"bool": {"should": [
                                       {
                                           "bool": {
                                               "must": [
                                                   {"term": {"name": feature_name}},
                                                   {"term": {"client_alias": client_alias}},
                                                   {"term": {"purpose_sub_type": purpose_sub_type}}
                                               ]
                                           }
                                       },
                                       {
                                           "bool": {
                                               "must": [
                                                   {"term": {"alias": feature_name}},
                                                   {"term": {"client_alias": client_alias}},
                                                   {"term": {"purpose_sub_type": purpose_sub_type}}
                                               ]
                                           }
                                       }
                                   ]}}, match_list))
            }
        }
    }

    return query_spec


def nested_bool_should_t2_marketing(match_list, client_alias, purpose_sub_type, partner_name):
    """bool with should and must for marketing
    """
    query_spec = {
        "query": {
            "bool": {
                "should": list(map(lambda feature_name:
                                   {"bool": {"should": [
                                       {
                                           "bool": {
                                               "must": [
                                                   {"term": {"name": feature_name}},
                                                   {"term": {"client_alias": client_alias}},
                                                   {"term": {"purpose_sub_type": purpose_sub_type}},
                                                   {"term": {"partner_name": partner_name}}
                                               ]
                                           }
                                       },
                                       {
                                           "bool": {
                                               "must": [
                                                   {"term": {"name": feature_name}},
                                                   {"term": {"client_alias": client_alias}},
                                                   {"term": {"purpose_sub_type": purpose_sub_type}},
                                                   {"term": {"partner_name": purpose_sub_type}}
                                               ]
                                           }
                                       },
                                       {
                                           "bool": {
                                               "must": [
                                                   {"term": {"alias": feature_name}},
                                                   {"term": {"client_alias": client_alias}},
                                                   {"term": {"purpose_sub_type": purpose_sub_type}},
                                                   {"term": {"partner_name": partner_name}}
                                               ]
                                           }
                                       },
                                       {
                                           "bool": {
                                               "must": [
                                                   {"term": {"alias": feature_name}},
                                                   {"term": {"client_alias": client_alias}},
                                                   {"term": {"purpose_sub_type": purpose_sub_type}},
                                                   {"term": {"partner_name": purpose_sub_type}}
                                               ]
                                           }
                                       }
                                   ]}}, match_list))
            }
        }
    }

    return query_spec


def uid_nested_match_query(doc_uid, match_key, match_value):
    """get docs if uid and nested path matches
    """
    query_spec = {
        "query": {
            "bool": {
                "must": [
                    {
                        "term": {
                            "uid": {
                                "value": doc_uid
                            }
                        }
                    },
                    {
                        "nested": {
                            "path": "artifacts",
                            "query": {
                                "bool": {
                                    "must": [
                                        {"match": { match_key : match_value } }
                                    ]
                                }
                            }
                        }
                    }
                ]
            }
        }
    }

    return query_spec


def match_by_field_name(field_name, field_value):
    """
    search client names by name

    """
    query_spec = {
        'size': 10000,
        'query': {
        'match' : {field_name: field_value}
        }
        }
    return query_spec


def match_by_regex(field_name, field_value):
    """
    search clients name by regex char
    """
    query_spec= {
                "query": {
                    "regexp": {
                    field_name: {
                        "value": ".*"+field_value+".*",
                        "flags": "ALL",
                        "max_determinized_states": 1000,
                        "rewrite": "constant_score"
                    }
                    }
                }
                }
    print("query:",query_spec)
    return query_spec


def get_query_filter_realtime_models(stage):
    """ 
    searches active and inservice realtime models
    """
    if stage == "prod":
        filter_match = {
            "bool": {
                "must": [
                    {"term": {"model_status": "active"}},
                    {"term": {"prod_stage.status": "InService"}},
                    {"term": {"execution_mode_realtime": True}},
                    {"exists": {"field": "model_code"}}
                ],
                "must_not": [
                    {"term": {"model_code": "9Z"}},
                    {"term": {"model_code": ""}}
                ]
            }
        }
    else:
        filter_match = {
            "bool": {
                "must": [
                    {"term": {"test_stage.status": "InService"}},
                    {"term": {"execution_mode_realtime": True}},
                    {"exists": {"field": "model_code"}},
                    {
                        "bool": {
                            "should": [
                                {"term": {"model_status": "test"}},
                                {"term": {"model_status": "active"}}
                            ]
                        }
                    }
                ],
                "must_not": [
                    {"term": {"model_code": "9Z"}},
                    {"term": {"model_code": ""}}
                ]
            }
        }
    
    return filter_match
