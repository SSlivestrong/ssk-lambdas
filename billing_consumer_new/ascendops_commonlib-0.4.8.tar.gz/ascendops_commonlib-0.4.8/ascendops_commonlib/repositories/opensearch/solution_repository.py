"""
    Performs operations relatated to soutions
"""
from ascendops_commonlib.entities.opensearch.solution import Solution


def opensearch_get_aggregated_solutions():
    """Gets all the solutions
    Returns:
        list of solutions objects
    """
    # TODO: I think this by_version aggregation should not be necessary. However, I see that removing
    # the by solution only has 3 inner documents although size is 1000
    query_spec = {
        "size": 0,
        "query": {"bool": {"must": {"exists": {"field": "version"}}}},
        "aggs": {
            "by_solution_id": {
                "terms": {
                    "field": "solution_id",
                    "size": 1000,
                },
                "aggs": {
                    "by_version": {
                        "terms": {
                            "field": "version",
                            "size": 1000,
                        },
                        "aggs": {
                            "include_source": {
                                "top_hits": {
                                    "_source": {
                                        "include": [
                                            "uid",
                                            "is_available_for_integration_testing",
                                            "status",
                                            "version",
                                            "updated_on",
                                            "updated_by",
                                            "created_by",
                                            "created_date",
                                            "solution_id",
                                            "created_on",
                                            "solution_type",
                                            "client_name",
                                        ]
                                    }
                                }
                            }
                        },
                    }
                },
            },
        },
    }
    search = Solution.create_search_object()
    search.update_from_dict(query_spec)
    return search.execute().aggregations


def opensearch_get_solution(uid: str) -> Solution:
    """To retrieve a Solution document with uid
    Params:
        uid: uniquely identifies a Solution
    Return:
        Solution object
    """
    return Solution.get(uid)


def opensearch_get_solutions(**kwargs) -> list[Solution]:
    """To retrieve a Solution document with uid
    Params:
        uid: uniquely identifies a Solution
    Return:
        Solution object
    """
    solution_id = kwargs.get("solution_id")
    status = kwargs.get("status")
    is_available_for_integration_testing = kwargs.get(
        "is_available_for_integration_testing"
    )
    include_fields = kwargs.get("include_fields")
    exclude_fields = kwargs.get("exclude_fields")

    search = Solution.create_search_object(
        include_fields=include_fields, exclude_fields=exclude_fields
    )
    term_queries_added = False
    if solution_id is not None:
        search = search.query("term", solution_id=solution_id)
        term_queries_added = True
    if status is not None:
        search = search.query("term", status=status)
        term_queries_added = True
    if is_available_for_integration_testing is not None:
        search = search.query(
            "term",
            is_available_for_integration_testing=is_available_for_integration_testing,
        )
        term_queries_added = True

    # if no term queries added, search all documents
    if not term_queries_added:
        search = search.query("match_all")

    return search.execute().hits


def opensearch_create_solution(
    solution: Solution, created_by: str, refresh="false"
) -> Solution:
    """To create a solution document
    Params:
        solution: defines properties of solution  object
        created_by: creator of solution
    Return:
        Solution object
    """
    solution.created_by = created_by
    solution.insert_document(refresh=refresh)
    return solution


def opensearch_update_solution(
    solution: Solution, update_json: dict, refresh: str = "wait_for"
) -> Solution:
    """To update a solution document
    Params:
        solution: defines properties of solution object
        update_json: properties and values to update in solution
    Return:
        Solution object
    """
    for row in update_json:
        solution[row] = update_json[row]
    solution.update_document(refresh=refresh)
    return solution
