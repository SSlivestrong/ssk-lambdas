from opensearch_dsl import Search
from opensearchpy.helpers import bulk
from ascendops_commonlib.entities.opensearch.solution_test_history import (
    SolutionTestHistory,
)


def opensearch_get_solution_test_history(uid: str) -> SolutionTestHistory:
    """Gets solution test history by uid
    Parameters:
        uid: uniquely identifies a solution test case
    Returns:
        solution test history doc
    """
    return SolutionTestHistory.get(uid)


def opensearch_get_solution_test_histories(**kwargs) -> list[SolutionTestHistory]:
    """Gets all solution test histories filterd by given parameters
    Parameters:
        solution_uid: each test belongs to a specific solution
        test_suite_execution_uid: identifies the suite execution this test was part of
        include_fields - Optional[list[str]]: document fields to include in returned document
        exclude_fields - Optional[list[str]]: document fields to exclude in returned document
    Returns:
        list of solution test histories
    """
    include_fields = kwargs.get("include_fields")
    exclude_fields = kwargs.get("exclude_fields")
    solution_uid = kwargs.get("solution_uid")
    test_suite_execution_uid = kwargs.get("test_suite_execution_uid")

    search: Search = SolutionTestHistory.create_search_object(
        include_fields=include_fields, exclude_fields=exclude_fields
    )

    term_queries_added = False

    if solution_uid is not None:
        search = search.query("term", solution_uid=solution_uid)
        term_queries_added = True

    if test_suite_execution_uid is not None:
        search = search.query("term", test_suite_execution_uid=test_suite_execution_uid)
        term_queries_added = True

    # if no term queries added, search all documents
    if not term_queries_added:
        search = search.query("match_all")

    return search.execute().hits


def opensearch_bulk_create_solution_test_history(
    opensearch_connection,
    solution_test_histories: "list[SolutionTestHistory]",
) -> None:
    """Creates multiple solution test histories at once
    Is much more performant than creating individually

    See https://opster.com/guides/opensearch/opensearch-operations/opensearch-py-bulk/
    for more info on bulk operations
    """
    create_actions = []
    for solution_test_history in solution_test_histories:
        # since not using insert document method, need to set create metadata
        solution_test_history.set_create_document_metadata()
        # turn entity into a dictionary and include metadata so can be properly created with bulk method
        create_actions.append(
            solution_test_history.convert_to_opensearch_action("create")
        )

    # opensearch dsl does not support bulk directly, use opensearch py bulk method
    bulk(
        opensearch_connection,
        create_actions,
        index=SolutionTestHistory.Index.name,
    )


def opensearch_get_test_suite_summaries(solution_uid: str) -> list[dict]:
    """Returns a list od summary of test suites per solution. A test suite is a set of tests with the same test_suite_execution_uid"""
    search: Search = SolutionTestHistory.create_search_object(
        include_fields=[
            "test_suite_execution_uid",
            "test_suite_submitted_on",
            "status",
            "status_daas",
            "runtime_ms",
            "solution_uid",
            "test_suite_execution_name",
            "created_by",
        ]
    )
    # this will make hits return no values, we only care about the aggregations
    search = search[0:0]
    search = search.query("term", solution_uid=solution_uid)
    # group by test suite execution id
    search.aggs.bucket(
        "group_by_test_suite", "terms", field="test_suite_execution_uid", size=10000
    )
    # get total runtime by summing runtime of all tests
    search.aggs["group_by_test_suite"].metric(
        "total_runtime", "sum", field="runtime_ms"
    )
    # get count of each status
    search.aggs["group_by_test_suite"].bucket("by_status", "terms", field="status")
    # add one document to get other test suite info
    search.aggs["group_by_test_suite"].metric("top_hit", "top_hits", size=1)
    # for Daas tests get count of each status
    search.aggs["group_by_test_suite"].bucket(
        "by_status_daas", "terms", field="status_daas"
    )

    response = search.execute()
    # create summaries from response
    summaries = []
    for aggregation in response["aggregations"]["group_by_test_suite"]["buckets"]:
        # convert to dictionary to use get function with default
        aggregation_dict = aggregation.to_dict()
        # create status dictionary for ease of use
        status_dictionary = {}
        status_dictionary_daas = {}
        for bucket_dictionary in aggregation_dict["by_status"]["buckets"]:
            status_dictionary[bucket_dictionary["key"]] = bucket_dictionary["doc_count"]
        for bucket_dictionary in aggregation_dict["by_status_daas"]["buckets"]:
            status_dictionary_daas[bucket_dictionary["key"]] = bucket_dictionary[
                "doc_count"
            ]
        # extract info for summary
        summary = {
            "test_suite_execution_uid": aggregation_dict["top_hit"]["hits"]["hits"][0][
                "_source"
            ].get("test_suite_execution_uid"),
            "test_suite_execution_name": aggregation_dict["top_hit"]["hits"]["hits"][0][
                "_source"
            ].get("test_suite_execution_name"),
            "total_runtime": int(aggregation_dict["total_runtime"].get("value")),
            "number_tests": aggregation_dict["doc_count"],
            # convert to dictionary to use get function with default
            "number_created_status": int(status_dictionary.get("created", 0)),
            "number_failed_status": int(status_dictionary.get("failed", 0)),
            "number_passed_status": int(status_dictionary.get("passed", 0)),
            "submitted_on": aggregation_dict["top_hit"]["hits"]["hits"][0][
                "_source"
            ].get("test_suite_submitted_on"),
            "submitted_by": aggregation_dict["top_hit"]["hits"]["hits"][0][
                "_source"
            ].get("created_by"),
            # daas tests
            "number_tests_daas": int(status_dictionary_daas.get("failed", 0))
            + int(status_dictionary_daas.get("passed", 0)),
            "number_failed_status_daas": int(status_dictionary_daas.get("failed", 0)),
            "number_passed_status_daas": int(status_dictionary_daas.get("passed", 0)),
        }
        summaries.append(summary)
    return summaries
