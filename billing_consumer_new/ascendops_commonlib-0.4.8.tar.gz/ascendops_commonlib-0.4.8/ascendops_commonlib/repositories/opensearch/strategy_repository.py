"""
    Performs operations related to strategy
"""
from ascendops_commonlib.entities.opensearch.strategy import Strategy


def opensearch_create_strategy(
    strategy: Strategy, created_by: str, refresh="false"
) -> Strategy:
    """To create a strategy document
    Params:
        solution: defines properties of strategy  object
    Return:
        strategy object
    """
    strategy.created_by = created_by
    strategy.insert_document(refresh=refresh)
    return strategy


def opensearch_get_strategies(**kwargs) -> "list[Strategy]":
    """To retrieve strategy documents with properties
    Params:
        client_uid - Optional[str]: uniquely identifies a client
        strategy_name - Optional[str]: strategy name
        include_fields - Optional[list[str]]: document fields to include in returned document
        exclude_fields - Optional[list[str]]: document fields to exclude in returned document

    Return:
        list of strategy objects
    """

    client_uid = kwargs.get("client_uid")
    strategy_name = kwargs.get("strategy_name")
    include_fields = kwargs.get("include_fields")
    exclude_fields = kwargs.get("exclude_fields")

    search = Strategy.create_search_object(
        include_fields=include_fields, exclude_fields=exclude_fields
    )

    term_queries_added = False

    if client_uid is not None:
        search = search.query("term", client_uid=client_uid)
        term_queries_added = True
    if strategy_name is not None:
        search = search.query("term", strategy_name=strategy_name)
        term_queries_added = True
    if not term_queries_added:
        search = search.query("match_all")
    return search.execute().hits


def opensearch_get_strategy(strategy_uid: str) -> Strategy:
    """To retrieve a strategy document with uid
    Params:
        strategy_uid: uniquely identifies a strategy
    Return:
        strategy object
    """
    return Strategy.get(strategy_uid)
