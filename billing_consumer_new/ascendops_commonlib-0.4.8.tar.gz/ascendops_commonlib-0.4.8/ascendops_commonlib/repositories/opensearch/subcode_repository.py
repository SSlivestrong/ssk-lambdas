"""
    Performs operations related to subcode
"""
from ascendops_commonlib.entities.opensearch.subcode import Subcode


def opensearch_get_subcodes(**kwargs) -> "list[Subcode]":
    """To retrieve subcode documents with client_uid
    Params:
        client_uid: uniquely identifies a client
        include_fields - Optional[list[str]]: document fields to include in returned document
        exclude_fields - Optional[list[str]]: document fields to exclude in returned document
    Return:
        list of Subcode objects
    """

    client_uid = kwargs.get("client_uid")
    include_fields = kwargs.get("include_fields")
    exclude_fields = kwargs.get("exclude_fields")

    search = Subcode.create_search_object(
        include_fields=include_fields, exclude_fields=exclude_fields
    )
    term_queries_added = False
    if client_uid is not None:
        search = search.query("term", client_uid=client_uid)
        term_queries_added = True

    if not term_queries_added:
        search = search.query("match_all")
    return search.execute().hits
