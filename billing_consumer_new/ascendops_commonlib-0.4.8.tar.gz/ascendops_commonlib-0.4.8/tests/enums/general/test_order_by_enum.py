""" Unit tests for OrderByEnum """

import unittest
import json
from ascendops_commonlib.enums.general.order_by_enum import OrderByEnum


class TestOrderByEnumEnum(unittest.TestCase):
    """Unit tests for OrderByEnum"""

    def test_enum_construction(self):
        """Test that the enum can be constructed from a string"""
        self.assertEqual(
            OrderByEnum("asc"),
            OrderByEnum.ASC,
        )
        self.assertEqual(
            OrderByEnum("desc"),
            OrderByEnum.DESC,
        )

    def test_enum_values(self):
        """Test that the enum values are correct"""
        self.assertEqual(OrderByEnum.ASC.value, "asc")
        self.assertEqual(OrderByEnum.DESC.value, "desc")

    def test_enum_members(self):
        """Test that the enum members are correct"""
        self.assertEqual(
            OrderByEnum.ASC,
            OrderByEnum["ASC"],
        )
        self.assertEqual(
            OrderByEnum.DESC,
            OrderByEnum["DESC"],
        )

    def test_enum_json_serializable(self):
        """Test that enum is json serializable"""
        self.assertEqual(json.dumps(OrderByEnum.ASC), '"asc"')
        self.assertEqual(
            json.dumps(OrderByEnum.DESC),
            '"desc"',
        )
