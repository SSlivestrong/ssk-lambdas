""" Unit test cases for solution_test_history_repository """
import unittest
import datetime
from unittest.mock import MagicMock, patch, call

from ascendops_commonlib.entities.opensearch.solution_test_history import (
    SolutionTestHistory,
)
from ascendops_commonlib.repositories.opensearch import solution_test_history_repository


class TestSolutionTestHistoryRepository(unittest.TestCase):
    """Unit test cases for solution_test_history_repository"""

    def test_opensearch_get_solution_test_histories_all_kwargs(self):
        """tests get all documents with all kwargs given"""
        # ARRANGE
        solution_uid = "solution_uid"
        test_suite_execution_uid = "test_suite_exec_uid_1"
        client_name = "client_name_1"
        include_fields = ["name", "client_name"]
        exclude_fields = ["client_uid"]

        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [SolutionTestHistory()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            SolutionTestHistory, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = (
                solution_test_history_repository.opensearch_get_solution_test_histories(
                    solution_uid=solution_uid,
                    test_suite_execution_uid=test_suite_execution_uid,
                    client_name=client_name,
                    include_fields=include_fields,
                    exclude_fields=exclude_fields,
                )
            )
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=include_fields, exclude_fields=exclude_fields
            )

            # make sure all expected queries are added
            expected_query_calls = [
                call("term", solution_uid=solution_uid),
                call("term", test_suite_execution_uid=test_suite_execution_uid),
            ]
            mock_search.query.assert_has_calls(expected_query_calls, any_order=True)

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_get_solution_test_histories_match_all(self):
        """tests get all documents when no term kwargs given"""
        # ARRANGE
        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [SolutionTestHistory()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            SolutionTestHistory, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = (
                solution_test_history_repository.opensearch_get_solution_test_histories()
            )
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=None, exclude_fields=None
            )

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with("match_all")

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_bulk_create_solution_test_history(self):
        """tests bulk creates documents successfully"""
        # ARRANGE

        solution_test_history_1 = SolutionTestHistory()
        solution_test_history_1.uid = "1"
        solution_test_history_1.solution_uid = "test_solution__v1.0"

        solution_test_history_2 = SolutionTestHistory()
        solution_test_history_2.uid = "2"
        solution_test_history_2.solution_uid = "test_solution__v1.0"
        solution_test_histories = [solution_test_history_1, solution_test_history_2]

        mock_opensearch_connection = MagicMock()
        mock_date = datetime.datetime(year=2024, month=3, day=3)
        mock_epoch_millis = round(
            mock_date.replace(tzinfo=datetime.timezone.utc).timestamp() * 1000
        )

        expected_create_actions = [
            {
                "_id": "1",
                "_op_type": "create",
                "_index": "solution_test_history",
                "_source": {
                    "uid": "1",
                    "solution_uid": "test_solution__v1.0",
                    "created_on": mock_epoch_millis,
                    "updated_on": mock_epoch_millis,
                },
            },
            {
                "_id": "2",
                "_op_type": "create",
                "_index": "solution_test_history",
                "_source": {
                    "uid": "2",
                    "solution_uid": "test_solution__v1.0",
                    "created_on": mock_epoch_millis,
                    "updated_on": mock_epoch_millis,
                },
            },
        ]

        with patch(
            "ascendops_commonlib.entities.opensearch.na_base_document.datetime",
            wraps=datetime,
        ) as mock_datetime:

            mock_datetime.datetime.utcnow.return_value = mock_date

            with patch(
                "ascendops_commonlib.repositories.opensearch.solution_test_history_repository.bulk"
            ) as mock_bulk:

                # ACT
                solution_test_history_repository.opensearch_bulk_create_solution_test_history(
                    mock_opensearch_connection, solution_test_histories
                )

                # ASSERT

                # check correct paramaeters passed to bulk
                mock_bulk.assert_called_once_with(
                    mock_opensearch_connection,
                    expected_create_actions,
                    index=SolutionTestHistory.Index.name,
                )
