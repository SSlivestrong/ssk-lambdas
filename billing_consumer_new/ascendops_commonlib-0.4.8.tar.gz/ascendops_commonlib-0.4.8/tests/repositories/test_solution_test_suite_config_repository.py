""" Unit tests for solution_test_suite_config_repository """
import unittest
from unittest.mock import MagicMock, patch, call

from ascendops_commonlib.repositories.opensearch import (
    solution_test_suite_config_repository,
)
from ascendops_commonlib.entities.opensearch.solution_test_suite_config import (
    SolutionTestSuiteConfig,
)


class TestSolutionTestSuiteRepository(unittest.TestCase):
    """Unit tests for solution_test_suite_config_repository"""

    def test_opensearch_get_solution_test_suite_configs_all_kwargs(self):
        """tests get all documents with all kwargs given"""
        # ARRANGE
        include_fields = ["uid", "created_by"]
        exclude_fields = ["updated_by"]
        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [SolutionTestSuiteConfig()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            SolutionTestSuiteConfig, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = solution_test_suite_config_repository.opensearch_get_solution_test_suite_configs(
                include_fields=include_fields,
                exclude_fields=exclude_fields,
            )
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=include_fields, exclude_fields=exclude_fields
            )

            # make sure all expected queries are added
            expected_query_calls = [
                call("match_all"),
            ]
            mock_search.query.assert_has_calls(expected_query_calls, any_order=True)

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_get_solution_test_suite_configs_match_all(self):
        """tests get all documents when no term kwargs given"""
        # ARRANGE
        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [SolutionTestSuiteConfig()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            SolutionTestSuiteConfig, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = (
                solution_test_suite_config_repository.opensearch_get_solution_test_suite_configs()
            )
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=None, exclude_fields=None
            )

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with("match_all")

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)
