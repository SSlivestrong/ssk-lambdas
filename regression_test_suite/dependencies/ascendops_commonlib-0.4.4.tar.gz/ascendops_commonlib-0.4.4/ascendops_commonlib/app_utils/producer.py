"""Consume messages produced by Lambda
"""
import json, gzip
from kafka import KafkaProducer
from kafka.errors import KafkaError
from ascendops_commonlib.ops_utils import ops_util
from ascendops_commonlib.ops_utils import ops_config


class BytesEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, bytes):
            return obj.decode('utf-8')
        return json.JSONEncoder.default(self, obj)

def encode_if_bytes(obj):
    if isinstance(obj, bytes):
        return obj.decode('utf-8')
    return json.JSONEncoder.default(None, obj)

def value_serializer(x):
    if type(x) == list:
        if x[0] == "orjson/gzip":
            import orjson
            inbytes = orjson.dumps(x[1], default=encode_if_bytes, option=orjson.OPT_NON_STR_KEYS)
            return gzip.compress(inbytes, compresslevel=1)
        else:
            inbytes = json.dumps(x, cls=BytesEncoder).encode("utf-8")
            return inbytes
    else:
        inbytes = json.dumps(x, cls=BytesEncoder).encode("utf-8")
        return inbytes

class Producer():
    """Wrapper to connect to MSK cluster as a KafkaConsumer
    """

    def __init__(self, unique_client_id, topic, log, **kwargs):
        """Instantiate a KafkaProducer object
        """
        self.client_id = unique_client_id
        self.topic = topic
        self.log = log

        log.info("[P] initialize KafkaProducer %s", unique_client_id)
        num_retries = kwargs.pop("num_retries", "3")
        protocol = kwargs.pop("security_protocol", "SSL")
        if protocol == "SSL":
            private_key_pwd = kwargs.pop("private_key_pwd")
            cafile_path = kwargs.pop("cafile_path")
            certfile_path = kwargs.pop("certfile_path")
            keyfile_path = kwargs.pop("keyfile_path")
            num_retries = kwargs.pop("num_retries", 3)
            self.producer = KafkaProducer(
                bootstrap_servers=ops_config.MSK_BOOTSTRAP_SERVERS,
                client_id=unique_client_id,
                security_protocol=protocol,
                ssl_check_hostname=False,
                ssl_password=private_key_pwd,
                ssl_cafile=cafile_path,
                ssl_certfile=certfile_path,
                ssl_keyfile=keyfile_path,
                value_serializer=lambda x: value_serializer(x),
                retries=num_retries
            )
        else:
            self.producer = KafkaProducer(
                bootstrap_servers=ops_config.MSK_BOOTSTRAP_SERVERS,
                client_id=unique_client_id,
                value_serializer=lambda x: value_serializer(x),
                retries=num_retries
            )


    def send_message(self, msg_key, msg_body, headers=None):
        """ To send a message
        Args:
            msg_key: string
            msg_body: dictionary
        """
        if not msg_key:
            msg_key = self.client_id + "_" + ops_util.get_epoch_seconds_string()
        try: 
            future = self.producer.send(self.topic, key=msg_key.encode(), value=msg_body, headers=headers)
            record_metadata = future.get(timeout=ops_config.KAFKA_PRODUCER_TIMEOUT)
            self.log.debug("[P] Sent topic %s offset %s msg_key %s", record_metadata.topic,
                record_metadata.offset, msg_key)
            return True
        except KafkaError as kerr:
            self.log.error(kerr)
            return False
