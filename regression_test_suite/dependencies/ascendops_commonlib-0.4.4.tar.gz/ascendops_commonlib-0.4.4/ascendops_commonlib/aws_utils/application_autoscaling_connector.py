""" Connects to AWS Application Autoscaling Service - wrapper around boto3 application autoscaling client """
import logging
from ascendops_commonlib.aws_utils.aws_client_util import STSClientUtil


log = logging.getLogger("ascendopscommon")


class ApplicationAutoscalingConnector:
    """Connects to AWS Application Autoscaling Service - wrapper around boto3 application autoscaling client"""

    def __init__(self, role_arn=None) -> None:
        """creates boto3 auto-scaling client
        Params:
            role_arn - optional role to assume to use to connect to application autoscaling client
        """

        sts_client = STSClientUtil()
        self.application_autoscaling_client = sts_client.get_client(
            "application-autoscaling", role_arn=role_arn
        )

    def describe_scaling_policies(
        self, service_name_space: str, resource_id: str
    ) -> dict:
        """Describe Scaling Policies
        Params:
            service_name_space: AWS service that provides the resource
            resource_id: ID of the resource to list policies for
        Returns:
            dict - see boto3 application autoscaling documentation
        """
        return self.application_autoscaling_client.describe_scaling_policies(
            ServiceNamespace=service_name_space, ResourceId=resource_id
        )

    def delete_scaling_policy(
        self,
        service_name_space: str,
        policy_name: str,
        resource_id: str,
        scalable_dimension: str,
    ) -> None:
        """deletes the auto scaling policy
        Params:
            service_name_space: AWS service that provides the resource
            policy_name: name of policy to delete
            resource_id: ID of the resource policy belongs to
            scalable_dimension: dimension resource is scalable in
        """
        self.application_autoscaling_client.delete_scaling_policy(
            ServiceNamespace=service_name_space,
            PolicyName=policy_name,
            ResourceId=resource_id,
            ScalableDimension=scalable_dimension,
        )
        log.info(
            "Application Autoscaling Connector - deleted policy %s for resource %s",
            policy_name,
            resource_id,
        )

    def describe_scalable_targets(
        self,
        service_name_space: str,
        resource_ids: "list[str]",
        scalable_dimension: str,
    ) -> dict:
        """Describes registered scalable targets
        Params:
            service_name_space: AWS service that provides the resource
            resource_ids: list of string IDs of the resource to describe
            scalable_dimension: dimension resource is scalable in
        Return:
            dict - see boto3 application autoscaling describe scalable targets documentation
        """
        return self.application_autoscaling_client.describe_scalable_targets(
            ServiceNamespace=service_name_space,
            ResourceIds=resource_ids,
            ScalableDimension=scalable_dimension,
        )

    def deregister_scalable_target(
        self, service_name_space: str, resource_id: str, scalable_dimension: str
    ) -> None:
        """deregisters scalable target
        Params:
            service_name_space: AWS service that provides the resource
            resource_id: ID of the resource to deregister
            scalable_dimension: dimension resource is scalable in
        """
        self.application_autoscaling_client.deregister_scalable_target(
            ServiceNamespace=service_name_space,
            ResourceId=resource_id,
            ScalableDimension=scalable_dimension,
        )

        log.info(
            "Application Autoscaling Connector - deregistered %s target in %s dimension",
            resource_id,
            scalable_dimension,
        )
