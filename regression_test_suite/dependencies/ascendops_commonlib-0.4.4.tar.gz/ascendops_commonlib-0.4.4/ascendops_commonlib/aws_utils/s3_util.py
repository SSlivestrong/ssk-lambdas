"""
This module provides a utility class for interacting with AWS S3 objects

The S3util class provides methods to interact with AWS s3 objects including downloading files for a given s3 bucket, path and file name.

Classes:
    S3Util: utiltiy class that provides utility functions to interact with AWS S3 service
"""
import os
import boto3
import logging
from ascendops_commonlib.ops_utils import ops_config

log = logging.getLogger("ascendopscommon")
log_level = ops_config.LOG_LEVEL

CERT_DIR = os.path.join(ops_config.APP_DIR, "certs")
CACERT_LOCAL_PATH = os.path.join(CERT_DIR, ops_config.CACERT_FILE_NAME)
PUBLIC_CERT_LOCAL_PATH = os.path.join(CERT_DIR, ops_config.PUBLIC_CERT_FILE_NAME)
PRIVATE_KEY_LOCAL_PATH = os.path.join(CERT_DIR, ops_config.PRIVATE_KEY_FILE_NAME)


def download_pem_files():
    """Retrieve PEM files from s3 bucket
    """
    try:
        s3_resource = boto3.resource('s3', region_name=ops_config.DEFAULT_REGION)
        the_bucket = s3_resource.Bucket(ops_config.MSK_CERT_BUCKET_NAME)

        if not os.path.isfile(CACERT_LOCAL_PATH):
            with open(CACERT_LOCAL_PATH, "wb") as cacert_file:
                the_bucket.download_fileobj(ops_config.CACERT_S3_PATH, cacert_file)
                log.warning("Downloaded CA cert from s3")
        else:
            log.warning("Referenced CA cert from app")

        if not os.path.isfile(PUBLIC_CERT_LOCAL_PATH):
            with open(PUBLIC_CERT_LOCAL_PATH, "wb") as public_cert_file:
                the_bucket.download_fileobj(ops_config.PUBLIC_CERT_S3_PATH, public_cert_file)
                log.warning("Downloaded public cert from s3")
        else:
            log.warning("Referenced public cert from app")

        if not os.path.isfile(PRIVATE_KEY_LOCAL_PATH):
            with open(PRIVATE_KEY_LOCAL_PATH, "wb") as private_key_file:
                the_bucket.download_fileobj(ops_config.PRIVATE_KEY_S3_PATH, private_key_file)
                log.warning("Downloaded private key from s3")
        else:
            log.warning("Referenced private key from app")

    except Exception as xcp:
        log.error("Error setting Kafka certs: %s", str(xcp))
        