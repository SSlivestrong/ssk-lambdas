""" Entity to represent criteria entity """
from datetime import datetime
from typing import Optional
from opensearch_dsl import InnerDoc, Nested, Integer, Object, Text, Keyword


from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.entities.opensearch.fields.na_enum_opensearch_field import (
    NAEnumOpensearchField,
)
from ascendops_commonlib.entities.opensearch.fields.na_epoch_millis_date_field import (
    NAEpochMillisDateField,
)
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.enums.criteria.criteria_status_enum import CriteriaStatusEnum
from ascendops_commonlib.enums.criteria.offer_generator_version_enum import (
    OfferGeneratorVersionEnum,
)


class CriteriaFeature(InnerDoc):
    """Defines feature schema inside a model.
    Preserves feature information for this model even if features edited in feature index"""

    feature_uid: Optional[str] = Keyword()
    feature_name: Optional[str] = Keyword()
    feature_alias: Optional[str] = Keyword()
    feature_description: Optional[str] = Text()
    feature_dcr_name: Optional[str] = Text()
    feature_type: Optional[str] = Keyword()
    # feature_type = EnumOpensearchField(FeatureTypeEnum)
    feature_sequence: Optional[int] = Integer()
    feature_ss_usage_count: Optional[int] = Integer()
    feature_dataset_uid: Optional[str] = Keyword()
    feature_dataset_name: Optional[str] = Keyword()
    feature_dataset_alias: Optional[str] = Keyword()
    feature_dataset_type: Optional[str] = Keyword()
    feature_dataset_display_name: Optional[str] = Text()
    feature_dataset_source: Optional[str] = Text()
    feature_dataset_code: Optional[str] = Keyword()
    feature_dataset_online_store_system: Optional[str] = Keyword()
    feature_arftype: Optional[int] = Integer()
    feature_valid_values: Optional[str] = Text()

    feature_default: Optional[str] = Text()
    feature_min_value: Optional[str] = Text()
    feature_max_value: Optional[str] = Text()
    # feature_dataset_type = EnumOpensearchField(DatasetTypeEnum)
    feature_dataset_category: Optional[str] = Keyword()
    # feature_dataset_category = EnumOpensearchField(DatasetCategoryEnum)

    feature_datatype: Optional[str] = Keyword()
    feature_length: Optional[int] = Integer()
    feature_decimal_scale: Optional[int] = Integer()
    sequence: Optional[int] = Integer()


class CriteriaOutput(InnerDoc):
    """Defines outputs of a model"""

    name: Optional[str] = Keyword()
    alias: Optional[str] = Keyword()
    description: Optional[str] = Text()
    keyword: Optional[str] = Keyword()
    # type of the output attribute. Can be key, score, aac or any of feature type
    output_field_type: Optional[str] = Keyword()
    # output_field_type = EnumOpensearchField(FeatureTypeEnum)
    datatype: Optional[str] = Text()
    length: Optional[int] = Integer()
    decimal_scale: Optional[int] = Integer()
    default: Optional[str] = Text()
    default_values_desc: Optional[str] = Text()
    min_value: Optional[str] = Text()
    max_value: Optional[str] = Text()
    sequence: Optional[int] = Integer()


class SystemDatasets(InnerDoc):
    """system datasets containing dataset codes"""

    ATB = Text(multi=True)
    CLA = Text(multi=True)
    EQX = Text(multi=True)
    EXP = Text(multi=True)
    LEX = Text(multi=True)
    OPS = Text(multi=True)
    TU = Text(multi=True)
    CLIENT = Text(multi=True)


class CriteriaArtifact(InnerDoc):
    """file that defines the model"""

    location: Optional[str] = Text()
    type: Optional[str] = Keyword()


class Rule(InnerDoc):
    """Generator for rules"""

    offer_ids: Optional["list[str]"] = Text(multi=True)
    expression: Optional[str] = Text()
    name: Optional[str] = Text()


class Criteria(NABaseDocument):
    """Defining properties for criteria not part of BaseDocument"""

    criteria_name: Optional[str] = Keyword()
    criteria_description: Optional[str] = Text()
    criteria_code: Optional[str] = Keyword()
    client_alias: Optional[str] = Keyword()
    client_uid: Optional[str] = Keyword()
    criteria_artifacts: Optional["list[CriteriaArtifact]"] = Nested(CriteriaArtifact)
    features: Optional["list[CriteriaFeature]"] = Nested(CriteriaFeature)
    outputs: Optional["list[CriteriaOutput]"] = Nested(CriteriaOutput)
    offer_generator_version: Optional[
        OfferGeneratorVersionEnum
    ] = NAEnumOpensearchField(OfferGeneratorVersionEnum)
    version: Optional[str] = Text()
    system_datasets: Optional[SystemDatasets] = Object(SystemDatasets)
    status: Optional[CriteriaStatusEnum] = NAEnumOpensearchField(CriteriaStatusEnum)
    rules: Optional[Rule] = Nested(Rule)
    deployed_on: Optional[datetime] = NAEpochMillisDateField(format="epoch_millis")
    deployed_by: Optional[str] = Keyword()
    # datasets that the model features come from
    generic_datasets: Optional["list[str]"] = Text(multi=True)
    external_datasets: Optional["list[str]"] = Text(multi=True)
    marketing_datasets: Optional["list[str]"] = Text(multi=True)
    custom_datasets: Optional["list[str]"] = Text(multi=True)
    ops_model_datasets: Optional["list[str]"] = Text(multi=True)

    def update_from_dict(self, dictionary: dict) -> None:
        """updates criteria properties from a dictionary"""

        if "criteria_name" in dictionary:
            self.criteria_name = dictionary.get("criteria_name")

        if "status" in dictionary:
            self.status = dictionary.get("status")

        if "deployed_on" in dictionary:
            self.deployed_on = dictionary.get("deployed_on")

        if "deployed_by" in dictionary:
            self.deployed_by = dictionary.get("deployed_by")

        super().update_from_dict(dictionary)

    class Index:
        """Opensearch Index where criteria documents are stored"""

        name = ops_config.CRITERIA_INDEX_NAME
