""" Custom class for using enum in opensearch-dsl document entity"""
from enum import Enum
from opensearch_dsl import CustomField


class NAEnumOpensearchField(CustomField):
    """Custom class for serializing opensearch keyword into Enum"""

    builtin_type = "keyword"

    def __init__(self, enum_class: type[Enum], *args, **kwargs) -> None:
        """overrides constructor to save enum class used for this custom field"""
        super().__init__(*args, **kwargs)
        self._enum_class = enum_class

    def _serialize(self, data) -> Enum:
        """serialize enum into value of enum"""
        return data.value

    def _deserialize(self, data: str | Enum) -> Enum:
        """construct enum from enum value"""
        if isinstance(data, self._enum_class):
            return data
        return self._enum_class(data)
