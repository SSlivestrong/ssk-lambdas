""" configuration for a specific solution test suite """
from typing import Optional
from opensearch_dsl import Keyword

from ascendops_commonlib.entities.opensearch.na_base_document import NABaseDocument
from ascendops_commonlib.ops_utils import ops_config


class SolutionTestSuiteConfig(NABaseDocument):
    """configuration for a specific solution test suite"""

    # test suite
    name: Optional[str] = Keyword()
    # test cases in this test suite
    solution_test_case_config_uids: Optional["list[str]"] = Keyword(multi=True)

    class Index:
        """index where solution test case config documents are stored"""

        name: str = ops_config.SOLUTION_TEST_SUITE_CONFIG_INDEX_NAME
