""" Represents the type of models available to specify in client contract. """
from enum import Enum, unique


@unique
# Inherits from str as well so that enum is json serializable
class ClientContractModelTypeEnum(str, Enum):
    """represents the type of model"""

    # model files are provided to and then containerized by Ascend Ops
    INTERNAL: str = "internal"
    # black box models, here we are provided with an already containerized model
    AIS: str = "ais"
    ZEST: str = "zest"
    H2O: str = "h2o"
    DATA_ROBOT: str = "data_robot"
