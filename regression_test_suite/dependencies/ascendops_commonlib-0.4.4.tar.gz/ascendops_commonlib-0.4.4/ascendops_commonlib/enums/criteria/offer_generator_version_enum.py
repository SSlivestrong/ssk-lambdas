""" Enum to define the version of offer generator used to create a criteria """

from enum import Enum, unique


@unique
class OfferGeneratorVersionEnum(str, Enum):
    """Enum to define criteria OfferGeneratorVersion"""

    # user uploads artifacts to create criteria
    PYOG_VERSION: str = "v1.0"
    # user uses the drag and drop UI to create criteria
    SSOG_VERSION: str = "v2.0"
