""" Enum that defines the type of input datasources available for realtime execution """

from enum import Enum, unique


@unique
class ServiceNameEnum(str, Enum):
    """ service name enum """

    CRYPTO = "CRYPTO"
