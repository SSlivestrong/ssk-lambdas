""" Represents the type of Segment. """

from enum import Enum, unique


# Inherits from str as well so that enum is json serializable
@unique
class SolutionSegmentTypeEnum(str, Enum):
    """represents the Segment type of Solution"""

    SCORE: str = "score"
    ATTRIBUTE: str = "attribute"
