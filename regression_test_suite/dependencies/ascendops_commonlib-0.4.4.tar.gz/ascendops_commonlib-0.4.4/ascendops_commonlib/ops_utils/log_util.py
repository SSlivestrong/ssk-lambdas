""" log util """
import json
import traceback
import logging
from datetime import datetime
from ascendops_commonlib.ops_utils import CloudWatch_log_templates
from ascendops_commonlib.ops_utils.CloudWatch_log_templates import log_templates

log = logging.getLogger("opsapi")


class CustomLogging:

    def log_es_call_stack_trace(startup, transaction_id):
        """ log call stack trace for all ES calls """
        try:
            valid_traces = []
            for line in reversed(traceback.format_stack()[:-2]):
                valid_traces.append(line)
                if len(valid_traces) == 3:
                    break

            call_stack = []
            for trace_item in valid_traces:
                call_stack_item = CustomLogging.parse_stacktrace(trace_item)
                call_stack.append(call_stack_item)

            es_evt = log_templates.get("elasticsearch", {})
            es_evt["event_priority"] = "P1" if startup is False else None
            es_evt["transaction_id"] = transaction_id
            es_evt["file_name"] = call_stack[0]["file_name"]
            es_evt["caller_method"] = call_stack[0]["method_name"]
            es_evt["call_stack"] = call_stack
            es_evt["ltime"] = datetime.now().strftime('%M:%S.%f')[:-3]
                   
            log.warning(json.dumps(es_evt))
        except Exception as xcp:
            log.warning("Error logging call stack for ESConnector: %s", str(xcp))
        
    def parse_stacktrace(line):
        """ parse stacktrace to get file_name, caller method """
        call_stack_item_template = {
            "file_name": "",
            "method_name": "",
        }
        call_stack_item = call_stack_item_template.copy()
        call_stack_item['file_name'] = line.split(',')[0].split('"')[1].split('/').pop()
        call_stack_item['method_name'] = line.split('\n')[0].split()[-1]
        # call_stack_item['code_statement'] = line.split("\n")[1].lstrip()
        # call_stack_item['line_number'] = line.split(',')[1].strip()
        return call_stack_item


class OpsRealtimeLogger():

    def __init__(self, app_id, run_instance_id, flow_tags={}) -> None:
        self.app_id = app_id
        self.run_instance_id = run_instance_id
        self.event_message = self.get_message_template(app_id)
        self.flow_tags = flow_tags

    def get_message_template(self, app_id):
        """ returns event message template for app_id """
        return log_templates["message"].get(app_id, {})
    
    def get_log_template(self, template_type):
        return log_templates.get(template_type, {})

    def add_flow_tags(self, flow_tags):
        self.flow_tags.update(flow_tags)
