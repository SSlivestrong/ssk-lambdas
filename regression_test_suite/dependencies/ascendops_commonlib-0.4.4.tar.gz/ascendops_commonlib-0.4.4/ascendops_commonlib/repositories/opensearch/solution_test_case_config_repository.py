""" data layer to interact with test case config objects """
from ascendops_commonlib.entities.opensearch.solution_test_case_config import (
    SolutionTestCaseConfig,
)


def opensearch_get_test_case_configs_by_uids(
    uids: list[str], missing: str = "none"
) -> list[SolutionTestCaseConfig]:
    """
    retrieves test case configs by test case config uids
    missing: "raise", "skip", "none" - defines behavior when test case is missing
    """
    return SolutionTestCaseConfig.mget(uids, missing=missing)


def opensearch_get_test_case_configs(**kwargs) -> list[SolutionTestCaseConfig]:
    """Gets all test case configs or configs filterd by given parameters
    Parameters:
        alias - Optional[str]: string identifier for name of test
        test_type - Optional[SolutionTestTypeEnum]: type of tests
        include_fields - Optional[list[str]]: document fields to include in returned document
        exclude_fields - Optional[list[str]]: document fields to exclude in returned document

    Returns:
        list of test case configs
    """
    alias = kwargs.get("alias")
    test_type = kwargs.get("test_type")
    include_fields = kwargs.get("include_fields")
    exclude_fields = kwargs.get("exclude_fields")

    search = SolutionTestCaseConfig.create_search_object(
        include_fields=include_fields, exclude_fields=exclude_fields
    )

    term_queries_added = False

    if alias is not None:
        search = search.query("term", alias=alias)
        term_queries_added = True
    if test_type is not None:
        search = search.query("term", test_type=test_type)
        term_queries_added = True

    # if no term queries added, search all documents
    if not term_queries_added:
        search = search.query("match_all")

    return search.execute().hits
