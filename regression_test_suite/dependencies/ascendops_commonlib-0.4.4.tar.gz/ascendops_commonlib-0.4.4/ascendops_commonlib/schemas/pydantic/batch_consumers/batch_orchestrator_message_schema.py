""" Model that represents the message that triggers the Batch Orchestrator Consumer App"""

from typing import Optional
from pydantic import (
    model_validator,
    ValidationError,
)
from pydantic_core import InitErrorDetails, PydanticCustomError
from ascendops_commonlib.schemas.pydantic.schema_util.base_schema import (
    BaseSchema,
)
from ascendops_commonlib.schemas.pydantic.schema_util.common_types import NonEmptyString
from ascendops_commonlib.enums.batch_consumers.batch_app_name_enum import (
    BatchAppNameEnum,
)
from ascendops_commonlib.enums.batch_consumers.batch_orchestrator_message_type_enum import (
    BatchOrchestratorMessageTypeEnum,
)


class BatchOrchestratorMessageSchema(BaseSchema):
    """Model that represents the message that triggers the Batch Orchestrator Consumer App"""

    message_source: BatchAppNameEnum
    message_type: BatchOrchestratorMessageTypeEnum
    go_campaign_id: NonEmptyString
    ops_exec_chain_id: NonEmptyString
    model_uid: Optional[NonEmptyString] = None
    go_model_exec_id: Optional[NonEmptyString] = None

    @model_validator(mode="after")
    def validate_by_message_type(self):
        """validates entire model by message type"""

        # validate that the optional fields are present for EXEC END message. These fields are needed for this
        # type of message
        validation_errors = []
        if self.message_type == BatchOrchestratorMessageTypeEnum.EXEC_END:
            if not self.model_uid:
                # model_uid should not be "" or None
                message = f"model_uid is required for message of type {BatchOrchestratorMessageTypeEnum.EXEC_END}"
                validation_errors.append(
                    InitErrorDetails(
                        type=PydanticCustomError("exec_end_message_error", message),
                        loc=("model_uid",),
                        input=self.model_uid,
                        ctx={},
                    )
                )
            if not self.go_model_exec_id:
                # go_model_exec_id should not be "" or None
                message = f"go_model_exec_id is required for message of type {BatchOrchestratorMessageTypeEnum.EXEC_END}"
                validation_errors.append(
                    InitErrorDetails(
                        type=PydanticCustomError("exec_end_message_error", message),
                        loc=("go_model_exec_id",),
                        input=self.go_model_exec_id,
                        ctx={},
                    )
                )

        if validation_errors:
            raise ValidationError.from_exception_data(
                title=self.__class__.__name__,
                line_errors=validation_errors,
            )
        return self
