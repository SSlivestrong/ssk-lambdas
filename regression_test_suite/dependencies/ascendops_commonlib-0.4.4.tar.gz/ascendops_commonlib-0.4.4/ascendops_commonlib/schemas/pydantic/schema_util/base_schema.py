"""Base Schema - contains schema configurations that are useful for all schemas"""

from pydantic import BaseModel, ConfigDict


class BaseSchema(BaseModel):
    """Base Schema - contains schema configurations that are useful for all pydantic schemas"""

    # customizes pydantic model behavior
    model_config = ConfigDict(
        # use enum.value when dumping model
        use_enum_values=True,
        # ignore warning that field starts with "model_". Will still throw error if conflict with pydantic BaseModel attribute
        protected_namespaces=(),
        # inputs to schema must be correctly typed
        strict=True,
        # throw error if model is instantiated with extra fields
        extra="forbid",
    )
