""" Common types to be used in a pydantic schema """

from typing_extensions import Annotated
from pydantic import StringConstraints

# useful common types
NonEmptyString = Annotated[str, StringConstraints(min_length=1)]
