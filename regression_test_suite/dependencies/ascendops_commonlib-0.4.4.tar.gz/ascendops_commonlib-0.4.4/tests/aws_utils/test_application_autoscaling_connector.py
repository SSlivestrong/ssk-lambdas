""" Unit Tests for Application Autoscaling Connector """

import unittest
from unittest.mock import MagicMock, patch
from ascendops_commonlib.aws_utils.application_autoscaling_connector import (
    ApplicationAutoscalingConnector,
)
from ascendops_commonlib.aws_utils.aws_client_util import STSClientUtil


class TestApplicationAutoscalingConnector(unittest.TestCase):
    """Unit Tests for Application Autoscaling Connector"""

    def setUp(self):
        """runs before each test"""
        # create application autoscaling connector with mocked sts client
        with patch.object(STSClientUtil, "get_client"):
            self.application_autoscaling_connector = ApplicationAutoscalingConnector()

        # set application autoscaling client to be magic mock
        self.application_autoscaling_connector.application_autoscaling_client = (
            MagicMock()
        )

    def test_init_success(self):
        """tests initializes correctly with no arguments"""
        # ARRANGE
        with patch.object(STSClientUtil, "get_client") as mock_get_client:
            # ACT
            ApplicationAutoscalingConnector()
            # ASSERT
            mock_get_client.assert_called_once_with(
                "application-autoscaling", role_arn=None
            )

    def test_init_success_with_role(self):
        """tests gets client with role if role given in constructor"""
        # ARRANGE
        role_arn = "my_role_arn"
        with patch.object(STSClientUtil, "get_client") as mock_get_client:
            # ACT
            ApplicationAutoscalingConnector(role_arn=role_arn)
            # ASSERT
            mock_get_client.assert_called_once_with(
                "application-autoscaling", role_arn=role_arn
            )

    def test_describe_scaling_policies_success(self):
        """test that describe scaling policies returns client response"""

        # ARRANGE
        service_name_space = "service_name_space"
        resource_id = "id"
        mock_client_response = {
            "ScalingPolicies": [
                {
                    "PolicyName": "my_policy",
                    "ResourceId": resource_id,
                    "ServiceNamespace": service_name_space,
                }
            ]
        }
        # set up mock to return mock client response
        self.application_autoscaling_connector.application_autoscaling_client.describe_scaling_policies = MagicMock(
            return_value=mock_client_response
        )

        # ACT
        connector_response = (
            self.application_autoscaling_connector.describe_scaling_policies(
                service_name_space, resource_id
            )
        )

        # ASSERT
        self.application_autoscaling_connector.application_autoscaling_client.describe_scaling_policies.assert_called_once_with(
            ServiceNamespace=service_name_space, ResourceId=resource_id
        )
        self.assertDictEqual(connector_response, mock_client_response)

    def test_describe_scaling_policies_exception(self):
        """test that client exception is forwarded in describe scaling policies"""

        # ARRANGE
        service_name_space = "service_name_space"
        resource_id = "id_1"

        exception_message = "describe failed"
        self.application_autoscaling_connector.application_autoscaling_client.describe_scaling_policies = MagicMock(
            side_effect=Exception(exception_message)
        )
        # ACT and ASSERT
        with self.assertRaisesRegex(Exception, exception_message):
            self.application_autoscaling_connector.describe_scaling_policies(
                service_name_space, resource_id
            )
        self.application_autoscaling_connector.application_autoscaling_client.describe_scaling_policies.assert_called_once_with(
            ServiceNamespace=service_name_space,
            ResourceId=resource_id,
        )

    def test_describe_scalable_targets_success(self):
        """test that describe_scalable_targets returns client response"""
        # ARRANGE
        service_name_space = "service_name_space"
        resource_ids = ["id_1", "id_2"]
        scalable_dimension = "instance-count"
        mock_client_response = {
            "ScalableTargets": [
                {
                    "ScalableDimension": scalable_dimension,
                    "ResourceId": resource_ids[0],
                    "ServiceNamespace": service_name_space,
                    "ScalableTargetARN": "arn_1",
                },
                {
                    "ScalableDimension": scalable_dimension,
                    "ResourceId": resource_ids[1],
                    "ServiceNamespace": service_name_space,
                    "ScalableTargetARN": "arn_2",
                },
            ]
        }
        # set up mock to return mock client response
        self.application_autoscaling_connector.application_autoscaling_client.describe_scalable_targets = MagicMock(
            return_value=mock_client_response
        )
        # ACT
        connector_response = (
            self.application_autoscaling_connector.describe_scalable_targets(
                service_name_space, resource_ids, scalable_dimension
            )
        )

        # ASSERT
        self.application_autoscaling_connector.application_autoscaling_client.describe_scalable_targets.assert_called_once_with(
            ServiceNamespace=service_name_space,
            ResourceIds=resource_ids,
            ScalableDimension=scalable_dimension,
        )
        self.assertDictEqual(connector_response, mock_client_response)

    def test_delete_scaling_policy_success(self):
        """tests delete scaling policy success case"""
        # ARRANGE
        policy_name = "policy_1"
        service_name_space = "service_name_space"
        resource_id = "id_1"
        scalable_dimension = "instance-count"

        # ACT
        self.application_autoscaling_connector.delete_scaling_policy(
            service_name_space, policy_name, resource_id, scalable_dimension
        )
        # ASSERT
        self.application_autoscaling_connector.application_autoscaling_client.delete_scaling_policy.assert_called_once_with(
            ServiceNamespace=service_name_space,
            PolicyName=policy_name,
            ResourceId=resource_id,
            ScalableDimension=scalable_dimension,
        )

    def test_delete_scaling_policy_exception(self):
        """tests client exception is forwarded"""
        # ARRANGE
        policy_name = "policy_1"
        service_name_space = "service_name_space"
        resource_id = "id_1"
        scalable_dimension = "instance-count"

        exception_message = "delete failed"
        self.application_autoscaling_connector.application_autoscaling_client.delete_scaling_policy = MagicMock(
            side_effect=Exception(exception_message)
        )
        # ACT and ASSERT
        with self.assertRaisesRegex(Exception, exception_message):
            self.application_autoscaling_connector.delete_scaling_policy(
                service_name_space, policy_name, resource_id, scalable_dimension
            )
        self.application_autoscaling_connector.application_autoscaling_client.delete_scaling_policy.assert_called_once_with(
            ServiceNamespace=service_name_space,
            PolicyName=policy_name,
            ResourceId=resource_id,
            ScalableDimension=scalable_dimension,
        )

    def test_deregister_scalable_target_success(self):
        """tests success case for deregister scalable target"""
        # ARRANGE
        service_name_space = "service_name_space"
        resource_id = "id_1"
        scalable_dimension = "instance-count"

        # ACT
        self.application_autoscaling_connector.deregister_scalable_target(
            service_name_space, resource_id, scalable_dimension
        )
        # ASSERT
        self.application_autoscaling_connector.application_autoscaling_client.deregister_scalable_target.assert_called_once_with(
            ServiceNamespace=service_name_space,
            ResourceId=resource_id,
            ScalableDimension=scalable_dimension,
        )

    def test_deregister_scalable_target_exception(self):
        """tests client exception is forwarded"""

        # ARRANGE
        service_name_space = "service_name_space"
        resource_id = "id_1"
        scalable_dimension = "instance-count"

        exception_message = "deregister failed"
        self.application_autoscaling_connector.application_autoscaling_client.deregister_scalable_target = MagicMock(
            side_effect=Exception(exception_message)
        )
        # ACT and ASSERT
        with self.assertRaisesRegex(Exception, exception_message):
            self.application_autoscaling_connector.deregister_scalable_target(
                service_name_space, resource_id, scalable_dimension
            )
        self.application_autoscaling_connector.application_autoscaling_client.deregister_scalable_target.assert_called_once_with(
            ServiceNamespace=service_name_space,
            ResourceId=resource_id,
            ScalableDimension=scalable_dimension,
        )
