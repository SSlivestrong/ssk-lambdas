""" Unit Tests for Client Application Autoscaling Connector """

from unittest import TestCase, mock
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.aws_utils.client_application_autoscaling_connector import (
    ClientApplicationAutoscalingConnector,
)
from ascendops_commonlib.aws_utils.application_autoscaling_connector import (
    ApplicationAutoscalingConnector,
)


# constants for mock
AWS_ACCOUNT = "123456789"
RUNTIME_ENV = "uat"


class TestClientApplicationAutoscalingConnector(TestCase):
    """Unit Tests for Client Application Autoscaling Connector"""

    @mock.patch.object(ops_config, "AWS_ACCOUNT", AWS_ACCOUNT)
    @mock.patch.object(ops_config, "RUNTIME_ENV", RUNTIME_ENV)
    def test_init_success(self):
        """tests initializes correctly with no arguments"""
        # ARRANGE
        client_alias = "experian"
        role_arn = (
            f"arn:aws:iam::{AWS_ACCOUNT}:role/{RUNTIME_ENV}-{client_alias}-sagemaker"
        )

        with mock.patch.object(
            ApplicationAutoscalingConnector, "__init__"
        ) as mock_application_autoscaling_init:
            # ACT
            ClientApplicationAutoscalingConnector("experian")
            # ASSERT
            mock_application_autoscaling_init.assert_called_once_with(role_arn=role_arn)
