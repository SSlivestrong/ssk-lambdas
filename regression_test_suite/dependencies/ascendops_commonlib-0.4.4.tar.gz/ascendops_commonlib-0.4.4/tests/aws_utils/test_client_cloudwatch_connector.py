""" Unit Tests for Client Cloudwatch Connector """

from unittest import TestCase, mock
from ascendops_commonlib.ops_utils import ops_config
from ascendops_commonlib.aws_utils.client_cloudwatch_connector import (
    ClientCloudwatchConnector,
)
from ascendops_commonlib.aws_utils.cloudwatch_connector import (
    CloudwatchConnector,
)


# constants for mock
AWS_ACCOUNT = "123456789"
RUNTIME_ENV = "uat"


class TestClientCloudwatchConnector(TestCase):
    """Unit Tests for Client Cloudwatch Connector"""

    @mock.patch.object(ops_config, "AWS_ACCOUNT", AWS_ACCOUNT)
    @mock.patch.object(ops_config, "RUNTIME_ENV", RUNTIME_ENV)
    def test_init_success(self):
        """tests initializes correctly with no arguments"""
        # ARRANGE
        client_alias = "experian"
        role_arn = (
            f"arn:aws:iam::{AWS_ACCOUNT}:role/{RUNTIME_ENV}-{client_alias}-sagemaker"
        )

        with mock.patch.object(
            CloudwatchConnector, "__init__"
        ) as mock_cloud_connector_init:
            # ACT
            ClientCloudwatchConnector("experian")
            # ASSERT
            mock_cloud_connector_init.assert_called_once_with(role_arn=role_arn)
