""" Unit Tests for Cloudwatch Connector """
import unittest
from unittest.mock import patch, MagicMock
from ascendops_commonlib.aws_utils.cloudwatch_connector import CloudwatchConnector
from ascendops_commonlib.aws_utils.aws_client_util import STSClientUtil


class TestCloudwatchConnector(unittest.TestCase):
    """Unit Tests for Cloudwatch Connector"""

    def setUp(self):
        """runs before each test"""
        # create cloudwatch connector with mocked sts client
        with patch.object(STSClientUtil, "get_client"):
            self.cloudwatch_connector = CloudwatchConnector()

        # set cloudwatch client to be magic mock
        self.cloudwatch_connector.cloudwatch_client = MagicMock()

    def test_init_success(self):
        """tests successful initialization with no arguments"""
        # ARRANGE
        with patch.object(STSClientUtil, "get_client") as mock_get_client:

            # ACT
            CloudwatchConnector()
            # ASSERT
            mock_get_client.assert_called_once_with("cloudwatch", role_arn=None)

    def test_init_success_with_role(self):
        """tests successful initialization including role arn"""
        # ARRANGE
        role_arn = "my_role_arn"

        with patch.object(STSClientUtil, "get_client") as mock_get_client:

            # ACT
            CloudwatchConnector(role_arn=role_arn)
            # ASSERT
            mock_get_client.assert_called_once_with("cloudwatch", role_arn=role_arn)

    def test_describe_alarms_success(self):
        """test successful describe alarms"""
        # ARRANGE
        alarm_names = ["alarm_1", "alarm_2"]

        mock_client_response = {
            "CompositeAlarms": [{"AlarmName": "alarm_1"}],
            "MetricAlarms": [{"AlarmName": "alarm_2"}],
        }
        self.cloudwatch_connector.cloudwatch_client.describe_alarms = MagicMock(
            return_value=mock_client_response
        )

        # ACT
        connector_response = self.cloudwatch_connector.describe_alarms(alarm_names)
        # ASSERT
        self.cloudwatch_connector.cloudwatch_client.describe_alarms.assert_called_once_with(
            AlarmNames=alarm_names
        )
        self.assertDictEqual(connector_response, mock_client_response)

    def test_describe_alarms_exception(self):
        """tests cloudwatch client exception is forwarded"""
        # ARRANGE
        alarm_names = ["alarm_1", "alarm_2"]
        exception_message = "describe failed"
        self.cloudwatch_connector.cloudwatch_client.describe_alarms = MagicMock(
            side_effect=Exception(exception_message)
        )
        # ACT and ASSERT
        with self.assertRaisesRegex(Exception, exception_message):
            self.cloudwatch_connector.describe_alarms(alarm_names)
        self.cloudwatch_connector.cloudwatch_client.describe_alarms.assert_called_once_with(
            AlarmNames=alarm_names
        )

    def test_delete_alarms_success(self):
        """test successful delete alarms"""
        # ARRANGE
        alarm_names = ["alarm_1", "alarm_2"]
        # ACT
        self.cloudwatch_connector.delete_alarms(alarm_names)
        # ASSERT
        self.cloudwatch_connector.cloudwatch_client.delete_alarms.assert_called_once_with(
            AlarmNames=alarm_names
        )

    def test_delete_alarms_exception(self):
        """tests cloudwatch client exception is forwarded"""
        # ARRANGE
        alarm_names = ["alarm_1", "alarm_2"]
        exception_message = "delete failed"
        self.cloudwatch_connector.cloudwatch_client.delete_alarms = MagicMock(
            side_effect=Exception(exception_message)
        )
        # ACT and ASSERT
        with self.assertRaisesRegex(Exception, exception_message):
            self.cloudwatch_connector.delete_alarms(alarm_names)
        self.cloudwatch_connector.cloudwatch_client.delete_alarms.assert_called_once_with(
            AlarmNames=alarm_names
        )
