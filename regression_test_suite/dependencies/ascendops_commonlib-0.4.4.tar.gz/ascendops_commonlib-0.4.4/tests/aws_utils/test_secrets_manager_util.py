"""
This module contains unit tests for the 'secrets_manager.py' module.

The TestSecretsManagerUtil class contains the tests for the 'SecretsManagerUtil' class. 
It tests the 'get_secret' method to ensure it correctly retrievs secrets from AWS Secret Manager.

Usage:
    Run this file directly to run all the tests:
    $ python test_secrets_manager.py

    Since this module is created under the tests folder, pytest will execute all the test classes as a part of unit tests run.

Classes:
    TestSecretsManagerUtil: unit tests for the SecretsManagerUtil class.
"""

import unittest
from unittest.mock import MagicMock
from ascendops_commonlib.aws_utils.secrets_manager_util import SecretsManagerUtil

class TestSecretsManagerUtil(unittest.TestCase):
    """
    TestSecretsManagerUtil class
    """

    def setUp(self):
        """
        initialize client and setup
        """
        self.region = "us-east-1"
        self.secret_name = "pytest_secret"

        self.secrets_manager_util = SecretsManagerUtil(self.region)
        self.secrets_manager_util.client = MagicMock()

    def test_get_secret_success(self):
        """
        mock the behavior of boto3 secretsmanager client
        """
        secret_value = { 'SecretString': '{ "credentials": "cred-val-123" }'}
        self.secrets_manager_util.client.get_secret_value.return_value = secret_value

        expected_secret = { "credentials": "cred-val-123" }
        actual_secret = self.secrets_manager_util.get_secret(self.secret_name)
        self.assertEqual(expected_secret, actual_secret)

        # self.secrets_manager_util.client.get_secret_value.return_value = { 'SecretString': '{ "credentials": "cred-val-123" }'}

        # secret = self.secrets_manager_util.get_secret(self.secret_name)
        # self.secrets_manager_util.client.get_secret_value.assert_called_with(SecretId=self.secret_name)
        # self.assertEqual(secret, { "credentials": "cred-val-123" })

    def test_get_secret_none(self):
        """
        mock none response from get_secret method
        """
        secret_value = { "something": "random" }
        self.secrets_manager_util.client.get_secret_value.side_effect = secret_value

        # expected_secret = None
        actual_secret = self.secrets_manager_util.get_secret(self.secret_name + "A1")
        self.assertIsNone(actual_secret)
        # secret = self.secrets_manager_util.get_secret(self.secret_name)
        # self.secrets_manager_util.client.get_secret_value.assert_called_with(SecretId=self.secret_name)
        # self.assertIsNone(secret)

    def test_get_secret_error(self):
        """
        mock exception error
        """
        self.secrets_manager_util.client.get_secret_value.side_effect = Exception("Error")

        with self.assertRaises(Exception) as context:
            self.secrets_manager_util.get_secret(self.secret_name)

        self.assertTrue("Error" in str(context.exception))
