""" Unit Tests for SNS Connector """
import unittest
from unittest.mock import MagicMock, patch
from ascendops_commonlib.aws_utils.sns_connector import (
    SNSConnector,
    SNSConnectorException,
)
from ascendops_commonlib.aws_utils.aws_client_util import STSClientUtil


class TestSNSConnector(unittest.TestCase):
    """Unit Tests for SNS Connector"""

    def setUp(self):
        """runs before each test"""
        # create sns connector with mocked sts client
        topic_arn = "arn:aws:sns:us-west-2:123456789012:MyTopic"
        with patch.object(STSClientUtil, "get_client"):
            self.sns_connector = SNSConnector(topic_arn)

        # set sns client to be magic mock
        self.sns_connector.sns_client = MagicMock()

    def test_init_success(self):
        """tests successful initialization with only topic arn"""
        # ARRANGE
        topic_name = "MyTopic"
        topic_arn = "arn:aws:sns:us-west-2:123456789012:MyTopic"

        with patch.object(STSClientUtil, "get_client") as mock_get_client:

            # ACT
            sns_connector = SNSConnector(topic_arn)
            # ASSERT
            self.assertEqual(sns_connector.topic_arn, topic_arn)
            self.assertEqual(sns_connector.topic_name, topic_name)

            mock_get_client.assert_called_once_with("sns", role_arn=None)

    def test_init_success_with_role(self):
        """tests successful initialization including role arn"""
        # ARRANGE
        topic_name = "MyTopic"
        topic_arn = "arn:aws:sns:us-west-2:123456789012:MyTopic"
        role_arn = "my_role_arn"

        with patch.object(STSClientUtil, "get_client") as mock_get_client:

            # ACT
            sns_connector = SNSConnector(topic_arn, role_arn=role_arn)
            # ASSERT
            self.assertEqual(sns_connector.topic_arn, topic_arn)
            self.assertEqual(sns_connector.topic_name, topic_name)

            mock_get_client.assert_called_once_with("sns", role_arn=role_arn)

    def test_init_null_topic_arn(self):
        """tests constructing with null topic arn throws expected exception"""
        # ARRANGE
        with patch.object(STSClientUtil, "get_client"):
            # ACT and ASSERT
            with self.assertRaisesRegex(
                SNSConnectorException, "SNS Connector - topic arn cannot be null"
            ):
                SNSConnector(None)

    def test_init_invalid_topic_arn(self):
        """tests constructiong with invalid topic arn throws expected exception"""
        # ARRANGE
        with patch.object(STSClientUtil, "get_client"):
            # ACT ASSERT
            with self.assertRaisesRegex(
                SNSConnectorException, "SNS Connector - Invalid topic arn: MyTopic"
            ):
                SNSConnector("MyTopic")

    def test_publish_message_success(self):
        """tests successful publish message"""

        # ARRANGE
        message = "test message"
        message_attributes = {"key": {"DataType": "String", "StringValue": "value"}}
        # ACT
        self.sns_connector.publish_message(message, message_attributes)

        # ASSERT
        self.sns_connector.sns_client.publish.assert_called_once_with(
            TopicArn=self.sns_connector.topic_arn,
            Message=message,
            MessageAttributes=message_attributes,
        )

    def test_publish_message_sns_client_exception(self):
        """tests sns client exception is forwarded"""

        # ARRANGE
        message = "test message"
        message_attributes = {"key": {"DataType": "String", "StringValue": "value"}}

        exception_msg = "publish failed"
        self.sns_connector.sns_client.publish = MagicMock(
            side_effect=Exception(exception_msg)
        )

        # ACT and ASSERT
        with self.assertRaisesRegex(Exception, exception_msg):
            self.sns_connector.publish_message(message, message_attributes)

        self.sns_connector.sns_client.publish.assert_called_once_with(
            TopicArn=self.sns_connector.topic_arn,
            Message=message,
            MessageAttributes=message_attributes,
        )
