"""
mock test module for es_util
"""

import unittest
from unittest.mock import patch, Mock
from ascendops_commonlib.datastores.es_util import ESConnector
from elasticsearch.exceptions import NotFoundError, RequestError


class TestESConnector(unittest.TestCase):
    """ test class for ESConnector module """

    @patch("ascendops_commonlib.datastores.es_util.boto3.Session")
    @patch("ascendops_commonlib.datastores.es_util.Elasticsearch")
    def setUp(self, mock_elasticsearch_class, mock_session_class):
        """ setup method for es client """
        mock_sts_client = Mock()
        mock_sts_client.assume_role.return_value = {
            "Credentials": {
                "AccessKeyId": "mock_access_key",
                "SecretAccessKey": "mock_secret_key",
                "SessionToken": "mock_token"
            }
        }

        mock_session = mock_session_class.return_value
        mock_session.client.return_value = mock_sts_client

        self.mock_esearch_instance = mock_elasticsearch_class.return_value
        self.es_conn = ESConnector()

    @patch("ascendops_commonlib.datastores.es_util.boto3.Session")
    @patch("ascendops_commonlib.datastores.es_util.AWS4Auth")
    @patch("ascendops_commonlib.datastores.es_util.Elasticsearch")
    def test_init(self, mock_elasticsearch, mock_aws4auth,  mock_session):
        """ test init method """

        mock_session_instance = mock_session.return_value
        mock_sts_client = Mock()
        mock_session_instance.client.return_value = mock_sts_client
        mock_sts_client.assume_role.return_value = {
            "Credentials": {
                "AccessKeyId": "mock_access_key",
                "SecretAccessKey": "mock_secret_key",
                "SessionToken": "mock_token"
            }
        }

        mock_aws4auth.return_value = "mocked_aws_auth"

        mock_elasticsearch_instance = mock_elasticsearch.return_value

        es_conn = ESConnector()
        self.assertIsNotNone(es_conn)
        self.assertEqual(es_conn.esearch, mock_elasticsearch_instance)

        mock_session.assert_called_once_with(region_name="us-east-1")
        mock_session_instance.client.assert_called_once_with("sts", endpoint_url="https://sts.us-east-1.amazonaws.com")
        mock_sts_client.assume_role.assert_called_once_with(
            RoleArn="arn:aws:iam::994075455914:role/dev-es-role",
            RoleSessionName="BatchSession1"
        )
        mock_aws4auth.assert_called_once_with(
            "mock_access_key", "mock_secret_key", "us-east-1", "es", session_token="mock_token"
        )
        mock_elasticsearch.assert_called_once()

        # create another instance of es_conn with profile name for test coverage
        es_conn = ESConnector(profile="test")
        self.assertIsNotNone(es_conn)

    def test_get_es_info(self):
        """ test get_es_info method """
        self.mock_esearch_instance.info.return_value = {
            "name": "9a6e291a38271e39c8f0e4f327d2f01b",
            "cluster_name": "262403030294:uat-ascend-go",
            "cluster_uuid": "sOeiiRpFTpiYCioWuUoW_w",
            "version": {
                "number": "7.10.2",
                "build_flavor": "oss",
                "build_type": "tar",
                "build_hash": "unknown",
                "build_date": "2023-01-10T07:34:26.861201Z",
                "build_snapshot": False,
                "lucene_version": "8.7.0",
                "minimum_wire_compatibility_version": "6.8.0",
                "minimum_index_compatibility_version": "6.0.0-beta1"
            },
            "tagline": "You Know, for Search"
        }
        response = self.es_conn.get_es_info()
        self.assertEqual(response, {
            "name": "9a6e291a38271e39c8f0e4f327d2f01b",
            "cluster_name": "262403030294:uat-ascend-go",
            "cluster_uuid": "sOeiiRpFTpiYCioWuUoW_w",
            "version": {
                "number": "7.10.2",
                "build_flavor": "oss",
                "build_type": "tar",
                "build_hash": "unknown",
                "build_date": "2023-01-10T07:34:26.861201Z",
                "build_snapshot": False,
                "lucene_version": "8.7.0",
                "minimum_wire_compatibility_version": "6.8.0",
                "minimum_index_compatibility_version": "6.0.0-beta1"
            },
            "tagline": "You Know, for Search"
        })


    def test_inspect_indices(self):
        """ test for inspect_indices method """
        mocked_response = {
            "client": {
                "aliases": {}
            },
            "dataset": {
                "aliases": {}
            },
            "feature": {
                "aliases": {}
            },
            "model": {
                "aliases": {}
            }
        }
        self.mock_esearch_instance.indices.get_alias.return_value = mocked_response
        response = self.es_conn.inspect_indices()
        self.assertEqual(response, mocked_response)


    def test_get_document(self):
        """ test get_document method """
        self.mock_esearch_instance.get.return_value = {
            "_index": "client",
            "_type": "_doc",
            "_id": "experian",
            "_version": 21,
            "_seq_no": 521,
            "_primary_term": 1,
            "found": True,
            "_source": {
                "alias": "experian",
                "created_by": "System Admin",
                "description": "Internal client for testing",
                "name": "experian",
                "uid": "experian",
                "created_on": 1648224520960,
                "boost_optout": False,
                "products": [
                    "credit_card",
                    "auto",
                    "mortgage",
                    "home_equity",
                    "personal_lending",
                    "small_business"
                ],
                "partners": [
                    "banking_affiliate_1",
                    "banking_affiliate_2",
                    "co_brand_1",
                    "co_brand_2"
                ],
                "purposes": [
                    "underwriting",
                    "marketing",
                    "account_management"
                ],
                "sub_purposes": [
                    "pre_screen",
                    "ITA",
                    "line_assignment"
                ],
                "default_tags": [
                    "Marketing"
                ],
                "updated_by": "System Admin",
                "updated_on": 1691466225302,
                "has_access_to_marketing_datasets": False,
                "restrict_100_population_campaign": False,
                "restrict_1_population_campaign": False,
                "persist_model_artifacts": True,
                "assign_model_code": False,
                "promotion_requires_deployed": False,
                "promotion_requires_latency_test": False,
                "model_code_length": "six_bytes",
                "reuse_model_code_between_versions": False,
                "enable_load_to_marketing_audience_engine": False,
                "allow_realtime_model_exemption_from_latency_req": False,
                "daily_1_population_run_limit": 5,
                "is_sandbox_client": False
            }
        }
        response = self.es_conn.get_document("test_index", "test_doc_id", ["include_field"], ["exclude_field"])
        self.assertEqual(response, {

            "_index": "client",
            "_type": "_doc",
            "_id": "experian",
            "_version": 21,
            "_seq_no": 521,
            "_primary_term": 1,
            "found": True,
            "_source": {
                "alias": "experian",
                "created_by": "System Admin",
                "description": "Internal client for testing",
                "name": "experian",
                "uid": "experian",
                "created_on": 1648224520960,
                "boost_optout": False,
                "products": [
                    "credit_card",
                    "auto",
                    "mortgage",
                    "home_equity",
                    "personal_lending",
                    "small_business"
                ],
                "partners": [
                    "banking_affiliate_1",
                    "banking_affiliate_2",
                    "co_brand_1",
                    "co_brand_2"
                ],
                "purposes": [
                    "underwriting",
                    "marketing",
                    "account_management"
                ],
                "sub_purposes": [
                    "pre_screen",
                    "ITA",
                    "line_assignment"
                ],
                "default_tags": [
                    "Marketing"
                ],
                "updated_by": "System Admin",
                "updated_on": 1691466225302,
                "has_access_to_marketing_datasets": False,
                "restrict_100_population_campaign": False,
                "restrict_1_population_campaign": False,
                "persist_model_artifacts": True,
                "assign_model_code": False,
                "promotion_requires_deployed": False,
                "promotion_requires_latency_test": False,
                "model_code_length": "six_bytes",
                "reuse_model_code_between_versions": False,
                "enable_load_to_marketing_audience_engine": False,
                "allow_realtime_model_exemption_from_latency_req": False,
                "daily_1_population_run_limit": 5,
                "is_sandbox_client": False
            }
        })
        # mocking for response when no include exclude field provided
        mock_response_wo_fields = {'_index': 'test_dataset', '_type': '_doc', '_id': 'premier_1_3', '_version': 11, '_seq_no': 1922, '_primary_term': 2, 'found': True, 
                                   '_source': {'name': 'premier_1_3', 'alias': 'premier_1_3', 'description': None, 
                                               'is_on_platform': ['ascend'], 'created_by': 'admin', 'type': 'generic', 'uid': 'premier_1_3', 'dataset_code': 'A3', 'created_on': 1649352733912, 'dataset_category': 'attribute', 'display_name': 'Premier 1.3', 'updated_on': 1666255306101, 
                                               'updated_by': 'admin', 'online_store': {'system': 'EXP'}}}
        self.mock_esearch_instance.get.return_value = mock_response_wo_fields
        response_wo_fields = self.es_conn.get_document(index_name='test_dataset', doc_id='premier_1_3')
        self.assertEqual(response_wo_fields, mock_response_wo_fields)

    def test_index_document(self):
        """
        test for method index_document"""

        mock_response = {'_index': 'test_index', '_type': '_doc', '_id': '5', '_version': 2, 'result': 'updated', '_shards': {'total': 2, 'successful': 
                        2, 'failed': 0}, '_seq_no': 2, '_primary_term': 1}
        mock_document = {"name": "premier_index_test"}

        self.mock_esearch_instance.index.return_value = mock_response
        response = self.es_conn.index_document(index_name='test_index', doc_id='1', doc_content=mock_document)
        self.assertEqual(response, mock_response)


    def test_index_exists(self):
        # test index_exists method
        # tests for possible return: bool
        self.mock_esearch_instance.indices.exists.return_value = True
        self.assertTrue(self.es_conn.index_exists(index_name_list='dataset'))

        self.mock_esearch_instance.indices.exists.return_value = False
        self.assertFalse(self.es_conn.index_exists(index_name_list='dataset'))

    def test_delete_index(self):
        """test delete_index method
        tests for two possible returns: bool | any
           If the index does not exist, ES throws NotFoundError:
            status_code: 404,
            error: 'index_not_found_exception
            info: {error dictionary will have the details}
        """
        self.mock_esearch_instance.indices.delete.return_value=True
        response_bool = self.es_conn.delete_index(index_name_list='test_index')
        self.assertTrue(response_bool)

        # test exception for index not found
        self.mock_esearch_instance.indices.delete.side_effect = NotFoundError(404, 'index_not_found_exception', {'error': {'root_cause': [{'type': 'index_not_found_exception', 'reason': 'no such index [modell_dev_oops]', 'index_uuid': '_na_', 'resource.type': 'index_or_alias', 'resource.id': 'modell_dev_oops', 'index': 'modell_dev_oops'}], 'type': 'index_not_found_exception', 'reason': 'no such index [modell_dev_oops]', 'index_uuid': '_na_', 'resource.type': 'index_or_alias', 'resource.id': 'test_index', 'index': 'test_index'}, 'status': 404})
        response_error = self.es_conn.delete_index(index_name_list='test_index')
        self.assertEqual(response_error,{'reason': 'no such index [modell_dev_oops]', 'error': 'index_not_found_exception', 'status_code': 404})
       
    def test_get_index_mapping(self):
        mocked_reponse = {"test_dataset": 
                            {"mappings": 
                                {"dynamic": "false", "properties": 
                                    {"aggregation_info": 
                                    {"properties": 
                                    {"input_files_location": {"type": "keyword"}, 
                                    "input_schema_file": {"type": "keyword"}, 
                                    "output_files_location": {"type": "keyword"}}}, 
                                    "alias": {"type": "keyword"}, 
                                    "client_alias": {"type": "keyword"}, 
                                    "created_by": {"type": "keyword"}, 
                                    "created_on": {"type": "date", "format": "epoch_millis"}, 
                                    "dataset_category": {"type": "keyword"}, 
                                    "dataset_code": {"type": "keyword"}, 
                                    "description": {"type": "text"}, 
                                    "display_name": {"type": "text"}, 
                                    "is_on_platform": {"type": "keyword"}, 
                                    "marketing_client_name": {"type": "keyword"}, 
                                    "name": {"type": "keyword"}, 
                                    "offline_store": {"properties": {"system": {"type": "keyword"}}}, 
                                    "online_store": {"properties": {"system": {"type": "keyword"}}}, 
                                    "partner_name": {"type": "keyword"}, "purpose_sub_type": {"type": "keyword"}, 
                                    "source": {"properties": {"append_tradebase_date": {"type": "boolean"}, 
                                    "append_tradebase_format": {"type": "text"}, 
                                    "compression": {"type": "text"}, 
                                    "database": {"type": "text"}, 
                                    "delimiter": {"type": "text"}, 
                                    "file_format": {"type": "text"}, "identifier_column": {"type": "text"}, 
                                    "input_identifier": {"type": "text"}, 
                                    "location": {"type": "text"}, 
                                    "secret": {"type": "text"}, 
                                    "split_key": {"type": "text"}, 
                                    "table": {"type": "text"}, 
                                    "type": {"type": "text"}}}, 
                                    "type": {"type": "keyword"}, 
                                    "uid": {"type": "keyword"}, 
                                    "updated_by": {"type": "keyword"}, 
                                    "updated_on": {"type": "date", "format": "epoch_millis"}
                                    }}}}

        self.mock_esearch_instance.indices.get_mapping.return_value = mocked_reponse
        response = self.es_conn.get_index_mapping(index_name='test_dataset')
        self.assertEqual(response, mocked_reponse)
    
    def test_create_index(self):
        """
        test method for create_index.
        Main method returns: bool | any
        if index exists, throws RequestError"""

        self.mock_esearch_instance.indices.create.return_value = True
        response_bool = self.es_conn.create_index(index_name='test_index', body_content={
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 1
            },
            "mappings": {
            }})
        self.assertTrue(response_bool)

        # test for RequestError
        self.mock_esearch_instance.indices.create.side_effect = RequestError(400, 'resource_already_exists_exception', {'error': {'root_cause': [{'type': 'resource_already_exists_exception', 'reason': 'index [test_index/3cb2H2KEQqyvggbyfHEybg] already exists', 'index_uuid': '3cb2H2KEQqyvggbyfHEybg', 'index': 'test_index'}], 'type': 'resource_already_exists_exception', 'reason': 'index [test_index/3cb2H2KEQqyvggbyfHEybg] already exists', 'index_uuid': '3cb2H2KEQqyvggbyfHEybg', 'index': 'test_index'}, 'status': 400})

        response_error = self.es_conn.create_index(index_name='test_index', body_content={"settings": {
                "number_of_shards": 1,
                "number_of_replicas": 1
            },
            "mappings": {}})

        self.assertEqual(response_error, {'target': 'test_index', 'error': 'resource_already_exists_exception', 'status_code': 400})


    def test_get_all_documents_by_scroll(self):
        """
        method to test get_all_documents_by_scroll
        used mocked scroll and search reponse
        avoid falling into infinite loop in the mocked elastic search responses"        
        """
        # mocked scroll response must be empty hits, to avoid infinite loop
        mocked_scroll_respone = {
        "_scroll_id": "DXF1ZXJ5QW5kRmV0Y2gBAAAAAAAAAD4WYm9laVYtZndUQlNsdDcwakFMNjU1QQ==",
        "took": 2,
        "timed_out": False,
        "_shards": {
            "total": 1,
            "successful": 1,
            "skipped": 0,
            "failed": 0},
        "hits": {
            "total": {
                "value": 20,
                "relation": "eq"},
            "max_score": 1.3862942,
            "hits": []
        }
        }

        mocked_search_response = {
        "_scroll_id": "test_scrollid",
        "took": 2,
        "timed_out": False,
        "_shards": {
            "total": 1,
            "successful": 1,
            "skipped": 0,
            "failed": 0},
        "hits": {
            "total": {
                "value": 20,
                "relation": "eq"},
            "max_score": 1.3862942,
            "hits": [
            {
                "_index": "my-index-000001",
                "_type" : "_doc",
                "_id": "0",
                "_score": 1.3862942,
                "_source": {
                "@timestamp": "2099-11-15T14:12:12",
                "http": {
                    "request": {
                    "method": "get"
                    },
                    "response": {
                    "status_code": 200,
                    "bytes": 1070000
                    },
                    "version": "1.1"
                },
                "source": {
                    "ip": "127.0.0.1"
                },
                "message": "test_message",
                "user": {
                    "id": "test_user"
                }
                }
            },
            {
                "_index": "my-index-000001",
                "_type" : "_doc",
                "_id": "0",
                "_score": 1.3862942,
                "_source": {
                "@timestamp": "2099-11-15T14:15:12",
                "http": {
                    "request": {
                    "method": "get"
                    },
                    "response": {
                    "status_code": 300,
                    "bytes": 1070000
                    },
                    "version": "1.1"
                },
                "source": {
                    "ip": "127.0.0.1"
                },
                "message": "test_message two",
                "user": {
                    "id": "test_user"
                }
                }
            }
            ]
        }
        }
        self.mock_esearch_instance.scroll.return_value = mocked_scroll_respone
        self.mock_esearch_instance.search.return_value = mocked_search_response

        # get reponse and compare
        response = self.es_conn.get_all_documents_by_scroll(index_name='test_dataset', query='', scroll='1s')
        mocked_assert_response = [{'_index': 'my-index-000001', '_type': '_doc', '_id': '0', '_score': 1.3862942, '_source': {'@timestamp': '2099-11-15T14:12:12', 'http': {'request': {'method': 'get'}, 'response': {'status_code': 200, 'bytes': 1070000}, 'version': '1.1'}, 'source': {'ip': '127.0.0.1'}, 'message': 'test_message', 'user': {'id': 'test_user'}}}, {'_index': 'my-index-000001', '_type': '_doc', '_id': '0', '_score': 1.3862942, '_source': {'@timestamp': '2099-11-15T14:15:12', 'http': {'request': {'method': 'get'}, 'response': {'status_code': 300, 'bytes': 1070000}, 'version': '1.1'}, 'source': {'ip': '127.0.0.1'}, 'message': 'test_message two', 'user': {'id': 'test_user'}}}]
        self.assertEqual(response, mocked_assert_response)

    def test_get_document_by_query(self):
        """test for get_document_by_query method
        tests for two possible return response: 
        1) raw result set to default, and 
        2) raw result set to True """

        mocked_response = {
        "took": 5,
        "timed_out": False,
        "_shards": {
            "total": 1,
            "successful": 1,
            "skipped": 0,
            "failed": 0},
        "hits": {
            "total": {
                "value": 20,
                "relation": "eq"},
            "max_score": 1.3862942,
            "hits": [
            {
                "_index": "my-index-000001",
                "_type" : "_doc",
                "_id": "0",
                "_score": 1.3862942,
                "_source": {
                "@timestamp": "2099-11-15T14:12:12",
                "http": {
                    "request": {
                    "method": "get"
                    },
                    "response": {
                    "status_code": 200,
                    "bytes": 1070000
                    },
                    "version": "1.1"
                },
                "source": {
                    "ip": "127.0.0.1"
                },
                "message": "test_message",
                "user": {
                    "id": "test_user"
                }
                }
            },
            {
                "_index": "my-index-000001",
                "_type" : "_doc",
                "_id": "0",
                "_score": 1.3862942,
                "_source": {
                "@timestamp": "2099-11-15T14:15:12",
                "http": {
                    "request": {
                    "method": "get"
                    },
                    "response": {
                    "status_code": 300,
                    "bytes": 1070000
                    },
                    "version": "1.1"
                },
                "source": {
                    "ip": "127.0.0.1"
                },
                "message": "test_message two",
                "user": {
                    "id": "test_user"
                }
                }
            }
            ]
        }
        }
        self.mock_esearch_instance.search.return_value = mocked_response

        # raw response is set to True
        response= self.es_conn.get_document_by_query(index_name='test_index', raw_res=True, query={"term": {"testuser.id": "test_user"}}, include_fields=['include_fields'], exclude_fields=['exclude_fields'], start=1000)
        self.assertEqual(response, mocked_response)

        # raw result set to default: False
        response_false = self.es_conn.get_document_by_query(index_name='test_index', query={"term": {"testuser.id": "test_user"}})
        self.assertEqual(response_false, mocked_response['hits']['hits'])

    def test_get_document_by_query_filter(self):
        """test for get_document_by_query_filter method
        tests for two possible return response: 
        1) raw result set to True (default), and 
        2) raw result set to False """
  
        mocked_response = {
        "took": 5,
        "timed_out": False,
        "_shards": {
            "total": 1,
            "successful": 1,
            "skipped": 0,
            "failed": 0},
        "hits": {
            "total": {
                "value": 20,
                "relation": "eq"},
            "max_score": 1.3862942,
            "hits": [
            {
                "_index": "my-index-000001",
                "_type" : "_doc",
                "_id": "0",
                "_score": 1.3862942,
                "_source": {
                "@timestamp": "2099-11-15T14:12:12",
                "http": {
                    "request": {
                    "method": "get"
                    },
                    "response": {
                    "status_code": 200,
                    "bytes": 1070000
                    },
                    "version": "1.1"
                },
                "source": {
                    "ip": "127.0.0.1"
                },
                "message": "test_message",
                "user": {
                    "id": "test_user"
                }
                }
            },
            {
                "_index": "my-index-000001",
                "_type" : "_doc",
                "_id": "0",
                "_score": 1.3862942,
                "_source": {
                "@timestamp": "2099-11-15T14:15:12",
                "http": {
                    "request": {
                    "method": "get"
                    },
                    "response": {
                    "status_code": 300,
                    "bytes": 1070000
                    },
                    "version": "1.1"
                },
                "source": {
                    "ip": "127.0.0.1"
                },
                "message": "test_message two",
                "user": {
                    "id": "test_user"
                }
                }
            }
            ]
        }
        }

        # set mock returns
        self.mock_esearch_instance.search.return_value = mocked_response
        mock_query = {'query': {'term': {'name': 'sbcs_data'}}}

        # assert raw response
        response_raw = self.es_conn.get_document_by_query_filter(index_name='test_dataset', raw_res=True, query=mock_query, include_fields=['include_fields'], exclude_fields=['exclude_fields'], start=1000, filter_spec=['test_filter_spec'])
        self.assertEqual(response_raw, mocked_response)

        #assert default response
        response_default = self.es_conn.get_document_by_query_filter(index_name='test_dataset', raw_res=False, query=mock_query)
        self.assertEqual(response_default, mocked_response["hits"]["hits"])

    
    def test_delete_documents_by_query(self):
        """
        method to test delete_documents_by_query.
        uses mock query values, 
        main method returns a dict"""

        # set mock values
        mock_query = {'query': {'term': {'name': 'sbcs_data'}}}
        mocked_response = {
                'took': 580, 'timed_out': False, 'total': 0, 'deleted': 0, 'batches': 0, 
                'version_conflicts': 0, 'noops': 0, 'retries': {'bulk': 0, 'search': 0}, 
                'throttled_millis': 0, 'requests_per_second': -1.0, 'throttled_until_millis': 0, 
                'failures': []}

        self.mock_esearch_instance.delete_by_query.return_value = mocked_response
        response = self.es_conn.delete_documents_by_query(index_name='test_dataset', query=mock_query)
        self.assertEqual(response, mocked_response)
    

    def test_create_document(self):
        """
        method to test create_document
        main method returns a dict
        """
        # set mocked values
        mock_doc ={"name": "premier_1_3_test"}
        mock_response = {'_index': 'test_model', '_type': '_doc', '_id': '1', '_version': 1, 'result': 'created', '_shards': {'total': 2, 'successful': 2, 'failed': 0}, '_seq_no': 0, '_primary_term': 1}
        self.mock_esearch_instance.create.return_value = mock_response

        response = self.es_conn.create_document(index_name='test_index', doc_id='1', doc_content=mock_doc)
        self.assertEqual(response, mock_response)
  

    def test_update_document(self):
        """
        method to test update_document, 
        main method return a dict"""
        
        # set mock values
        mock_response = {'_index': 'test_index', '_type': '_doc', '_id': '1', '_version': 2, 'result': 'updated', '_shards': {'total': 2, 'successful': 2, 'failed': 0}, '_seq_no': 1, '_primary_term': 1}
        mock_updated_document = {"doc": {"name": "updated_name"}}        
        self.mock_esearch_instance.update.return_value = mock_response

        response = self.es_conn.update_document(index_name='test_index', doc_id='1', doc_content=mock_updated_document)
        self.assertEqual(response, mock_response)

    def test_upsert_document(self):
        """
        test method for upsert_document"""

        # set mock values
        mock_response = {'_index': 'model_dev_ops', '_type': '_doc', '_id': '1', '_version': 3, 'result': 'updated', '_shards': {'total': 2, 'successful': 2, 'failed': 0}, '_seq_no': 2, '_primary_term': 1}
        mock_upsert_document = {"doc": {"name": "test_name"}}
        self.mock_esearch_instance.update.return_value = mock_response

        response = self.es_conn.upsert_document(index_name='test_index', doc_id='1', doc_content=mock_upsert_document)
        self.assertEqual(response, mock_response)

    def test_delete_document(self):
        """method to test delete_document().
        Delete document by document id, main method returns a dictionary"""

        # set mock values 
        mock_response = {'_index': 'test_index', '_type': '_doc', '_id': '1', '_version': 4, 
                         'result': 'deleted', 
                         '_shards': {'total': 2, 'successful': 2, 'failed': 0}, 
                         '_seq_no': 3, '_primary_term': 1}
        self.mock_esearch_instance.delete.return_value = mock_response
        response = self.es_conn.delete_document(index_name='test_index', doc_id='1')

        self.assertEqual(response, mock_response)

    @patch("ascendops_commonlib.datastores.es_util.helpers")
    def test_bulk_import(self, mock_helpers):
        """
        test for bulk_import method
        using mocked:
        - action: (list of objects aka documents to be imported)
        - index
        - main method returns a tuple with pass and fails: (pass, fail)

        """
        # set mock values for list of objects (list of documents to be imported)
        mock_action = [{'_index': 'test_index', '_type': '_doc', '_id': '5', '_score': 1.0, '_source': {'name': 'premier_1_4_test'}}, 
                       {'_index': 'test_index', '_type': '_doc', '_id': '4', '_score': 1.0, '_source': {'name': 'premier_1_5_test'}}]
        mock_response = (2, [])
        # assign mock values for bulk
        mock_helpers.bulk.return_value = mock_response

        response = self.es_conn.bulk_import(objects_list=mock_action, index='test_index', doc_type='test_index')
        self.assertEqual(response, mock_response)


    def test_put_mapping(self):
        """
        test for put_mapping method, main method returns a dictionary response
        """
        mock_response = {'acknowledged': True}
        mock_map = {
                   "properties": {
                        "city": {
                        "type": "text",
                        "fields": {
                            "raw": {
                            "type": "keyword"
                            }
                        }
                        }
                         }
                    }

        self.mock_esearch_instance.indices.put_mapping.return_value = mock_response
        response = self.es_conn.put_mapping(index_name='test_index', mapping_content=mock_map)
        self.assertEqual(response, mock_response)






