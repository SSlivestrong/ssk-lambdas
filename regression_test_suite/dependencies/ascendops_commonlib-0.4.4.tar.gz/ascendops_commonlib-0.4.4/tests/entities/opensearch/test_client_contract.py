""" Unit tests for ClientContract entity """
from datetime import datetime
import unittest

from ascendops_commonlib.entities.opensearch.client_contract import ClientContract
from ascendops_commonlib.enums.client_contract.model_execution_type_enum import (
    ModelExecutionTypeModeEnum,
)
from ascendops_commonlib.enums.client_contract.client_contract_model_type_enum import (
    ClientContractModelTypeEnum,
)


class TestClientContract(unittest.TestCase):
    """Unit tests for Client Contract"""

    def setUp(self) -> None:
        """Creates client contract object populated with fields before each test"""
        self.client_contract = ClientContract()

        self.original_client_uid = "janedoenterprise"
        self.original_client_name = "Jane Doe Enterprise"
        self.original_email = "janedoe@gmail.com"
        self.original_phone_number = "(512)332-1231"
        self.original_name = "contract1"
        self.original_execution_type = ModelExecutionTypeModeEnum.BATCH
        self.original_model_type = ClientContractModelTypeEnum.AIS
        self.original_contract_start_date = datetime(year=2024, month=1, day=1)
        self.original_contract_end_date = datetime(year=2025, month=1, day=1)
        self.original_max_model_count = 5

        self.client_contract.client_uid = self.original_client_uid
        self.client_contract.client_name = self.original_client_name
        self.client_contract.email = self.original_email
        self.client_contract.phone_number = self.original_phone_number
        self.client_contract.name = self.original_name
        self.client_contract.execution_type = self.original_execution_type
        self.client_contract.model_type = self.original_model_type
        self.client_contract.contract_start_date = self.original_contract_start_date
        self.client_contract.contract_end_date = self.original_contract_end_date
        self.client_contract.max_model_count = self.original_max_model_count

    def test_update_from_dict_full_payload(self):
        """Test update from dict with all editable fields"""

        # ARRANGE
        # set update fields
        updated_name = "clientcontract2"
        updated_email = "mycompany2@gmail.com"
        updated_phone_number = "(714)321-2311"
        updated_execution_type = ModelExecutionTypeModeEnum.REALTIME_AND_BATCH
        updated_model_type = ClientContractModelTypeEnum.DATA_ROBOT
        updated_contract_start_date = datetime(year=2025, month=6, day=1)
        updated_contract_end_date = datetime(year=2026, month=6, day=1)
        updated_max_model_count = 10

        # ACT
        self.client_contract.update_from_dict(
            {
                "name": updated_name,
                "email": updated_email,
                "phone_number": updated_phone_number,
                "execution_type": updated_execution_type,
                "model_type": updated_model_type,
                "contract_start_date": updated_contract_start_date,
                "contract_end_date": updated_contract_end_date,
                "max_model_count": updated_max_model_count,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(self.client_contract.client_uid, self.original_client_uid)
        self.assertEqual(self.client_contract.client_name, self.original_client_name)

        # these fields should be updated
        self.assertEqual(self.client_contract.name, updated_name)
        self.assertEqual(self.client_contract.email, updated_email)
        self.assertEqual(self.client_contract.phone_number, updated_phone_number)
        self.assertEqual(self.client_contract.execution_type, updated_execution_type)
        self.assertEqual(self.client_contract.model_type, updated_model_type)
        self.assertEqual(
            self.client_contract.contract_start_date, updated_contract_start_date
        )
        self.assertEqual(
            self.client_contract.contract_end_date, updated_contract_end_date
        )
        self.assertEqual(self.client_contract.max_model_count, updated_max_model_count)

    def test_update_from_dict_payload_with_nulls(self) -> None:
        """Test update from dict updates fields with null if given in payload"""

        # ARRANGE
        # set update fields
        updated_name = None
        updated_email = None
        updated_phone_number = None
        updated_execution_type = None
        updated_model_type = None
        updated_contract_start_date = None
        updated_contract_end_date = None
        updated_max_model_count = None

        # ACT
        self.client_contract.update_from_dict(
            {
                "name": updated_name,
                "email": updated_email,
                "phone_number": updated_phone_number,
                "execution_type": updated_execution_type,
                "model_type": updated_model_type,
                "contract_start_date": updated_contract_start_date,
                "contract_end_date": updated_contract_end_date,
                "max_model_count": updated_max_model_count,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(self.client_contract.client_uid, self.original_client_uid)
        self.assertEqual(self.client_contract.client_name, self.original_client_name)

        # these fields should be updated
        self.assertEqual(self.client_contract.name, updated_name)
        self.assertEqual(self.client_contract.email, updated_email)
        self.assertEqual(self.client_contract.phone_number, updated_phone_number)
        self.assertEqual(self.client_contract.execution_type, updated_execution_type)
        self.assertEqual(self.client_contract.model_type, updated_model_type)
        self.assertEqual(
            self.client_contract.contract_start_date, updated_contract_start_date
        )
        self.assertEqual(
            self.client_contract.contract_end_date, updated_contract_end_date
        )
        self.assertEqual(self.client_contract.max_model_count, updated_max_model_count)

    def test_update_from_dict_partial_payload(self) -> None:
        """Tests that only fields included in dict update in datasource"""

        # ARRANGE
        # set update fields
        updated_email = "mycompany2@gmail.com"
        updated_phone_number = "(714)321-2311"
        updated_execution_type = ModelExecutionTypeModeEnum.REALTIME_AND_BATCH
        updated_model_type = ClientContractModelTypeEnum.DATA_ROBOT
        updated_contract_start_date = datetime(year=2025, month=6, day=1)
        updated_contract_end_date = datetime(year=2026, month=6, day=1)
        updated_max_model_count = 10

        # ACT
        self.client_contract.update_from_dict(
            {
                "email": updated_email,
                "phone_number": updated_phone_number,
                "execution_type": updated_execution_type,
                "model_type": updated_model_type,
                "contract_start_date": updated_contract_start_date,
                "contract_end_date": updated_contract_end_date,
                "max_model_count": updated_max_model_count,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(self.client_contract.client_uid, self.original_client_uid)
        self.assertEqual(self.client_contract.client_name, self.original_client_name)
        self.assertEqual(self.client_contract.name, self.original_name)

        # these fields should be updated
        self.assertEqual(self.client_contract.email, updated_email)
        self.assertEqual(self.client_contract.phone_number, updated_phone_number)
        self.assertEqual(self.client_contract.execution_type, updated_execution_type)
        self.assertEqual(self.client_contract.model_type, updated_model_type)
        self.assertEqual(
            self.client_contract.contract_start_date, updated_contract_start_date
        )
        self.assertEqual(
            self.client_contract.contract_end_date, updated_contract_end_date
        )
        self.assertEqual(self.client_contract.max_model_count, updated_max_model_count)

    def test_update_from_dict_payload_uneditable_field(self) -> None:
        """Verify that update does not update uneditable fields within datasource"""

        # ARRANGE
        # set update fields
        updated_client_name = "new_client"
        updated_name = "clientcontract2"
        updated_email = "mycompany2@gmail.com"
        updated_phone_number = "(714)321-2311"
        updated_execution_type = ModelExecutionTypeModeEnum.REALTIME_AND_BATCH
        updated_model_type = ClientContractModelTypeEnum.DATA_ROBOT
        updated_contract_start_date = datetime(year=2025, month=6, day=1)
        updated_contract_end_date = datetime(year=2026, month=6, day=1)
        updated_max_model_count = 10

        # ACT
        self.client_contract.update_from_dict(
            {
                "client_name": updated_client_name,
                "name": updated_name,
                "email": updated_email,
                "phone_number": updated_phone_number,
                "execution_type": updated_execution_type,
                "model_type": updated_model_type,
                "contract_start_date": updated_contract_start_date,
                "contract_end_date": updated_contract_end_date,
                "max_model_count": updated_max_model_count,
            }
        )

        # ASSERT
        # these fields should not be updated
        self.assertEqual(self.client_contract.client_uid, self.original_client_uid)
        self.assertEqual(self.client_contract.client_name, self.original_client_name)

        # these fields should be updated
        self.assertEqual(self.client_contract.name, updated_name)
        self.assertEqual(self.client_contract.email, updated_email)
        self.assertEqual(self.client_contract.phone_number, updated_phone_number)
        self.assertEqual(self.client_contract.execution_type, updated_execution_type)
        self.assertEqual(self.client_contract.model_type, updated_model_type)
        self.assertEqual(
            self.client_contract.contract_start_date, updated_contract_start_date
        )
        self.assertEqual(
            self.client_contract.contract_end_date, updated_contract_end_date
        )
        self.assertEqual(self.client_contract.max_model_count, updated_max_model_count)
