""" Unit tests for FeatureTypeEnum """

import unittest
from ascendops_commonlib.enums.feature_type_enum import FeatureTypeEnum

class TestFeatureTypeEnum(unittest.TestCase):
    """ Unit tests for FeatureTypeEnum """

    def test_enum_values(self):
        """ Test that the enum values are correct """
        self.assertEqual(FeatureTypeEnum.GENERIC.value, "generic")
        self.assertEqual(FeatureTypeEnum.EXTERNAL.value, "external")
        self.assertEqual(FeatureTypeEnum.MARKETING.value, "marketing")
        self.assertEqual(FeatureTypeEnum.CUSTOM.value, "custom")
        self.assertEqual(FeatureTypeEnum.KEY.value, "key")
        self.assertEqual(FeatureTypeEnum.SCORE.value, "score")
        self.assertEqual(FeatureTypeEnum.AAC.value, "aac")
        self.assertEqual(FeatureTypeEnum.ATTRIBUTE.value, "attribute")
        self.assertEqual(FeatureTypeEnum.OBJECT.value, "object")

    def test_enum_members(self):
        """ Test that the enum members are correct """
        self.assertEqual(FeatureTypeEnum.GENERIC, FeatureTypeEnum["GENERIC"])
        self.assertEqual(FeatureTypeEnum.EXTERNAL, FeatureTypeEnum["EXTERNAL"])
        self.assertEqual(FeatureTypeEnum.MARKETING, FeatureTypeEnum["MARKETING"])
        self.assertEqual(FeatureTypeEnum.CUSTOM, FeatureTypeEnum["CUSTOM"])
        self.assertEqual(FeatureTypeEnum.KEY, FeatureTypeEnum["KEY"])
        self.assertEqual(FeatureTypeEnum.SCORE, FeatureTypeEnum["SCORE"])
        self.assertEqual(FeatureTypeEnum.AAC, FeatureTypeEnum["AAC"])
        self.assertEqual(FeatureTypeEnum.ATTRIBUTE, FeatureTypeEnum["ATTRIBUTE"])
        self.assertEqual(FeatureTypeEnum.OBJECT, FeatureTypeEnum["OBJECT"])
