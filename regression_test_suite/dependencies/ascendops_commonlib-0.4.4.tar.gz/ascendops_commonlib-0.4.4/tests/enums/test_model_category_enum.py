""" Unit tests for ModelCategoryEnum class """

import unittest
from ascendops_commonlib.enums.model_category_enum import ModelCategoryEnum


class TestModelCategoryEnum(unittest.TestCase):
    """ Unit tests for ModelCategoryEnum """

    def test_enum_values(self):
        """ Test that the enum values are correct """
        self.assertEqual(ModelCategoryEnum.SCORE.value, "score")
        self.assertEqual(ModelCategoryEnum.SCORE_AAC.value, "score_aac")
        self.assertEqual(ModelCategoryEnum.MULTI_SCORE.value, "multi_score")
        self.assertEqual(ModelCategoryEnum.MULTI_SCORE_AAC.value, "multi_score_aac")
        self.assertEqual(ModelCategoryEnum.ATTRIBUTE.value, "attribute")
        self.assertEqual(ModelCategoryEnum.OBJECT.value, "object")

    def test_enum_members(self):
        """ Test that the enum members are correct """
        self.assertEqual(ModelCategoryEnum.SCORE, ModelCategoryEnum["SCORE"])
        self.assertEqual(ModelCategoryEnum.SCORE_AAC, ModelCategoryEnum["SCORE_AAC"])
        self.assertEqual(ModelCategoryEnum.MULTI_SCORE, ModelCategoryEnum["MULTI_SCORE"])
        self.assertEqual(ModelCategoryEnum.MULTI_SCORE_AAC, ModelCategoryEnum["MULTI_SCORE_AAC"])
        self.assertEqual(ModelCategoryEnum.ATTRIBUTE, ModelCategoryEnum["ATTRIBUTE"])
        self.assertEqual(ModelCategoryEnum.OBJECT, ModelCategoryEnum["OBJECT"])
