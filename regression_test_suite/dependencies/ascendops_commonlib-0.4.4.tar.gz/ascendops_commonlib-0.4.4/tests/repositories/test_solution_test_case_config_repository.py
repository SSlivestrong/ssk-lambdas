""" Unit tests for solution_test_case_config_repository """
import unittest
from unittest.mock import MagicMock, patch, call

from ascendops_commonlib.repositories.opensearch import (
    solution_test_case_config_repository,
)
from ascendops_commonlib.entities.opensearch.solution_test_case_config import (
    SolutionTestCaseConfig,
)
from ascendops_commonlib.enums.solution.solution_test_type_enum import (
    SolutionTestTypeEnum,
)


class TestSolutionTestCaseConfigRepository(unittest.TestCase):
    """Unit tests for solution_test_case_config_repository"""

    def test_opensearch_get_test_case_configs_by_uids(self):
        """tests get documents by uids"""
        # ARRANGE
        expected_solutions = [SolutionTestCaseConfig(), SolutionTestCaseConfig()]
        uids = ["uid_1", "uid_2"]
        with patch.object(
            SolutionTestCaseConfig, "mget", return_value=expected_solutions
        ) as mock_mget:
            # ACT
            actual_solutions = solution_test_case_config_repository.opensearch_get_test_case_configs_by_uids(
                uids
            )
            # ASSERT
            mock_mget.assert_called_once_with(uids, missing="none")
            self.assertEqual(expected_solutions, actual_solutions)

    def test_opensearch_get_test_case_configs_all_kwargs(self):
        """tests get all documents with all kwargs given"""
        # ARRANGE
        alias = "alias_1"
        test_type = SolutionTestTypeEnum.COMMON
        include_fields = ["uid", "created_by"]
        exclude_fields = ["updated_by"]
        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [SolutionTestCaseConfig()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            SolutionTestCaseConfig, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = (
                solution_test_case_config_repository.opensearch_get_test_case_configs(
                    alias=alias,
                    test_type=test_type,
                    include_fields=include_fields,
                    exclude_fields=exclude_fields,
                )
            )
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=include_fields, exclude_fields=exclude_fields
            )

            # make sure all expected queries are added
            expected_query_calls = [
                call("term", alias=alias),
                call("term", test_type=test_type),
            ]
            mock_search.query.assert_has_calls(expected_query_calls, any_order=True)

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)

    def test_opensearch_get_test_case_configs_match_all(self):
        """tests get all documents when no term kwargs given"""
        # ARRANGE
        mock_search = MagicMock()
        mock_search.query.return_value = mock_search

        mock_search_hits = [SolutionTestCaseConfig()]
        mock_execute = MagicMock()
        mock_execute.hits = mock_search_hits
        mock_search.execute.return_value = mock_execute

        with patch.object(
            SolutionTestCaseConfig, "create_search_object", return_value=mock_search
        ) as mock_create_search_object:

            # ACT
            actual_docs = (
                solution_test_case_config_repository.opensearch_get_test_case_configs()
            )
            # ASSERT

            # check include/ exclude are passed to search object
            mock_create_search_object.assert_called_once_with(
                include_fields=None, exclude_fields=None
            )

            # make sure all expected queries are added
            mock_search.query.assert_called_once_with("match_all")

            mock_search.execute.assert_called_once_with()
            # verify function returns what is returned in by execute
            self.assertEqual(actual_docs, mock_search_hits)
